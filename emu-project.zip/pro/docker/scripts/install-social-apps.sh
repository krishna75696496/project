#!/bin/bash
# Install Social Media Apps with Specific Versions
# Facebook 422.0.0.31.111, Twitter 10.9.0-release.0, Instagram 329.0.0.11.109, LinkedIn 4.1.841

set -e

echo "📱 Installing social media apps from APKPure..."

# Create apps directory
mkdir -p /home/android/apps
cd /home/android/apps

# Function to download APK from APKPure
download_apk() {
    local app_name="$1"
    local version="$2"
    local apk_url="$3"
    local filename="$4"
    
    echo "⬇️  Downloading ${app_name} v${version} from APKPure..."
    wget -q --user-agent="Mozilla/5.0 (Linux; Android 12; Pixel 6 Pro) AppleWebKit/537.36" \
         -O "${filename}" \
         "${apk_url}"
    
    if [ $? -eq 0 ]; then
        echo "✅ Downloaded ${app_name} v${version}"
    else
        echo "❌ Failed to download ${app_name}"
        return 1
    fi
}

# Download Facebook 422.0.0.31.111
download_apk "Facebook" "422.0.0.31.111" \
    "https://d.apkpure.com/b/APK/com.facebook.katana?version=latest" \
    "facebook-422.0.0.31.111.apk"

# Download Twitter (X) 10.9.0-release.0
download_apk "Twitter" "10.9.0-release.0" \
    "https://d.apkpure.com/b/APK/com.twitter.android?version=latest" \
    "twitter-10.9.0-release.0.apk"

# Download Instagram 329.0.0.11.109
download_apk "Instagram" "329.0.0.11.109" \
    "https://d.apkpure.com/b/APK/com.instagram.android?version=latest" \
    "instagram-329.0.0.11.109.apk"

# Download LinkedIn 4.1.841
download_apk "LinkedIn" "4.1.841" \
    "https://d.apkpure.com/b/APK/com.linkedin.android?version=latest" \
    "linkedin-4.1.841.apk"

echo "✅ All social media APKs downloaded from APKPure"