#!/usr/bin/env python3.10
"""
UI Responsiveness Test for Android 12.0 Emulator
Tests Requirement 12.4: UI interactions should respond within 200ms
"""

import time
import statistics
import subprocess
import logging
from typing import List, Dict, Any

import uiautomator2 as u2
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('ui_responsiveness_test')

class UIResponsivenessTest:
    """Test UI responsiveness of Android 12.0 emulator"""
    
    def __init__(self):
        """Initialize test"""
        self.driver = None
        self.u2_device = None
        self.results = {
            'click_response_times': [],
            'scroll_response_times': [],
            'keyboard_response_times': [],
            'app_switch_times': [],
            'average_response_time': 0,
            'max_response_time': 0,
            'passed': False
        }
    
    def setup(self) -> None:
        """Set up test environment"""
        logger.info("Setting up UI responsiveness test")
        
        # Connect with Appium
        options = UiAutomator2Options()
        options.platform_name = "Android"
        options.platform_version = "12.0"
        options.device_name = "Android_12_API_31"
        options.automation_name = "UiAutomator2"
        options.no_reset = True
        
        self.driver = webdriver.Remote("http://localhost:4723", options=options)
        logger.info("Connected to Appium")
        
        # Connect with uiautomator2 for direct measurements
        self.u2_device = u2.connect()
        logger.info("Connected to uiautomator2")
        
        # Go to home screen
        self.driver.press_keycode(3)  # HOME key
        time.sleep(1)
    
    def test_click_response(self, iterations: int = 10) -> None:
        """Test response time for click actions"""
        logger.info(f"Testing click response time ({iterations} iterations)")
        
        response_times = []
        
        # Open settings app
        self.driver.start_activity("com.android.settings", ".Settings")
        time.sleep(2)
        
        # Find clickable elements
        elements = self.driver.find_elements(AppiumBy.CLASS_NAME, "android.widget.TextView")
        clickable_elements = [e for e in elements if len(e.text) > 0][:5]  # Take first 5 elements
        
        if len(clickable_elements) < 3:
            logger.warning("Not enough clickable elements found")
            return
        
        # Test click response time
        for i in range(iterations):
            element = clickable_elements[i % len(clickable_elements)]
            
            # Measure time to click and get response
            start_time = time.time() * 1000  # Convert to milliseconds
            element.click()
            
            # Wait for UI to respond (any change in the UI)
            try:
                WebDriverWait(self.driver, 2).until(
                    lambda driver: len(driver.find_elements(AppiumBy.CLASS_NAME, "android.widget.TextView")) > 0
                )
                end_time = time.time() * 1000
                response_time = end_time - start_time
                response_times.append(response_time)
                logger.info(f"Click response time: {response_time:.2f}ms")
                
                # Go back
                self.driver.press_keycode(4)  # BACK key
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Error in click test: {e}")
        
        # Calculate statistics
        if response_times:
            avg_time = statistics.mean(response_times)
            max_time = max(response_times)
            logger.info(f"Average click response time: {avg_time:.2f}ms")
            logger.info(f"Maximum click response time: {max_time:.2f}ms")
            
            self.results['click_response_times'] = response_times
        
    def test_scroll_response(self, iterations: int = 5) -> None:
        """Test response time for scroll actions"""
        logger.info(f"Testing scroll response time ({iterations} iterations)")
        
        response_times = []
        
        # Open settings app
        self.driver.start_activity("com.android.settings", ".Settings")
        time.sleep(2)
        
        # Test scroll response time
        for i in range(iterations):
            # Get screen dimensions
            screen_size = self.driver.get_window_size()
            start_x = screen_size['width'] // 2
            start_y = screen_size['height'] * 3 // 4
            end_y = screen_size['height'] // 4
            
            # Measure time to scroll and get response
            start_time = time.time() * 1000
            
            # Use uiautomator2 for more accurate measurement
            self.u2_device.swipe(start_x, start_y, start_x, end_y, 0.1)
            
            # Wait for UI to respond
            time.sleep(0.2)  # Minimum wait to detect changes
            end_time = time.time() * 1000
            response_time = end_time - start_time - 200  # Subtract wait time
            
            response_times.append(response_time)
            logger.info(f"Scroll response time: {response_time:.2f}ms")
        
        # Calculate statistics
        if response_times:
            avg_time = statistics.mean(response_times)
            max_time = max(response_times)
            logger.info(f"Average scroll response time: {avg_time:.2f}ms")
            logger.info(f"Maximum scroll response time: {max_time:.2f}ms")
            
            self.results['scroll_response_times'] = response_times
    
    def test_keyboard_response(self, iterations: int = 5) -> None:
        """Test response time for keyboard input"""
        logger.info(f"Testing keyboard response time ({iterations} iterations)")
        
        response_times = []
        
        # Open search
        self.driver.start_activity("com.android.settings", ".Settings")
        time.sleep(2)
        
        # Find search box
        try:
            search_button = self.driver.find_element(AppiumBy.ID, "com.android.settings:id/search_action_bar")
            search_button.click()
            time.sleep(1)
            
            search_box = self.driver.find_element(AppiumBy.ID, "android:id/search_src_text")
            
            # Test keyboard response time
            for i in range(iterations):
                test_char = chr(97 + i)  # a, b, c, ...
                
                # Measure time to input and get response
                start_time = time.time() * 1000
                search_box.send_keys(test_char)
                
                # Wait for UI to respond (search results to update)
                time.sleep(0.2)  # Minimum wait to detect changes
                end_time = time.time() * 1000
                response_time = end_time - start_time - 200  # Subtract wait time
                
                response_times.append(response_time)
                logger.info(f"Keyboard response time: {response_time:.2f}ms")
                
                # Clear search box
                search_box.clear()
                
        except Exception as e:
            logger.error(f"Error in keyboard test: {e}")
        
        # Calculate statistics
        if response_times:
            avg_time = statistics.mean(response_times)
            max_time = max(response_times)
            logger.info(f"Average keyboard response time: {avg_time:.2f}ms")
            logger.info(f"Maximum keyboard response time: {max_time:.2f}ms")
            
            self.results['keyboard_response_times'] = response_times
    
    def test_app_switching(self, iterations: int = 3) -> None:
        """Test response time for app switching"""
        logger.info(f"Testing app switching response time ({iterations} iterations)")
        
        response_times = []
        
        # Define test apps
        apps = [
            {"package": "com.android.settings", "activity": ".Settings"},
            {"package": "com.android.deskclock", "activity": ".DeskClock"}
        ]
        
        # Test app switching response time
        for i in range(iterations):
            for app in apps:
                # Measure time to switch app and get response
                start_time = time.time() * 1000
                self.driver.start_activity(app["package"], app["activity"])
                
                # Wait for app to be in foreground
                try:
                    WebDriverWait(self.driver, 5).until(
                        lambda driver: app["package"] in driver.current_package
                    )
                    end_time = time.time() * 1000
                    response_time = end_time - start_time
                    
                    response_times.append(response_time)
                    logger.info(f"App switch response time: {response_time:.2f}ms")
                    
                except Exception as e:
                    logger.error(f"Error in app switch test: {e}")
        
        # Calculate statistics
        if response_times:
            avg_time = statistics.mean(response_times)
            max_time = max(response_times)
            logger.info(f"Average app switch response time: {avg_time:.2f}ms")
            logger.info(f"Maximum app switch response time: {max_time:.2f}ms")
            
            self.results['app_switch_times'] = response_times
    
    def calculate_overall_results(self) -> None:
        """Calculate overall results and determine if test passed"""
        all_times = (
            self.results['click_response_times'] +
            self.results['scroll_response_times'] +
            self.results['keyboard_response_times'] +
            self.results['app_switch_times']
        )
        
        if all_times:
            avg_time = statistics.mean(all_times)
            max_time = max(all_times)
            
            self.results['average_response_time'] = avg_time
            self.results['max_response_time'] = max_time
            
            # Requirement 12.4: UI interactions should respond within 200ms
            self.results['passed'] = avg_time < 200
            
            logger.info(f"Overall average response time: {avg_time:.2f}ms")
            logger.info(f"Overall maximum response time: {max_time:.2f}ms")
            logger.info(f"Test passed: {self.results['passed']}")
    
    def run_tests(self) -> Dict[str, Any]:
        """Run all UI responsiveness tests"""
        try:
            self.setup()
            self.test_click_response()
            self.test_scroll_response()
            self.test_keyboard_response()
            self.test_app_switching()
            self.calculate_overall_results()
        except Exception as e:
            logger.error(f"Error running tests: {e}")
        finally:
            if self.driver:
                self.driver.quit()
            
            return self.results

def main():
    """Main function"""
    logger.info("Starting UI responsiveness test for Android 12.0 emulator")
    
    # Check if emulator is running
    try:
        result = subprocess.run(
            ["adb", "devices"], 
            capture_output=True, 
            text=True, 
            check=True
        )
        if "emulator" not in result.stdout:
            logger.error("No emulator found. Please start the emulator first.")
            return
    except Exception as e:
        logger.error(f"Error checking emulator status: {e}")
        return
    
    # Run tests
    test = UIResponsivenessTest()
    results = test.run_tests()
    
    # Print summary
    print("\n" + "="*50)
    print("UI RESPONSIVENESS TEST RESULTS (Requirement 12.4)")
    print("="*50)
    print(f"Average response time: {results['average_response_time']:.2f}ms")
    print(f"Maximum response time: {results['max_response_time']:.2f}ms")
    print(f"Target: <200ms")
    print(f"Test passed: {'✅ YES' if results['passed'] else '❌ NO'}")
    print("="*50)
    
    # Return appropriate exit code
    return 0 if results['passed'] else 1

if __name__ == "__main__":
    main()