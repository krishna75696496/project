#!/bin/bash
# Start Appium 2.4.1 Server with UiAutomator2 driver

set -e

echo "🔧 Starting Appium 2.4.1 server for Android 12.0 automation"

# Create logs directory
mkdir -p /home/android/logs

# Appium server configuration
APPIUM_OPTS=(
    "--address" "0.0.0.0"
    "--port" "4723"
    "--log-level" "info"
    "--log" "/home/android/logs/appium.log"
    "--log-timestamp"
    "--local-timezone"
    "--allow-insecure" "chromedriver_autodownload"
    "--relaxed-security"
)

# Wait for ADB to be available
echo "⏳ Waiting for ADB connection..."
timeout 60 bash -c 'until adb devices | grep -q "emulator"; do sleep 2; done'

if [ $? -eq 0 ]; then
    echo "✅ ADB connection established"
else
    echo "❌ ADB connection timeout"
    exit 1
fi

# Start Appium server
echo "🚀 Starting Appium server with UiAutomator2 driver..."
exec appium "${APPIUM_OPTS[@]}"