#!/bin/bash
# Start Appium 2.4.1 Server with Default Capabilities (Requirement 4.6)

set -e

echo "🔧 Starting Appium 2.4.1 server with default capabilities..."

# Create logs directory
mkdir -p /home/android/logs

# Verify Appium version (Requirement 4.2)
APPIUM_VERSION=$(appium --version)
if [[ $APPIUM_VERSION == "2.4.1" ]]; then
    echo "✅ Appium version verified: $APPIUM_VERSION"
else
    echo "❌ Wrong Appium version: $APPIUM_VERSION (expected 2.4.1)"
    exit 1
fi

# Verify Node.js version (Requirement 4.5)
NODE_VERSION=$(node --version)
echo "✅ Node.js version: $NODE_VERSION"

# Verify Java version (Requirement 4.5)
JAVA_VERSION=$(java -version 2>&1 | head -n 1)
echo "✅ Java version: $JAVA_VERSION"

# Appium server configuration with default capabilities (Requirements 4.3, 4.4, 4.6)
APPIUM_OPTS=(
    "--address" "0.0.0.0"                    # Requirement 4.3: External connections
    "--port" "4723"                          # Requirement 4.4: Port 4723
    "--log-level" "info"
    "--log" "/home/android/logs/appium.log"
    "--log-timestamp"
    "--local-timezone"
    "--allow-insecure" "chromedriver_autodownload"
    "--relaxed-security"
    "--session-override"
    "--default-capabilities" "/home/android/default-capabilities.json"  # Requirement 4.6
)

# Wait for ADB to be available
echo "⏳ Waiting for ADB connection..."
timeout 60 bash -c 'until adb devices | grep -q "emulator"; do sleep 2; done'

if [ $? -eq 0 ]; then
    echo "✅ ADB connection established"
else
    echo "❌ ADB connection timeout"
    exit 1
fi

# Display default capabilities (Requirement 4.6)
echo "📋 Default Desired Capabilities:"
echo "   platformName: Android"
echo "   deviceName: AndroidEmulator"
echo "   automationName: UiAutomator2"
echo "   noReset: true"
echo "   platformVersion: 12.0"

# Start Appium server with configuration
echo "🚀 Starting Appium 2.4.1 server on port 4723..."
echo "🌐 Server accessible at: http://0.0.0.0:4723"
echo "📋 Default capabilities loaded from: /home/android/default-capabilities.json"

exec appium "${APPIUM_OPTS[@]}"