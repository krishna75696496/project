#!/usr/bin/env python3.10
"""
External Python Orchestrator Script for Android 12.0 Emulator
Implements Requirements 11.1-11.7

This script:
1. Listens to NSQ message channel emulator_control on manual_control_requests (11.1)
2. Runs containers in manual mode when receiving signals (11.2)
3. Publishes VNC port information back to NSQ (11.4)
"""

import os
import sys
import json
import time
import logging
import argparse
import subprocess
import random
from typing import Dict, Any, Optional, List

import nsq
import tornado.ioloop

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/var/log/orchestrator.log')
    ]
)
logger = logging.getLogger('orchestrator')

class EmulatorOrchestrator:
    """
    Orchestrator for Android 12.0 Emulator containers
    Implements Requirements 11.1-11.7
    """
    
    def __init__(self, nsq_host: str = 'localhost', nsq_port: int = 4150):
        """Initialize orchestrator with NSQ connection details"""
        self.nsq_host = nsq_host
        self.nsq_port = nsq_port
        self.reader = None
        self.writer = None
        self.running_containers: Dict[str, Dict[str, Any]] = {}
        self.vnc_port_range = range(5901, 6000)  # Requirement 11.3: Port range 5901-6000
    
    def start(self) -> None:
        """Start the orchestrator"""
        logger.info("Starting Android 12.0 Emulator Orchestrator")
        logger.info("Implementing Requirements 11.1-11.7")
        
        # Connect to NSQ
        self.connect_to_nsq()
        
        # Start the event loop
        tornado.ioloop.IOLoop.instance().start()
    
    def connect_to_nsq(self) -> None:
        """Connect to NSQ for listening and publishing"""
        logger.info(f"Connecting to NSQ at {self.nsq_host}:{self.nsq_port}")
        
        try:
            # Create NSQ reader for manual control requests (Requirement 11.1)
            self.reader = nsq.Reader(
                message_handler=self.handle_manual_control_request,
                lookupd_http_addresses=[f'http://{self.nsq_host}:4161'],
                topic='emulator_control',  # Requirement 11.1
                channel='manual_control_requests',  # Requirement 11.1
                nsqd_tcp_addresses=[f'{self.nsq_host}:{self.nsq_port}']
            )
            
            # Create NSQ writer for publishing VNC ports
            self.writer = nsq.Writer([f'{self.nsq_host}:{self.nsq_port}'])
            
            logger.info("Successfully connected to NSQ")
            
        except Exception as e:
            logger.error(f"Failed to connect to NSQ: {e}")
            sys.exit(1)
    
    def handle_manual_control_request(self, message: nsq.Message) -> None:
        """
        Handle manual control request from NSQ
        Requirement 11.2: Run container in manual mode when receiving signal
        """
        try:
            # Process the message
            message.enable_async()
            
            # Parse the message body
            body = message.body.decode('utf-8')
            logger.info(f"Received manual control request: {body}")
            
            request = json.loads(body)
            
            # Validate request
            required_fields = ['avatar_uuid', 'social_media_app']
            if not all(field in request for field in required_fields):
                logger.error(f"Invalid request: missing required fields {required_fields}")
                message.finish()
                return
            
            # Launch container in manual mode
            container_id = self.launch_manual_container(request)
            
            if container_id:
                logger.info(f"Container {container_id} launched successfully")
                message.finish()
            else:
                logger.error("Failed to launch container")
                message.requeue()
                
        except Exception as e:
            logger.error(f"Error handling manual control request: {e}")
            message.requeue()
    
    def launch_manual_container(self, request: Dict[str, Any]) -> Optional[str]:
        """
        Launch a container in manual mode
        Requirement 11.3: Set up container in manual mode
        """
        try:
            # Extract request parameters
            avatar_uuid = request['avatar_uuid']
            social_media_app = request['social_media_app']
            proxy_host = request.get('proxy_host')
            proxy_port = request.get('proxy_port')
            proxy_user = request.get('proxy_user')
            proxy_pass = request.get('proxy_pass')
            
            # Find an available VNC port in the range 5901-6000 (Requirement 11.3)
            vnc_port = self.find_available_port()
            if not vnc_port:
                logger.error("No available VNC ports in range 5901-6000")
                return None
            
            # Generate a unique container name
            container_name = f"emulator-manual-{avatar_uuid}-{int(time.time())}"
            
            # Prepare environment variables
            env_vars = [
                f"AVATAR_UUID={avatar_uuid}",
                f"SOCIAL_MEDIA_APP={social_media_app}",
                "MANUAL_MODE=true",  # Enable manual mode
                f"VNC_PORT={vnc_port}"
            ]
            
            # Add proxy configuration if provided
            if proxy_host and proxy_port:
                env_vars.extend([
                    f"PROXY_HOST={proxy_host}",
                    f"PROXY_PORT={proxy_port}"
                ])
                
                if proxy_user and proxy_pass:
                    env_vars.extend([
                        f"PROXY_USER={proxy_user}",
                        f"PROXY_PASS={proxy_pass}"
                    ])
            
            # Prepare volume mounts
            volume_mounts = [
                # Mount avatar volume to /data partition (Requirement 11.6)
                f"avatar-volume-{avatar_uuid}:/data",
                # Other standard mounts
                "android_data:/home/android/.android",
                "android_scripts:/home/android/scripts",
                "android_logs:/home/android/logs"
            ]
            
            # Build docker run command
            cmd = [
                "docker", "run", "-d",
                "--name", container_name,
                "--privileged",
                "--device", "/dev/kvm:/dev/kvm"
            ]
            
            # Add environment variables
            for env in env_vars:
                cmd.extend(["-e", env])
            
            # Add volume mounts
            for volume in volume_mounts:
                cmd.extend(["-v", volume])
            
            # Add port mappings
            cmd.extend([
                "-p", f"{vnc_port}:5901",  # VNC port (Requirement 11.3)
                "-p", "4723:4723",         # Appium port
                "-p", "6080:6080"          # noVNC port
            ])
            
            # Add image name
            cmd.append("android-emulator:latest")
            
            # Add manual mode command
            cmd.append("manual")
            
            # Run the container
            logger.info(f"Launching container with command: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"Failed to launch container: {result.stderr}")
                return None
            
            # Get container ID
            container_id = result.stdout.strip()
            
            # Store container information
            self.running_containers[container_id] = {
                'avatar_uuid': avatar_uuid,
                'social_media_app': social_media_app,
                'vnc_port': vnc_port,
                'start_time': time.time()
            }
            
            # Publish VNC port information to NSQ (Requirement 11.4)
            self.publish_vnc_port(container_id, vnc_port, avatar_uuid)
            
            return container_id
            
        except Exception as e:
            logger.error(f"Error launching manual container: {e}")
            return None
    
    def find_available_port(self) -> Optional[int]:
        """Find an available port in the range 5901-6000"""
        # Get list of ports in use
        try:
            result = subprocess.run(
                ["netstat", "-tuln"], 
                capture_output=True, 
                text=True
            )
            
            used_ports = []
            for line in result.stdout.splitlines():
                if "LISTEN" in line:
                    parts = line.split()
                    for part in parts:
                        if ":" in part:
                            try:
                                port = int(part.split(":")[-1])
                                used_ports.append(port)
                            except ValueError:
                                pass
            
            # Find available port in range
            for port in self.vnc_port_range:
                if port not in used_ports and port not in [c['vnc_port'] for c in self.running_containers.values()]:
                    return port
            
            return None
            
        except Exception as e:
            logger.error(f"Error finding available port: {e}")
            # Fallback to random port in range
            return random.choice(list(self.vnc_port_range))
    
    def publish_vnc_port(self, container_id: str, vnc_port: int, avatar_uuid: str) -> None:
        """
        Publish VNC port information to NSQ
        Requirement 11.4: Publish to emulator_control on vnc_ports channel
        """
        try:
            # Prepare message
            message = {
                'container_id': container_id,
                'vnc_port': vnc_port,
                'avatar_uuid': avatar_uuid,
                'timestamp': time.time()
            }
            
            # Publish to NSQ
            logger.info(f"Publishing VNC port information to NSQ: {message}")
            self.writer.pub('emulator_control', json.dumps(message).encode('utf-8'), 
                           callback=self.nsq_publish_callback)
            
        except Exception as e:
            logger.error(f"Error publishing VNC port information: {e}")
    
    def nsq_publish_callback(self, conn, data) -> None:
        """Callback for NSQ publish"""
        if isinstance(data, nsq.Error):
            logger.error(f"NSQ publish error: {data}")
        else:
            logger.info("Successfully published to NSQ")
    
    def stop(self) -> None:
        """Stop the orchestrator"""
        logger.info("Stopping orchestrator")
        
        # Close NSQ connections
        if self.reader:
            self.reader.close()
        
        # Stop running containers
        for container_id in self.running_containers:
            try:
                subprocess.run(["docker", "stop", container_id], check=True)
                logger.info(f"Stopped container {container_id}")
            except Exception as e:
                logger.error(f"Error stopping container {container_id}: {e}")
        
        # Stop the event loop
        tornado.ioloop.IOLoop.instance().stop()

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Android 12.0 Emulator Orchestrator')
    parser.add_argument('--nsq-host', default='localhost', help='NSQ host')
    parser.add_argument('--nsq-port', type=int, default=4150, help='NSQ port')
    args = parser.parse_args()
    
    # Create and start orchestrator
    orchestrator = EmulatorOrchestrator(args.nsq_host, args.nsq_port)
    
    try:
        orchestrator.start()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down")
        orchestrator.stop()
    except Exception as e:
        logger.error(f"Error in orchestrator: {e}")
        orchestrator.stop()
        sys.exit(1)

if __name__ == "__main__":
    main()