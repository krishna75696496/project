#!/bin/bash
# Setup Social Media Apps with Automated User Agreement Handling
# Requirement 2.4: Automated setup process for user agreements
# Requirement 2.5: Disable background services by default

set -e

echo "🔧 Setting up social media apps with automated configuration..."

# Wait for emulator to be fully ready
wait_for_emulator() {
    echo "⏳ Waiting for Android 12.0 emulator to be ready..."
    timeout 300 bash -c 'until adb shell getprop sys.boot_completed | grep -q "1"; do sleep 5; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Android 12.0 emulator is ready for app installation"
    else
        echo "❌ Emulator not ready within timeout"
        exit 1
    fi
}

# Install APK with error handling
install_apk() {
    local app_name="$1"
    local apk_file="$2"
    local package_name="$3"
    
    echo "📦 Installing ${app_name}..."
    
    if [ -f "/home/android/apps/${apk_file}" ]; then
        adb install -r "/home/android/apps/${apk_file}"
        
        if [ $? -eq 0 ]; then
            echo "✅ ${app_name} installed successfully"
            return 0
        else
            echo "❌ Failed to install ${app_name}"
            return 1
        fi
    else
        echo "❌ APK file not found: ${apk_file}"
        return 1
    fi
}

# Disable background services for an app
disable_background_services() {
    local package_name="$1"
    local app_name="$2"
    
    echo "🚫 Disabling background services for ${app_name}..."
    
    # Disable background app refresh
    adb shell cmd appops set "${package_name}" RUN_IN_BACKGROUND ignore
    
    # Disable auto-start
    adb shell pm disable-user "${package_name}/.service.BackgroundService" 2>/dev/null || true
    
    # Disable notifications (optional)
    adb shell cmd notification set_enabled "${package_name}" false
    
    # Set battery optimization (doze mode)
    adb shell dumpsys deviceidle whitelist -"${package_name}"
    
    echo "✅ Background services disabled for ${app_name}"
}

# Handle user agreements automatically
handle_user_agreements() {
    local package_name="$1"
    local app_name="$2"
    
    echo "📋 Handling user agreements for ${app_name}..."
    
    # Launch app
    adb shell monkey -p "${package_name}" -c android.intent.category.LAUNCHER 1
    sleep 5
    
    # Common agreement handling patterns
    # Accept terms and conditions
    adb shell input tap 500 1200  # Common "Accept" button location
    sleep 2
    
    # Skip onboarding screens
    for i in {1..5}; do
        adb shell input tap 800 1200  # "Next" or "Skip" button
        sleep 2
    done
    
    # Deny location permissions (privacy-focused)
    adb shell input tap 300 800   # "Deny" button for location
    sleep 1
    
    # Deny notification permissions
    adb shell input tap 300 800   # "Deny" button for notifications
    sleep 1
    
    # Close app
    adb shell am force-stop "${package_name}"
    
    echo "✅ User agreements handled for ${app_name}"
}

# Grant necessary permissions
grant_permissions() {
    local package_name="$1"
    local app_name="$2"
    
    echo "🔐 Granting necessary permissions for ${app_name}..."
    
    # Grant only essential permissions
    adb shell pm grant "${package_name}" android.permission.INTERNET 2>/dev/null || true
    adb shell pm grant "${package_name}" android.permission.ACCESS_NETWORK_STATE 2>/dev/null || true
    adb shell pm grant "${package_name}" android.permission.WRITE_EXTERNAL_STORAGE 2>/dev/null || true
    
    # Explicitly deny sensitive permissions
    adb shell pm revoke "${package_name}" android.permission.ACCESS_FINE_LOCATION 2>/dev/null || true
    adb shell pm revoke "${package_name}" android.permission.ACCESS_COARSE_LOCATION 2>/dev/null || true
    adb shell pm revoke "${package_name}" android.permission.CAMERA 2>/dev/null || true
    adb shell pm revoke "${package_name}" android.permission.RECORD_AUDIO 2>/dev/null || true
    adb shell pm revoke "${package_name}" android.permission.READ_CONTACTS 2>/dev/null || true
    
    echo "✅ Permissions configured for ${app_name}"
}

# Main setup process
main() {
    wait_for_emulator
    
    echo "📱 Installing and configuring social media apps..."
    
    # Install Facebook 422.0.0.31.111
    if install_apk "Facebook" "facebook-422.0.0.31.111.apk" "com.facebook.katana"; then
        grant_permissions "com.facebook.katana" "Facebook"
        disable_background_services "com.facebook.katana" "Facebook"
        handle_user_agreements "com.facebook.katana" "Facebook"
    fi
    
    # Install Twitter (X) 10.9.0-release.0
    if install_apk "Twitter" "twitter-10.9.0-release.0.apk" "com.twitter.android"; then
        grant_permissions "com.twitter.android" "Twitter"
        disable_background_services "com.twitter.android" "Twitter"
        handle_user_agreements "com.twitter.android" "Twitter"
    fi
    
    # Install Instagram 329.0.0.11.109
    if install_apk "Instagram" "instagram-329.0.0.11.109.apk" "com.instagram.android"; then
        grant_permissions "com.instagram.android" "Instagram"
        disable_background_services "com.instagram.android" "Instagram"
        handle_user_agreements "com.instagram.android" "Instagram"
    fi
    
    # Install LinkedIn 4.1.841
    if install_apk "LinkedIn" "linkedin-4.1.841.apk" "com.linkedin.android"; then
        grant_permissions "com.linkedin.android" "LinkedIn"
        disable_background_services "com.linkedin.android" "LinkedIn"
        handle_user_agreements "com.linkedin.android" "LinkedIn"
    fi
    
    echo "🎉 All social media apps installed and configured!"
    echo ""
    echo "📱 Installed Apps:"
    echo "   ✅ Facebook 422.0.0.31.111 (com.facebook.katana)"
    echo "   ✅ Twitter 10.9.0-release.0 (com.twitter.android)"
    echo "   ✅ Instagram 329.0.0.11.109 (com.instagram.android)"
    echo "   ✅ LinkedIn 4.1.841 (com.linkedin.android)"
    echo ""
    echo "🔒 Security Configuration:"
    echo "   ✅ Background services disabled"
    echo "   ✅ User agreements handled automatically"
    echo "   ✅ Sensitive permissions denied"
    echo "   ✅ APKs sourced from APKPure"
}

# Run main setup
main "$@"