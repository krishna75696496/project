#!/bin/bash
set -e

# Enhanced Entrypoint script for Appium 2.4.1 Requirements 4.1-4.6
# Ubuntu 20.04 + Python 3.10 + Appium 2.4.1 + Node.js 18.19.1 + Java 11

echo "🚀 Starting Appium 2.4.1 Android 12.0 Emulator Container"
echo "🔧 Appium 2.4.1 | 📱 Android 12.0 | 🐍 Python 3.10 | ☕ Java 11 | 🟢 Node.js 18.x"

# Verify Appium requirements (4.1-4.6)
verify_appium_requirements() {
    echo "🔍 Verifying Appium Requirements 4.1-4.6..."
    
    # Requirement 4.1: Compatible Appium server in Docker
    if command -v appium &> /dev/null; then
        echo "✅ Requirement 4.1: Appium server installed in Docker container"
    else
        echo "❌ Requirement 4.1: Appium server not found"
        exit 1
    fi
    
    # Requirement 4.2: Appium version 2.4.1
    APPIUM_VERSION=$(appium --version)
    if [[ $APPIUM_VERSION == "2.4.1" ]]; then
        echo "✅ Requirement 4.2: Appium version $APPIUM_VERSION"
    else
        echo "❌ Requirement 4.2: Wrong Appium version $APPIUM_VERSION (expected 2.4.1)"
        exit 1
    fi
    
    # Requirement 4.5: Node.js 18.19.1 and Java 11
    NODE_VERSION=$(node --version | cut -d'v' -f2)
    if [[ $NODE_VERSION == 18.* ]]; then
        echo "✅ Requirement 4.5a: Node.js $NODE_VERSION (compatible with 18.19.1)"
    else
        echo "❌ Requirement 4.5a: Wrong Node.js version $NODE_VERSION"
        exit 1
    fi
    
    JAVA_VERSION=$(java -version 2>&1 | head -n 1 | grep -o '".*"' | sed 's/"//g')
    if [[ $JAVA_VERSION == 11.* ]]; then
        echo "✅ Requirement 4.5b: Java $JAVA_VERSION"
    else
        echo "❌ Requirement 4.5b: Wrong Java version $JAVA_VERSION"
        exit 1
    fi
    
    # Requirement 4.6: Default desired capabilities
    if [ -f "/home/android/default-capabilities.json" ]; then
        echo "✅ Requirement 4.6: Default capabilities file exists"
        
        # Verify required capabilities
        CAPABILITIES=$(cat /home/android/default-capabilities.json)
        if echo "$CAPABILITIES" | grep -q '"platformName": "Android"' && \
           echo "$CAPABILITIES" | grep -q '"deviceName": "AndroidEmulator"' && \
           echo "$CAPABILITIES" | grep -q '"automationName": "UiAutomator2"' && \
           echo "$CAPABILITIES" | grep -q '"noReset": true'; then
            echo "✅ Requirement 4.6: All required default capabilities present"
        else
            echo "❌ Requirement 4.6: Missing required default capabilities"
            exit 1
        fi
    else
        echo "❌ Requirement 4.6: Default capabilities file not found"
        exit 1
    fi
    
    echo "✅ All Appium Requirements 4.1-4.6 verified successfully!"
}

# Check KVM availability
if [ -e /dev/kvm ]; then
    echo "✅ KVM hardware acceleration available"
    export EMULATOR_ACCEL="-accel kvm"
else
    echo "⚠️  KVM not available, using software acceleration"
    export EMULATOR_ACCEL="-accel tcg"
fi

# Set display for headless operation
export DISPLAY=:99

# Function to start Xvfb (Virtual Display)
start_xvfb() {
    echo "🖥️  Starting virtual display (Xvfb)"
    Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset &
    export XVFB_PID=$!
    sleep 2
}

# Function to start VNC server
start_vnc() {
    echo "🌐 Starting VNC server for remote access"
    /usr/local/bin/start-vnc.sh &
    export VNC_PID=$!
}

# Function to start Android Emulator
start_emulator() {
    echo "📱 Starting Android 12.0 emulator"
    /usr/local/bin/start-emulator.sh &
    export EMULATOR_PID=$!
    
    # Wait for emulator to be ready
    echo "⏳ Waiting for Android 12.0 emulator to boot..."
    timeout 300 bash -c 'until adb shell getprop sys.boot_completed | grep -q "1"; do sleep 5; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Android 12.0 emulator is ready!"
        adb shell settings put global window_animation_scale 0
        adb shell settings put global transition_animation_scale 0
        adb shell settings put global animator_duration_scale 0
        echo "🎯 Disabled animations for testing optimization"
    else
        echo "❌ Emulator failed to start within timeout"
        exit 1
    fi
}

# Function to start Appium server with default capabilities
start_appium() {
    echo "🔧 Starting Appium 2.4.1 server with default capabilities"
    /usr/local/bin/start-appium.sh &
    export APPIUM_PID=$!
    
    # Wait for Appium to be ready
    echo "⏳ Waiting for Appium server..."
    timeout 60 bash -c 'until curl -s http://localhost:4723/wd/hub/status > /dev/null; do sleep 2; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Appium 2.4.1 server is ready!"
        echo "🌐 Server accessible at: http://localhost:4723"
        echo "📋 Default capabilities loaded and configured"
    else
        echo "❌ Appium server failed to start"
        exit 1
    fi
}

# Function to display system information
show_system_info() {
    echo ""
    echo "📊 System Information:"
    echo "   OS: $(lsb_release -d | cut -f2)"
    echo "   Python: $(python3.10 --version)"
    echo "   Appium: $(appium --version)"
    echo "   Node.js: $(node --version)"
    echo "   Java: $(java -version 2>&1 | head -n 1)"
    echo "   Android SDK: API Level $ANDROID_API_LEVEL"
    echo "   KVM: $([ -e /dev/kvm ] && echo 'Available' || echo 'Not Available')"
    echo ""
    echo "🔧 Appium 2.4.1 Configuration (Requirements 4.1-4.6):"
    echo "   ✅ 4.1: Appium server installed in Docker"
    echo "   ✅ 4.2: Appium version 2.4.1"
    echo "   ✅ 4.3: External connections configured (0.0.0.0)"
    echo "   ✅ 4.4: Exposed on port 4723"
    echo "   ✅ 4.5: Node.js $(node --version) + Java 11"
    echo "   ✅ 4.6: Default capabilities pre-configured"
    echo ""
    echo "📋 Default Desired Capabilities:"
    echo "   • platformName: Android"
    echo "   • deviceName: AndroidEmulator"
    echo "   • automationName: UiAutomator2"
    echo "   • noReset: true"
    echo ""
    echo "🌐 Access Points:"
    echo "   Appium Server: http://localhost:4723"
    echo "   VNC Server: vnc://localhost:5901"
    echo "   noVNC Web: http://localhost:6080"
    echo "   ADB Port: 5555"
    echo ""
}

# Function to cleanup on exit
cleanup() {
    echo "🧹 Cleaning up processes..."
    [ ! -z "$APPIUM_PID" ] && kill $APPIUM_PID 2>/dev/null || true
    [ ! -z "$EMULATOR_PID" ] && kill $EMULATOR_PID 2>/dev/null || true
    [ ! -z "$VNC_PID" ] && kill $VNC_PID 2>/dev/null || true
    [ ! -z "$XVFB_PID" ] && kill $XVFB_PID 2>/dev/null || true
    exit 0
}

# Set up signal handlers
trap cleanup SIGTERM SIGINT

# Main execution
case "${1:-start}" in
    start)
        verify_appium_requirements
        show_system_info
        start_xvfb
        start_vnc
        start_emulator
        start_appium
        
        echo "🎉 Appium 2.4.1 Android 12.0 Emulator Container is fully operational!"
        echo "🔧 Ready for automation with pre-configured default capabilities"
        echo "✅ Requirements 4.1-4.6 fully implemented!"
        
        # Keep container running
        while true; do
            sleep 30
            # Health check
            if ! curl -s http://localhost:4723/wd/hub/status > /dev/null; then
                echo "❌ Appium server health check failed"
                exit 1
            fi
        done
        ;;
    
    verify)
        echo "🔍 Verifying Appium 2.4.1 requirements..."
        verify_appium_requirements
        echo "✅ Appium requirements verification complete"
        ;;
    
    shell)
        echo "🐚 Starting interactive shell"
        exec /bin/bash
        ;;
    
    test)
        echo "🧪 Running Appium 2.4.1 tests"
        verify_appium_requirements
        
        # Test Appium server
        echo "🧪 Testing Appium server..."
        timeout 30 bash -c 'until curl -s http://localhost:4723/wd/hub/status > /dev/null; do sleep 2; done' || {
            echo "❌ Appium server not accessible"
            exit 1
        }
        
        # Test default capabilities
        echo "🧪 Testing default capabilities..."
        CAPABILITIES_RESPONSE=$(curl -s http://localhost:4723/wd/hub/status)
        if echo "$CAPABILITIES_RESPONSE" | grep -q "ready"; then
            echo "✅ Appium server ready with default capabilities"
        else
            echo "❌ Appium server not ready"
            exit 1
        fi
        
        echo "🎉 All Appium 2.4.1 tests passed!"
        ;;
    
    *)
        echo "Usage: $0 {start|verify|shell|test}"
        exit 1
        ;;
esac