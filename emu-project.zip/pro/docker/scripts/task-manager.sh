#!/bin/bash
# Task Manager for Android 12.0 Emulator
# Implements Requirements 10.1-10.12

set -e

# Configuration
LOG_FILE="/var/log/emulator_task.log"
PROFILES_DIR="/emulator_profiles"
TASK_LOOP_INTERVAL=60  # seconds to wait between API calls when no tasks (Requirement 10.3)

# Ensure log file exists and is writable
mkdir -p $(dirname $LOG_FILE)
touch $LOG_FILE
chmod 666 $LOG_FILE

# Log function with timestamps
log() {
    local level=$1
    local message=$2
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $message" | tee -a $LOG_FILE
}

# Initialize task manager
log "INFO" "Initializing Android 12.0 emulator task manager"

# Check required environment variables (Requirement 10.1)
if [ -z "$BACKEND_API_ENDPOINT" ]; then
    log "ERROR" "BACKEND_API_ENDPOINT environment variable is not set"
    exit 1
fi

# Check if profiles directory is mounted (Requirement 10.1, 10.8)
if [ ! -d "$PROFILES_DIR" ]; then
    log "ERROR" "Profiles directory not mounted at $PROFILES_DIR"
    exit 1
fi

log "INFO" "Using backend API: $BACKEND_API_ENDPOINT"
log "INFO" "Using profiles directory: $PROFILES_DIR"

# Function to get a task from the backend API (Requirement 10.2)
get_task() {
    log "INFO" "Requesting task from $BACKEND_API_ENDPOINT/get_task"
    
    # Make API call to get task
    local response
    response=$(curl -s -f -X GET "$BACKEND_API_ENDPOINT/get_task")
    
    # Check if response is empty or contains tasks
    if [ -z "$response" ] || [ "$response" = "[]" ] || [ "$response" = "{}" ]; then
        log "INFO" "No tasks available, will retry in $TASK_LOOP_INTERVAL seconds"
        return 1
    fi
    
    # Save task to temporary file
    echo "$response" > /tmp/current_task.json
    log "INFO" "Received task: $(cat /tmp/current_task.json | jq -c .)"
    return 0
}

# Function to update task status (Requirement 10.5)
update_task_status() {
    local task_id=$1
    local status=$2
    local details=$3
    
    log "INFO" "Updating task status: $task_id -> $status"
    
    # Create status update payload
    local payload="{\"task_id\": \"$task_id\", \"status\": \"$status\", \"details\": \"$details\"}"
    
    # Send status update to backend
    curl -s -f -X POST "$BACKEND_API_ENDPOINT/update_status" \
         -H "Content-Type: application/json" \
         -d "$payload" || log "ERROR" "Failed to update task status"
}

# Function to submit task results (Requirement 10.5)
submit_task_results() {
    local task_id=$1
    local results_file=$2
    
    log "INFO" "Submitting results for task: $task_id"
    
    # Check if results file exists
    if [ ! -f "$results_file" ]; then
        log "ERROR" "Results file not found: $results_file"
        return 1
    }
    
    # Send results to backend
    curl -s -f -X POST "$BACKEND_API_ENDPOINT/submit_result" \
         -H "Content-Type: application/json" \
         -d @"$results_file" || log "ERROR" "Failed to submit task results"
}

# Function to report errors (Requirement 10.12)
report_error() {
    local task_id=$1
    local error_message=$2
    
    log "ERROR" "Task $task_id failed: $error_message"
    
    # Create error payload
    local payload="{\"task_id\": \"$task_id\", \"error\": \"$error_message\"}"
    
    # Send error to backend
    curl -s -f -X POST "$BACKEND_API_ENDPOINT/report_error" \
         -H "Content-Type: application/json" \
         -d "$payload" || log "ERROR" "Failed to report error to backend"
}

# Function to configure proxy for a task (Requirement 10.4)
configure_task_proxy() {
    log "INFO" "Configuring proxy for task execution"
    
    # Check if proxy environment variables are set
    if [ -z "$PROXY_HOST" ] || [ -z "$PROXY_PORT" ]; then
        log "WARN" "Proxy configuration skipped: PROXY_HOST or PROXY_PORT not set"
        return 1
    fi
    
    # Configure proxy using the existing script
    /usr/local/bin/configure-proxy.sh
    
    # Apply proxy settings to Android
    if [ -f "/home/android/.proxy/pending_config" ]; then
        log "INFO" "Applying proxy configuration to Android 12.0"
        configure_android_proxy
        rm /home/android/.proxy/pending_config
    fi
    
    log "INFO" "Proxy configured successfully"
    return 0
}

# Function to load browser profile (Requirement 10.4, 10.8)
load_profile() {
    local account=$1
    
    log "INFO" "Loading browser profile for account: $account"
    
    # Check if profile exists
    local profile_path="$PROFILES_DIR/$account"
    if [ ! -d "$profile_path" ]; then
        log "ERROR" "Profile not found: $profile_path"
        return 1
    fi
    
    # Verify profile structure
    if [ ! -f "$profile_path/cookies.sqlite" ]; then
        log "WARN" "Profile may be incomplete, cookies.sqlite not found"
    }
    
    # Copy profile to appropriate location for the app to use
    # This is a placeholder - actual implementation depends on how the app uses profiles
    local app_profile_dir="/home/android/.app_profiles/$account"
    mkdir -p "$app_profile_dir"
    cp -r "$profile_path/"* "$app_profile_dir/"
    
    log "INFO" "Profile loaded successfully"
    return 0
}

# Function to save profile after task (Requirement 10.6, 10.11)
save_profile() {
    local account=$1
    
    log "INFO" "Saving browser profile for account: $account"
    
    # Check if profile exists
    local profile_path="$PROFILES_DIR/$account"
    if [ ! -d "$profile_path" ]; then
        log "INFO" "Creating new profile directory: $profile_path"
        mkdir -p "$profile_path"
    fi
    
    # Copy profile from app location back to persistent storage
    local app_profile_dir="/home/android/.app_profiles/$account"
    if [ -d "$app_profile_dir" ]; then
        cp -r "$app_profile_dir/"* "$profile_path/"
        log "INFO" "Profile saved successfully"
        return 0
    else
        log "ERROR" "App profile directory not found: $app_profile_dir"
        return 1
    fi
}

# Function to launch social media app (Requirement 10.4)
launch_app() {
    local app_name=$1
    
    log "INFO" "Launching social media app: $app_name"
    
    # Convert app name to package name
    local package_name
    case "$app_name" in
        "facebook")
            package_name="com.facebook.katana"
            ;;
        "instagram")
            package_name="com.instagram.android"
            ;;
        "twitter")
            package_name="com.twitter.android"
            ;;
        "whatsapp")
            package_name="com.whatsapp"
            ;;
        *)
            log "ERROR" "Unknown app: $app_name"
            return 1
            ;;
    esac
    
    # Check if app is installed
    if ! adb shell pm list packages | grep -q "$package_name"; then
        log "ERROR" "App not installed: $package_name"
        return 1
    fi
    
    # Launch the app
    adb shell monkey -p "$package_name" -c android.intent.category.LAUNCHER 1
    
    # Wait for app to start
    sleep 5
    
    # Verify app is running
    local current_app=$(adb shell dumpsys window | grep -E 'mCurrentFocus' | cut -d'/' -f1 | cut -d' ' -f5)
    if [[ "$current_app" == *"$package_name"* ]]; then
        log "INFO" "App launched successfully: $app_name"
        return 0
    else
        log "ERROR" "Failed to launch app: $app_name"
        return 1
    fi
}

# Function to close app (Requirement 10.6)
close_app() {
    local app_name=$1
    
    log "INFO" "Closing social media app: $app_name"
    
    # Convert app name to package name
    local package_name
    case "$app_name" in
        "facebook")
            package_name="com.facebook.katana"
            ;;
        "instagram")
            package_name="com.instagram.android"
            ;;
        "twitter")
            package_name="com.twitter.android"
            ;;
        "whatsapp")
            package_name="com.whatsapp"
            ;;
        *)
            log "ERROR" "Unknown app: $app_name"
            return 1
            ;;
    esac
    
    # Force stop the app
    adb shell am force-stop "$package_name"
    
    log "INFO" "App closed successfully: $app_name"
    return 0
}

# Function to execute Python script (Requirement 10.4, 10.10)
execute_python_script() {
    local script_path=$1
    local task_id=$2
    local results_file="/tmp/task_${task_id}_results.json"
    
    log "INFO" "Executing Python script: $script_path"
    
    # Check if script exists
    if [ ! -f "$script_path" ]; then
        log "ERROR" "Script not found: $script_path"
        return 1
    }
    
    # Execute the script with task data
    python3.10 "$script_path" --task-data /tmp/current_task.json --results-file "$results_file"
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log "INFO" "Script executed successfully"
        echo "$results_file"
        return 0
    else
        log "ERROR" "Script execution failed with exit code: $exit_code"
        return 1
    fi
}

# Main task execution function (Requirement 10.4)
execute_task() {
    # Parse task data
    local task_id=$(cat /tmp/current_task.json | jq -r '.task_id')
    local task_type=$(cat /tmp/current_task.json | jq -r '.task_type')
    local account=$(cat /tmp/current_task.json | jq -r '.account')
    local app_name=$(cat /tmp/current_task.json | jq -r '.social_media_app')
    local python_code=$(cat /tmp/current_task.json | jq -r '.python_code')
    
    log "INFO" "Executing task: $task_id ($task_type)"
    
    # Update task status to running
    update_task_status "$task_id" "running" "Task execution started"
    
    # Configure proxy for the task
    if ! configure_task_proxy; then
        log "WARN" "Continuing without proxy configuration"
    fi
    
    # Load browser profile
    if ! load_profile "$account"; then
        report_error "$task_id" "Failed to load profile for account: $account"
        update_task_status "$task_id" "failed" "Failed to load profile"
        return 1
    fi
    
    # Launch social media app
    if ! launch_app "$app_name"; then
        report_error "$task_id" "Failed to launch app: $app_name"
        update_task_status "$task_id" "failed" "Failed to launch app"
        return 1
    fi
    
    # Execute Python script
    update_task_status "$task_id" "running" "Executing Python script"
    local results_file
    results_file=$(execute_python_script "$python_code" "$task_id")
    local script_exit_code=$?
    
    if [ $script_exit_code -ne 0 ]; then
        report_error "$task_id" "Python script execution failed"
        update_task_status "$task_id" "failed" "Script execution failed"
        close_app "$app_name"
        return 1
    fi
    
    # Submit results
    if ! submit_task_results "$task_id" "$results_file"; then
        report_error "$task_id" "Failed to submit task results"
        update_task_status "$task_id" "failed" "Failed to submit results"
        close_app "$app_name"
        return 1
    fi
    
    # Close app properly
    if ! close_app "$app_name"; then
        log "WARN" "Failed to close app properly: $app_name"
    fi
    
    # Save profile
    if ! save_profile "$account"; then
        report_error "$task_id" "Failed to save profile for account: $account"
        update_task_status "$task_id" "failed" "Failed to save profile"
        return 1
    fi
    
    # Update task status to completed
    update_task_status "$task_id" "completed" "Task execution completed successfully"
    log "INFO" "Task completed successfully: $task_id"
    
    return 0
}

# Main task loop (Requirement 10.7)
main_task_loop() {
    log "INFO" "Starting main task loop"
    
    while true; do
        # Get a task from the backend
        if get_task; then
            # Execute the task
            execute_task
            
            # Clean up
            rm -f /tmp/current_task.json
        else
            # No tasks available, wait and retry (Requirement 10.3)
            log "INFO" "No tasks available, waiting for $TASK_LOOP_INTERVAL seconds"
            sleep $TASK_LOOP_INTERVAL
        fi
    done
}

# Start the task loop
main_task_loop