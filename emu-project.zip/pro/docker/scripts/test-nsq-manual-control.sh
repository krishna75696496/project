#!/bin/bash
# Test script for NSQ manual control (Requirements 11.1-11.7)

set -e

echo "🧪 Testing NSQ manual control implementation"
echo "📋 Requirements 11.1-11.7"

# Check if NSQ is installed
if ! command -v nsq_tail &> /dev/null; then
    echo "❌ NSQ tools not installed. Please install NSQ first."
    echo "   https://nsq.io/deployment/installing.html"
    exit 1
fi

# Check if Docker is running
if ! docker info &> /dev/null; then
    echo "❌ Docker is not running. Please start Docker first."
    exit 1
fi

# Start NSQ if not already running
if ! pgrep -x "nsqlookupd" > /dev/null; then
    echo "🚀 Starting NSQ lookupd..."
    nsqlookupd &
    NSQLOOKUPD_PID=$!
    sleep 2
fi

if ! pgrep -x "nsqd" > /dev/null; then
    echo "🚀 Starting NSQ daemon..."
    nsqd --lookupd-tcp-address=127.0.0.1:4160 &
    NSQD_PID=$!
    sleep 2
fi

# Create topics
echo "🔧 Creating NSQ topics..."
curl -s -X POST "http://127.0.0.1:4151/topic/create?topic=emulator_control"

# Start listening for VNC port messages
echo "👂 Starting listener for VNC port messages..."
nsq_tail --topic=emulator_control --channel=vnc_ports --lookupd-http-address=127.0.0.1:4161 > /tmp/vnc_ports.log &
TAIL_PID=$!

# Start the orchestrator in test mode
echo "🚀 Starting orchestrator in test mode..."
python3.10 orchestrator.py --nsq-host localhost --nsq-port 4150 --test-mode &
ORCHESTRATOR_PID=$!
sleep 5

# Send a test manual control request
echo "📤 Sending test manual control request..."
cat nsq-example-messages/manual_control_request.json | curl -s -d @- "http://127.0.0.1:4151/pub?topic=emulator_control"

# Wait for response
echo "⏳ Waiting for VNC port response..."
sleep 10

# Check if we received a VNC port message
if grep -q "container_id" /tmp/vnc_ports.log; then
    echo "✅ Received VNC port message:"
    cat /tmp/vnc_ports.log
    echo ""
    echo "✅ Requirements 11.1-11.7 verified successfully!"
else
    echo "❌ Did not receive VNC port message within timeout"
    echo "❌ Test failed"
fi

# Cleanup
echo "🧹 Cleaning up..."
kill $TAIL_PID 2>/dev/null || true
kill $ORCHESTRATOR_PID 2>/dev/null || true

# Don't kill NSQ if it was already running
if [ ! -z "$NSQD_PID" ]; then
    kill $NSQD_PID 2>/dev/null || true
fi

if [ ! -z "$NSQLOOKUPD_PID" ]; then
    kill $NSQLOOKUPD_PID 2>/dev/null || true
fi

rm -f /tmp/vnc_ports.log

echo "🎉 Test completed"