#!/bin/bash
# Start Android 12.0 Emulator with optimal settings

set -e

echo "🚀 Starting Android 12.0 emulator with hardware acceleration"

# Check if AVD exists
if [ ! -d "/home/android/.android/avd/Android_12_API_31.avd" ]; then
    echo "❌ AVD 'Android_12_API_31' not found"
    exit 1
fi

# Emulator configuration
EMULATOR_OPTS=(
    "-avd" "Android_12_API_31"
    "-no-audio"
    "-no-window"
    "-gpu" "swiftshader_indirect"
    "-no-snapshot"
    "-no-snapstorage"
    "-camera-back" "none"
    "-camera-front" "none"
    "-memory" "4096"
    "-partition-size" "8192"
    "-cores" "4"
    "-netdelay" "none"
    "-netspeed" "full"
    "-qemu" "-enable-kvm"
)

# Add KVM acceleration if available
if [ -e /dev/kvm ]; then
    echo "✅ Using KVM hardware acceleration"
    EMULATOR_OPTS+=("-accel" "kvm")
else
    echo "⚠️  KVM not available, using software acceleration"
    EMULATOR_OPTS+=("-accel" "tcg")
fi

# Start emulator
echo "📱 Launching Android 12.0 emulator..."
exec emulator "${EMULATOR_OPTS[@]}" \
    -verbose \
    -show-kernel \
    -logcat '*:V' \
    2>&1 | tee /home/android/logs/emulator.log