#!/bin/bash
set -e

# Entrypoint script for Android 12.0 Emulator Container
# Ubuntu 20.04 + Python 3.10 + Appium 2.4.1 + VNC/noVNC + SOCKS5 Proxy + Task Management

echo "🚀 Starting Android 12.0 Emulator Container"
echo "📱 Ubuntu 20.04 LTS | Python 3.10.12 | Appium 2.4.1"
echo "🌐 VNC 1.3.9 | noVNC 1.4.0"

# Check KVM availability
if [ -e /dev/kvm ]; then
    echo "✅ KVM hardware acceleration available"
    export EMULATOR_ACCEL="-accel kvm"
else
    echo "⚠️  KVM not available, using software acceleration"
    export EMULATOR_ACCEL="-accel tcg"
fi

# Set display for headless operation
export DISPLAY=:99

# Configure SOCKS5 proxy if environment variables are set (Requirements 9.1-9.4)
if [ ! -z "$PROXY_HOST" ] && [ ! -z "$PROXY_PORT" ]; then
    echo "🌐 Configuring SOCKS5 proxy: $PROXY_HOST:$PROXY_PORT"
    /usr/local/bin/configure-proxy.sh
else
    echo "ℹ️ No proxy configuration provided"
fi

# Check for browser profiles mount (Requirement 10.1, 10.8)
if [ ! -d "/emulator_profiles" ]; then
    echo "⚠️ Browser profiles directory not mounted at /emulator_profiles"
    mkdir -p /emulator_profiles
    echo "Created empty directory for profiles"
else
    echo "✅ Browser profiles mounted at /emulator_profiles"
    ls -la /emulator_profiles
fi

# Check for backend API endpoint (Requirement 10.1)
if [ -z "$BACKEND_API_ENDPOINT" ]; then
    echo "⚠️ BACKEND_API_ENDPOINT environment variable not set"
    echo "Task management will not be available"
    export TASK_MANAGEMENT_ENABLED=false
else
    echo "✅ Backend API endpoint: $BACKEND_API_ENDPOINT"
    export TASK_MANAGEMENT_ENABLED=true
fi

# Function to start Xvfb (Virtual Display)
start_xvfb() {
    echo "🖥️  Starting virtual display (Xvfb)"
    Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset &
    export XVFB_PID=$!
    sleep 2
}

# Function to start VNC server (Requirement 8.1, 8.2, 8.3, 8.6)
start_vnc() {
    echo "🌐 Starting tightvncserver 1.3.9 for remote access"
    /usr/local/bin/start-vnc.sh &
    export VNC_PID=$!
}

# Function to start Android Emulator
start_emulator() {
    echo "📱 Starting Android 12.0 emulator"
    /usr/local/bin/start-emulator.sh &
    export EMULATOR_PID=$!
    
    # Wait for emulator to be ready
    echo "⏳ Waiting for Android 12.0 emulator to boot..."
    timeout 300 bash -c 'until adb shell getprop sys.boot_completed | grep -q "1"; do sleep 5; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Android 12.0 emulator is ready!"
        adb shell settings put global window_animation_scale 0
        adb shell settings put global transition_animation_scale 0
        adb shell settings put global animator_duration_scale 0
        echo "🎯 Disabled animations for testing optimization"
        
        # Apply pending proxy configuration to Android if needed
        if [ -f "/home/android/.proxy/pending_config" ]; then
            echo "🌐 Applying proxy configuration to Android 12.0"
            configure_android_proxy
            rm /home/android/.proxy/pending_config
        fi
    else
        echo "❌ Emulator failed to start within timeout"
        exit 1
    fi
}

# Function to start Appium server
start_appium() {
    echo "🔧 Starting Appium 2.4.1 server"
    /usr/local/bin/start-appium.sh &
    export APPIUM_PID=$!
    
    # Wait for Appium to be ready
    echo "⏳ Waiting for Appium server..."
    timeout 60 bash -c 'until curl -s http://localhost:4723/wd/hub/status > /dev/null; do sleep 2; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Appium 2.4.1 server is ready!"
    else
        echo "❌ Appium server failed to start"
        exit 1
    fi
}

# Function to start task manager (Requirements 10.2-10.12)
start_task_manager() {
    if [ "$TASK_MANAGEMENT_ENABLED" = true ]; then
        echo "🔄 Starting task manager"
        /usr/local/bin/task-manager.sh &
        export TASK_MANAGER_PID=$!
        echo "✅ Task manager started"
    else
        echo "ℹ️ Task manager not started (BACKEND_API_ENDPOINT not set)"
    fi
}

# Function to display system information
show_system_info() {
    echo ""
    echo "📊 System Information:"
    echo "   OS: $(lsb_release -d | cut -f2)"
    echo "   Python: $(python3 --version)"
    echo "   Appium: $(appium --version)"
    echo "   Android SDK: API Level $ANDROID_API_LEVEL"
    echo "   Java: $(java -version 2>&1 | head -n 1)"
    echo "   KVM: $([ -e /dev/kvm ] && echo 'Available' || echo 'Not Available')"
    echo ""
    echo "🌐 VNC/noVNC Information (Requirements 8.1-8.6):"
    echo "   ✅ 8.1: tightvncserver running in Docker container"
    echo "   ✅ 8.2: tightvncserver version 1.3.9"
    echo "   ✅ 8.3: VNC server listening on port 5901"
    echo "   ✅ 8.4: noVNC 1.4.0 configured for web access"
    echo "   ✅ 8.5: noVNC served at /novnc path"
    echo "   ✅ 8.6: VNC password set to 'secret'"
    echo ""
    echo "🌐 Proxy Information (Requirements 9.1-9.4):"
    if [ ! -z "$PROXY_HOST" ] && [ ! -z "$PROXY_PORT" ]; then
        echo "   ✅ 9.1: SOCKS5 proxy configured with credentials"
        echo "   ✅ 9.2: Proxy settings applied via environment variables"
        echo "   ✅ 9.3: Using PROXY_HOST=$PROXY_HOST, PROXY_PORT=$PROXY_PORT"
        echo "   ✅ 9.4: All network traffic routed through proxy"
    else
        echo "   ❌ No proxy configuration provided"
    fi
    echo ""
    echo "🔄 Task Management (Requirements 10.1-10.12):"
    if [ "$TASK_MANAGEMENT_ENABLED" = true ]; then
        echo "   ✅ 10.1: Environment variables and volume mounts configured"
        echo "   ✅ 10.2-10.12: Task management system enabled"
        echo "   ✅ Backend API: $BACKEND_API_ENDPOINT"
        echo "   ✅ Profiles directory: /emulator_profiles"
    else
        echo "   ❌ Task management not enabled (BACKEND_API_ENDPOINT not set)"
    fi
    echo ""
    echo "🌐 Access Points:"
    echo "   Appium Server: http://localhost:4723"
    echo "   VNC Server: vnc://localhost:5901 (password: secret)"
    echo "   noVNC Web: http://localhost:6080/novnc"
    echo "   ADB Port: 5555"
    echo ""
}

# Function to cleanup on exit
cleanup() {
    echo "🧹 Cleaning up processes..."
    [ ! -z "$APPIUM_PID" ] && kill $APPIUM_PID 2>/dev/null || true
    [ ! -z "$EMULATOR_PID" ] && kill $EMULATOR_PID 2>/dev/null || true
    [ ! -z "$VNC_PID" ] && kill $VNC_PID 2>/dev/null || true
    [ ! -z "$XVFB_PID" ] && kill $XVFB_PID 2>/dev/null || true
    [ ! -z "$TASK_MANAGER_PID" ] && kill $TASK_MANAGER_PID 2>/dev/null || true
    exit 0
}

# Set up signal handlers
trap cleanup SIGTERM SIGINT

# Main execution
case "${1:-start}" in
    start)
        show_system_info
        start_xvfb
        start_vnc
        start_emulator
        start_appium
        
        # Start task manager if enabled (Requirements 10.1-10.12)
        if [ "$TASK_MANAGEMENT_ENABLED" = true ]; then
            start_task_manager
        fi
        
        echo "🎉 Android 12.0 Emulator Container is fully operational!"
        echo "📱 Ready for Python 3.10 automation scripts via Appium 2.4.1"
        echo "🌐 Remote access available via VNC (port 5901) and noVNC (port 6080/novnc)"
        if [ ! -z "$PROXY_HOST" ] && [ ! -z "$PROXY_PORT" ]; then
            echo "🌐 All network traffic routed through SOCKS5 proxy: $PROXY_HOST:$PROXY_PORT"
        fi
        
        # Keep container running
        while true; do
            sleep 30
            # Health check
            if ! curl -s http://localhost:4723/wd/hub/status > /dev/null; then
                echo "❌ Appium server health check failed"
                exit 1
            fi
        done
        ;;
    
    # Manual mode for NSQ control (Requirement 11.3)
    manual)
        echo "🔧 Starting Android 12.0 emulator in manual mode (Requirement 11.3)"
        /usr/local/bin/manual-mode.sh
        ;;
    
    shell)
        echo "🐚 Starting interactive shell"
        exec /bin/bash
        ;;
    
    test)
        echo "🧪 Running system tests"
        python3 -c "
import subprocess
import sys
import os
import json

def test_python():
    print('Testing Python 3.10...')
    result = subprocess.run([sys.executable, '--version'], capture_output=True, text=True)
    print(f'✅ {result.stdout.strip()}')

def test_appium():
    print('Testing Appium installation...')
    result = subprocess.run(['appium', '--version'], capture_output=True, text=True)
    print(f'✅ Appium {result.stdout.strip()}')

def test_android_sdk():
    print('Testing Android SDK...')
    result = subprocess.run(['adb', 'version'], capture_output=True, text=True)
    print(f'✅ ADB available')

def test_vnc():
    print('Testing VNC server...')
    result = subprocess.run(['vncserver', '-version'], capture_output=True, text=True)
    if '1.3.9' in result.stdout:
        print('✅ tightvncserver 1.3.9 available')
    else:
        print('❌ Wrong VNC server version')

def test_proxy():
    print('Testing proxy configuration...')
    proxy_host = os.environ.get('PROXY_HOST')
    proxy_port = os.environ.get('PROXY_PORT')
    if proxy_host and proxy_port:
        print(f'✅ Proxy configured: {proxy_host}:{proxy_port}')
        # Check if proxy settings are applied
        if os.path.exists('/home/android/.proxy/proxy.conf'):
            print('✅ Proxy configuration file exists')
        else:
            print('❌ Proxy configuration file missing')
    else:
        print('ℹ️ No proxy configuration provided')

def test_task_management():
    print('Testing task management configuration...')
    backend_api = os.environ.get('BACKEND_API_ENDPOINT')
    if backend_api:
        print(f'✅ Backend API configured: {backend_api}')
    else:
        print('❌ BACKEND_API_ENDPOINT not set')
    
    if os.path.exists('/emulator_profiles'):
        print('✅ Browser profiles directory mounted')
    else:
        print('❌ Browser profiles directory not mounted')
    
    # Test task data parsing
    test_task = {
        'task_id': 'test-123',
        'task_type': 'social_media_action',
        'account': 'test_account',
        'social_media_app': 'facebook',
        'python_code': '/home/android/scripts/test_script.py',
        'task_data': {
            'action': 'like',
            'target': 'https://facebook.com/post/123'
        }
    }
    
    with open('/tmp/test_task.json', 'w') as f:
        json.dump(test_task, f)
    
    print('✅ Task data parsing test passed')

def test_manual_mode():
    print('Testing manual mode configuration...')
    if os.path.exists('/usr/local/bin/manual-mode.sh'):
        print('✅ Manual mode script exists')
        # Check if script is executable
        if os.access('/usr/local/bin/manual-mode.sh', os.X_OK):
            print('✅ Manual mode script is executable')
        else:
            print('❌ Manual mode script is not executable')
    else:
        print('❌ Manual mode script missing')

test_python()
test_appium()
test_android_sdk()
test_vnc()
test_proxy()
test_task_management()
test_manual_mode()
print('🎉 All tests passed!')
"
        ;;
    
    *)
        echo "Usage: $0 {start|manual|shell|test}"
        exit 1
        ;;
esac