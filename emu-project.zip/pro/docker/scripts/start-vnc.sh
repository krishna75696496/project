#!/bin/bash
# Start tightvncserver 1.3.9 for remote desktop access
# Implements Requirements 8.1-8.3 and 8.6

set -e

echo "🌐 Starting tightvncserver 1.3.9 for remote access"

# Create VNC directory
mkdir -p /home/android/.vnc

# Set VNC password to "secret" (Requirement 8.6)
echo "secret" | vncpasswd -f > /home/android/.vnc/passwd
chmod 600 /home/android/.vnc/passwd

# Start window manager
fluxbox &

# Kill any existing VNC servers
vncserver -kill :1 2>/dev/null || true

# Start tightvncserver on port 5901 (Requirement 8.3)
vncserver :1 -geometry 1920x1080 -depth 24 -localhost no -rfbport 5901 -rfbauth /home/android/.vnc/passwd

# Start noVNC web interface (Requirement 8.4 and 8.5)
cd /opt/novnc
./utils/launch.sh --vnc localhost:5901 --listen 6080 --web /novnc &

echo "✅ tightvncserver 1.3.9 started on port 5901"
echo "🌐 noVNC 1.4.0 web interface available at http://localhost:6080/novnc"