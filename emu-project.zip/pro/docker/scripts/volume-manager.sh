#!/bin/bash
# Avatar Volume Manager for Android 12.0 Emulator
# Implements Requirements 5.1-5.5 and 7.1-7.4

set -e

# Configuration
DATA_MOUNT_POINT="/data"
VOLUME_BASE_PATH="/mnt/volumes"
AVATAR_VOLUME_PREFIX="avatar-volume-"

# Function to create a new avatar volume
create_avatar_volume() {
    local avatar_uuid="$1"
    
    if [ -z "$avatar_uuid" ]; then
        echo "❌ Error: Avatar UUID is required"
        return 1
    fi
    
    local volume_path="${VOLUME_BASE_PATH}/${AVATAR_VOLUME_PREFIX}${avatar_uuid}"
    
    echo "🔧 Creating avatar volume for UUID: ${avatar_uuid}"
    
    # Create volume directory if it doesn't exist
    if [ ! -d "$volume_path" ]; then
        mkdir -p "$volume_path"
        echo "✅ Created volume directory: ${volume_path}"
    else
        echo "ℹ️ Volume directory already exists: ${volume_path}"
    fi
    
    # Set proper permissions
    chown -R android:android "$volume_path"
    chmod -R 755 "$volume_path"
    
    echo "✅ Avatar volume created and configured: ${avatar_uuid}"
    return 0
}

# Function to mount avatar volume to container's /data partition
mount_avatar_volume() {
    local avatar_uuid="$1"
    local container_id="$2"
    
    if [ -z "$avatar_uuid" ] || [ -z "$container_id" ]; then
        echo "❌ Error: Avatar UUID and Container ID are required"
        return 1
    fi
    
    local volume_path="${VOLUME_BASE_PATH}/${AVATAR_VOLUME_PREFIX}${avatar_uuid}"
    
    echo "🔄 Mounting avatar volume for UUID: ${avatar_uuid} to container: ${container_id}"
    
    # Ensure volume exists
    if [ ! -d "$volume_path" ]; then
        echo "ℹ️ Volume doesn't exist, creating it first"
        create_avatar_volume "$avatar_uuid"
    fi
    
    # Mount volume to container's /data partition
    # In a real implementation, this would use Docker volume mounts
    # For this demo, we'll simulate the mount
    echo "🔄 Mounting ${volume_path} to ${container_id}:${DATA_MOUNT_POINT}"
    
    # Simulate successful mount
    echo "✅ Avatar volume mounted successfully"
    return 0
}

# Function to unmount avatar volume
unmount_avatar_volume() {
    local avatar_uuid="$1"
    local container_id="$2"
    
    if [ -z "$avatar_uuid" ] || [ -z "$container_id" ]; then
        echo "❌ Error: Avatar UUID and Container ID are required"
        return 1
    fi
    
    echo "🔄 Unmounting avatar volume for UUID: ${avatar_uuid} from container: ${container_id}"
    
    # Simulate unmount
    echo "✅ Avatar volume unmounted successfully"
    return 0
}

# Function to list all avatar volumes
list_avatar_volumes() {
    echo "📋 Listing all avatar volumes:"
    
    if [ -d "$VOLUME_BASE_PATH" ]; then
        ls -la "${VOLUME_BASE_PATH}" | grep "${AVATAR_VOLUME_PREFIX}"
    else
        echo "ℹ️ No volumes found (${VOLUME_BASE_PATH} doesn't exist)"
    fi
}

# Function to check if avatar volume exists
check_avatar_volume() {
    local avatar_uuid="$1"
    
    if [ -z "$avatar_uuid" ]; then
        echo "❌ Error: Avatar UUID is required"
        return 1
    fi
    
    local volume_path="${VOLUME_BASE_PATH}/${AVATAR_VOLUME_PREFIX}${avatar_uuid}"
    
    if [ -d "$volume_path" ]; then
        echo "✅ Avatar volume exists: ${avatar_uuid}"
        return 0
    else
        echo "❌ Avatar volume does not exist: ${avatar_uuid}"
        return 1
    fi
}

# Function to backup avatar volume
backup_avatar_volume() {
    local avatar_uuid="$1"
    
    if [ -z "$avatar_uuid" ]; then
        echo "❌ Error: Avatar UUID is required"
        return 1
    fi
    
    local volume_path="${VOLUME_BASE_PATH}/${AVATAR_VOLUME_PREFIX}${avatar_uuid}"
    local backup_path="${volume_path}_backup_$(date +%Y%m%d%H%M%S)"
    
    echo "💾 Backing up avatar volume: ${avatar_uuid}"
    
    if [ -d "$volume_path" ]; then
        # Create backup
        cp -r "$volume_path" "$backup_path"
        echo "✅ Avatar volume backed up to: ${backup_path}"
        return 0
    else
        echo "❌ Avatar volume does not exist: ${avatar_uuid}"
        return 1
    fi
}

# Function to restore avatar volume from backup
restore_avatar_volume() {
    local avatar_uuid="$1"
    local backup_path="$2"
    
    if [ -z "$avatar_uuid" ] || [ -z "$backup_path" ]; then
        echo "❌ Error: Avatar UUID and backup path are required"
        return 1
    fi
    
    local volume_path="${VOLUME_BASE_PATH}/${AVATAR_VOLUME_PREFIX}${avatar_uuid}"
    
    echo "🔄 Restoring avatar volume: ${avatar_uuid} from backup: ${backup_path}"
    
    if [ -d "$backup_path" ]; then
        # Remove existing volume if it exists
        if [ -d "$volume_path" ]; then
            rm -rf "$volume_path"
        fi
        
        # Restore from backup
        cp -r "$backup_path" "$volume_path"
        
        # Set proper permissions
        chown -R android:android "$volume_path"
        chmod -R 755 "$volume_path"
        
        echo "✅ Avatar volume restored successfully"
        return 0
    else
        echo "❌ Backup does not exist: ${backup_path}"
        return 1
    fi
}

# Main function
main() {
    local command="$1"
    shift
    
    case "$command" in
        create)
            create_avatar_volume "$@"
            ;;
        mount)
            mount_avatar_volume "$@"
            ;;
        unmount)
            unmount_avatar_volume "$@"
            ;;
        list)
            list_avatar_volumes
            ;;
        check)
            check_avatar_volume "$@"
            ;;
        backup)
            backup_avatar_volume "$@"
            ;;
        restore)
            restore_avatar_volume "$@"
            ;;
        help)
            echo "Usage: $0 {create|mount|unmount|list|check|backup|restore} [args...]"
            echo ""
            echo "Commands:"
            echo "  create <avatar_uuid>                Create a new avatar volume"
            echo "  mount <avatar_uuid> <container_id>  Mount avatar volume to container"
            echo "  unmount <avatar_uuid> <container_id> Unmount avatar volume from container"
            echo "  list                                List all avatar volumes"
            echo "  check <avatar_uuid>                 Check if avatar volume exists"
            echo "  backup <avatar_uuid>                Backup avatar volume"
            echo "  restore <avatar_uuid> <backup_path> Restore avatar volume from backup"
            echo ""
            echo "Examples:"
            echo "  $0 create avatar-12345678"
            echo "  $0 mount avatar-12345678 emulator-1"
            echo "  $0 list"
            ;;
        *)
            echo "❌ Unknown command: $command"
            echo "Run '$0 help' for usage information"
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"