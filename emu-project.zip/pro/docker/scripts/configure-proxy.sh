#!/bin/bash
# Configure SOCKS5 Proxy for Android 12.0 Emulator
# Implements Requirements 9.1-9.4

set -e

echo "🌐 Configuring SOCKS5 proxy for Android 12.0 emulator"

# Check if proxy environment variables are set (Requirement 9.3)
if [ -z "$PROXY_HOST" ] || [ -z "$PROXY_PORT" ]; then
    echo "⚠️  Proxy configuration skipped: PROXY_HOST or PROXY_PORT not set"
    exit 0
fi

# Log proxy configuration
echo "🔧 Setting up SOCKS5 proxy with the following parameters:"
echo "   Host: $PROXY_HOST"
echo "   Port: $PROXY_PORT"
echo "   User: ${PROXY_USER:-<not set>}"
echo "   Auth: ${PROXY_PASS:+<set>}"

# Create proxy configuration directory
mkdir -p /home/android/.proxy

# Configure system-wide proxy settings (Requirement 9.1, 9.2)
# Create a proxy.conf file
cat > /home/android/.proxy/proxy.conf << EOF
# SOCKS5 Proxy Configuration
proxy_type=socks5
proxy_host=$PROXY_HOST
proxy_port=$PROXY_PORT
EOF

# Add authentication if credentials are provided
if [ ! -z "$PROXY_USER" ] && [ ! -z "$PROXY_PASS" ]; then
    echo "proxy_user=$PROXY_USER" >> /home/android/.proxy/proxy.conf
    echo "proxy_pass=$PROXY_PASS" >> /home/android/.proxy/proxy.conf
fi

# Set proper permissions
chmod 600 /home/android/.proxy/proxy.conf
chown -R android:android /home/android/.proxy

# Configure Android emulator to use proxy (Requirement 9.4)
# This will be applied when the emulator starts
echo "🔧 Configuring Android 12.0 emulator to use SOCKS5 proxy"

# Update emulator configuration to use proxy
EMULATOR_CONF_DIR="/home/android/.android/avd/Android_12_API_31.avd"
echo "http.proxy=$PROXY_HOST:$PROXY_PORT" >> $EMULATOR_CONF_DIR/config.ini

# Configure ADB to use proxy
echo "🔧 Configuring ADB to use SOCKS5 proxy"
cat > /home/android/.android/adb_proxy.sh << EOF
#!/bin/bash
export https_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
export http_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
export all_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
EOF
chmod +x /home/android/.android/adb_proxy.sh

# Configure system-wide proxy for all applications (Requirement 9.4)
cat > /etc/profile.d/proxy.sh << EOF
#!/bin/bash
export https_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
export http_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
export all_proxy=socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
EOF
chmod +x /etc/profile.d/proxy.sh

# Configure npm to use proxy
if command -v npm &> /dev/null; then
    echo "🔧 Configuring npm to use SOCKS5 proxy"
    npm config set proxy socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
    npm config set https-proxy socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT
fi

# Configure apt to use proxy
echo "🔧 Configuring apt to use SOCKS5 proxy"
cat > /etc/apt/apt.conf.d/proxy.conf << EOF
Acquire::http::Proxy "socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT";
Acquire::https::Proxy "socks5://${PROXY_USER:+$PROXY_USER:$PROXY_PASS@}$PROXY_HOST:$PROXY_PORT";
EOF

# Configure Android system proxy settings via adb when emulator is running
configure_android_proxy() {
    # Wait for emulator to be fully booted
    echo "⏳ Waiting for Android 12.0 emulator to be ready for proxy configuration..."
    timeout 300 bash -c 'until adb shell getprop sys.boot_completed | grep -q "1"; do sleep 5; done'
    
    if [ $? -eq 0 ]; then
        echo "✅ Android 12.0 emulator is ready, configuring proxy settings"
        
        # Set global proxy settings for Android
        adb shell settings put global http_proxy "${PROXY_HOST}:${PROXY_PORT}"
        
        # For Android 12.0, we need to configure proxy credentials in a special way
        if [ ! -z "$PROXY_USER" ] && [ ! -z "$PROXY_PASS" ]; then
            # Create a proxy credentials script
            cat > /tmp/proxy_creds.sh << EOF
am start -n com.android.settings/.ProxySelector
# Wait for UI to load
sleep 2
# Input proxy credentials
input text "${PROXY_USER}"
input keyevent 61
input text "${PROXY_PASS}"
input keyevent 66
EOF
            # Push and execute the script
            adb push /tmp/proxy_creds.sh /data/local/tmp/
            adb shell chmod 755 /data/local/tmp/proxy_creds.sh
            adb shell sh /data/local/tmp/proxy_creds.sh
            
            # Clean up
            rm /tmp/proxy_creds.sh
            adb shell rm /data/local/tmp/proxy_creds.sh
        fi
        
        echo "✅ Android 12.0 proxy settings configured successfully"
    else
        echo "❌ Emulator not ready within timeout, proxy settings not applied"
    fi
}

# This function will be called from entrypoint.sh after emulator starts
echo "configure_android_proxy" > /home/android/.proxy/pending_config

echo "✅ SOCKS5 proxy configuration completed"
echo "🌐 All network traffic will be routed through the proxy"