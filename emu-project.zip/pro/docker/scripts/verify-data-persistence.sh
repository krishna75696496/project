#!/bin/bash
# Verify Data Persistence Script for Android 12.0 Emulator
# Tests Requirements 5.1-5.5 and 7.1-7.4

set -e

# Configuration
AVATAR_UUID=${AVATAR_UUID:-"default-avatar"}
AVATAR_VOLUME_PATH="/mnt/volumes/avatar-volume-${AVATAR_UUID}"
DATA_PARTITION="/data"

echo "🔍 Verifying data persistence for avatar UUID: ${AVATAR_UUID}"

# Check if avatar volume exists
if [ ! -d "$AVATAR_VOLUME_PATH" ]; then
    echo "❌ Avatar volume does not exist: ${AVATAR_VOLUME_PATH}"
    exit 1
fi

# Check if persistence marker exists
if [ -f "${AVATAR_VOLUME_PATH}/persistence_marker.txt" ]; then
    echo "✅ Found persistence marker:"
    cat "${AVATAR_VOLUME_PATH}/persistence_marker.txt"
else
    echo "❌ No persistence marker found"
    exit 1
fi

# Check if social media apps are installed
echo "🔍 Checking social media apps..."
for app in "com.facebook.katana" "com.twitter.android" "com.instagram.android" "com.linkedin.android"; do
    if adb shell pm list packages | grep -q "$app"; then
        echo "✅ $app is installed"
        
        # Check app data
        app_data_size=$(adb shell du -s /data/data/$app 2>/dev/null | awk '{print $1}')
        if [ -n "$app_data_size" ] && [ "$app_data_size" -gt 0 ]; then
            echo "   Data size: ${app_data_size}KB"
        else
            echo "   No app data found"
        fi
    else
        echo "❌ $app is not installed"
    fi
done

# Verify data isolation
echo "🔍 Verifying data isolation between avatars..."
other_volumes=$(find /mnt/volumes -maxdepth 1 -name "avatar-volume-*" | grep -v "$AVATAR_UUID" | wc -l)
if [ "$other_volumes" -gt 0 ]; then
    echo "⚠️ Found $other_volumes other avatar volumes"
    echo "   Note: In production, these should not be accessible from this container"
else
    echo "✅ No other avatar volumes accessible (proper isolation)"
fi

# Create a new persistence marker
echo "Creating new persistence marker: $(date)" > "${AVATAR_VOLUME_PATH}/persistence_marker.txt"
echo "Container ID: $(hostname)" >> "${AVATAR_VOLUME_PATH}/persistence_marker.txt"

echo "✅ Data persistence verification complete"
echo "   Avatar UUID: ${AVATAR_UUID}"
echo "   Volume Path: ${AVATAR_VOLUME_PATH}"
echo "   Data Partition: ${DATA_PARTITION}"

# Return success
exit 0