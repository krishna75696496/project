#!/usr/bin/env python3.10
"""
App Loading Time Test for Android 12.0 Emulator
Tests Requirement 12.4: Social media apps should load within 5 seconds
"""

import time
import statistics
import subprocess
import logging
from typing import List, Dict, Any

import uiautomator2 as u2
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('app_loading_test')

class AppLoadingTest:
    """Test app loading time of social media apps on Android 12.0 emulator"""
    
    def __init__(self):
        """Initialize test"""
        self.driver = None
        self.u2_device = None
        self.results = {
            'app_loading_times': {},
            'average_loading_time': 0,
            'max_loading_time': 0,
            'passed': False
        }
        
        # Social media apps to test
        self.social_apps = [
            {"name": "Facebook", "package": "com.facebook.katana", "activity": ".LoginActivity"},
            {"name": "Instagram", "package": "com.instagram.android", "activity": ".activity.MainTabActivity"},
            {"name": "Twitter", "package": "com.twitter.android", "activity": ".StartActivity"},
            {"name": "WhatsApp", "package": "com.whatsapp", "activity": ".Main"}
        ]
    
    def setup(self) -> None:
        """Set up test environment"""
        logger.info("Setting up app loading time test")
        
        # Connect with Appium
        options = UiAutomator2Options()
        options.platform_name = "Android"
        options.platform_version = "12.0"
        options.device_name = "Android_12_API_31"
        options.automation_name = "UiAutomator2"
        options.no_reset = True
        
        self.driver = webdriver.Remote("http://localhost:4723", options=options)
        logger.info("Connected to Appium")
        
        # Connect with uiautomator2 for direct measurements
        self.u2_device = u2.connect()
        logger.info("Connected to uiautomator2")
        
        # Go to home screen
        self.driver.press_keycode(3)  # HOME key
        time.sleep(1)
        
        # Close all background apps
        self.u2_device.app_clear_all()
        time.sleep(1)
    
    def verify_app_installed(self, package_name: str) -> bool:
        """Verify if app is installed"""
        try:
            result = subprocess.run(
                ["adb", "shell", "pm", "list", "packages", package_name],
                capture_output=True,
                text=True,
                check=True
            )
            return package_name in result.stdout
        except Exception as e:
            logger.error(f"Error checking if {package_name} is installed: {e}")
            return False
    
    def test_app_loading_time(self, app: Dict[str, str], iterations: int = 3) -> List[float]:
        """Test loading time for a specific app"""
        logger.info(f"Testing loading time for {app['name']} ({iterations} iterations)")
        
        # Verify app is installed
        if not self.verify_app_installed(app['package']):
            logger.warning(f"{app['name']} is not installed, skipping test")
            return []
        
        loading_times = []
        
        for i in range(iterations):
            # Force stop app before testing
            try:
                self.driver.terminate_app(app['package'])
                time.sleep(1)
            except:
                pass
            
            # Clear app from recent apps
            self.u2_device.app_clear(app['package'])
            time.sleep(1)
            
            # Measure app loading time
            try:
                logger.info(f"Starting {app['name']} (iteration {i+1})")
                
                # Start timing
                start_time = time.time()
                
                # Launch app
                self.driver.activate_app(app['package'])
                
                # Wait for app to load
                # Different apps have different indicators of being fully loaded
                # This is a simplified approach
                try:
                    # Wait for any UI element to appear
                    WebDriverWait(self.driver, 10).until(
                        lambda driver: len(driver.find_elements(AppiumBy.CLASS_NAME, "android.widget.TextView")) > 0 or
                                      len(driver.find_elements(AppiumBy.CLASS_NAME, "android.widget.ImageView")) > 0
                    )
                    
                    # Additional wait for app-specific elements
                    if app['package'] == "com.facebook.katana":
                        WebDriverWait(self.driver, 10).until(
                            lambda driver: "feed" in driver.page_source.lower() or 
                                          "login" in driver.page_source.lower()
                        )
                    elif app['package'] == "com.instagram.android":
                        WebDriverWait(self.driver, 10).until(
                            lambda driver: "feed" in driver.page_source.lower() or 
                                          "login" in driver.page_source.lower()
                        )
                    
                    # End timing
                    end_time = time.time()
                    loading_time = (end_time - start_time) * 1000  # Convert to milliseconds
                    
                    loading_times.append(loading_time)
                    logger.info(f"{app['name']} loading time: {loading_time:.2f}ms")
                    
                except Exception as e:
                    logger.error(f"Error waiting for {app['name']} to load: {e}")
                
                # Close app
                self.driver.press_keycode(3)  # HOME key
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Error testing {app['name']}: {e}")
        
        # Calculate statistics
        if loading_times:
            avg_time = statistics.mean(loading_times)
            max_time = max(loading_times)
            logger.info(f"Average {app['name']} loading time: {avg_time:.2f}ms")
            logger.info(f"Maximum {app['name']} loading time: {max_time:.2f}ms")
        
        return loading_times
    
    def run_tests(self) -> Dict[str, Any]:
        """Run all app loading tests"""
        try:
            self.setup()
            
            # Test each social media app
            for app in self.social_apps:
                loading_times = self.test_app_loading_time(app)
                if loading_times:
                    self.results['app_loading_times'][app['name']] = loading_times
            
            # Calculate overall results
            all_times = []
            for app_name, times in self.results['app_loading_times'].items():
                all_times.extend(times)
            
            if all_times:
                avg_time = statistics.mean(all_times)
                max_time = max(all_times)
                
                self.results['average_loading_time'] = avg_time
                self.results['max_loading_time'] = max_time
                
                # Requirement 12.4: Social media apps should load within 5 seconds (5000ms)
                self.results['passed'] = avg_time < 5000
                
                logger.info(f"Overall average loading time: {avg_time:.2f}ms")
                logger.info(f"Overall maximum loading time: {max_time:.2f}ms")
                logger.info(f"Test passed: {self.results['passed']}")
            
        except Exception as e:
            logger.error(f"Error running tests: {e}")
        finally:
            if self.driver:
                self.driver.quit()
            
            return self.results

def main():
    """Main function"""
    logger.info("Starting app loading time test for Android 12.0 emulator")
    
    # Check if emulator is running
    try:
        result = subprocess.run(
            ["adb", "devices"], 
            capture_output=True, 
            text=True, 
            check=True
        )
        if "emulator" not in result.stdout:
            logger.error("No emulator found. Please start the emulator first.")
            return
    except Exception as e:
        logger.error(f"Error checking emulator status: {e}")
        return
    
    # Run tests
    test = AppLoadingTest()
    results = test.run_tests()
    
    # Print summary
    print("\n" + "="*50)
    print("APP LOADING TIME TEST RESULTS (Requirement 12.4)")
    print("="*50)
    print(f"Average loading time: {results['average_loading_time']:.2f}ms ({results['average_loading_time']/1000:.2f}s)")
    print(f"Maximum loading time: {results['max_loading_time']:.2f}ms ({results['max_loading_time']/1000:.2f}s)")
    print(f"Target: <5000ms (5s)")
    print(f"Test passed: {'✅ YES' if results['passed'] else '❌ NO'}")
    
    # Print per-app results
    print("\nPer-app results:")
    for app_name, times in results['app_loading_times'].items():
        avg = statistics.mean(times)
        print(f"  {app_name}: {avg:.2f}ms ({avg/1000:.2f}s)")
    
    print("="*50)
    
    # Return appropriate exit code
    return 0 if results['passed'] else 1

if __name__ == "__main__":
    main()