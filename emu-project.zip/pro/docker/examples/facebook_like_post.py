#!/usr/bin/env python3.10
"""
Facebook Like Post Automation Script
For Android 12.0 Emulator with Appium 2.4.1

This script demonstrates task execution for Requirement 10.10
"""

import os
import sys
import json
import time
import argparse
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/var/log/emulator_task.log')
    ]
)
logger = logging.getLogger('facebook_automation')

class FacebookAutomation:
    """Facebook automation for Android 12.0 using Appium 2.4.1"""
    
    def __init__(self, task_data: Dict[str, Any]):
        """Initialize with task data"""
        self.task_data = task_data
        self.task_id = task_data.get('task_id', 'unknown')
        self.account = task_data.get('account', 'unknown')
        self.driver = None
        self.results = {
            'task_id': self.task_id,
            'success': False,
            'timestamp': datetime.now().isoformat(),
            'actions_performed': [],
            'errors': [],
            'screenshots': []
        }
    
    def setup_driver(self) -> None:
        """Initialize Appium driver for Android 12.0"""
        logger.info(f"Setting up Appium driver for task {self.task_id}")
        
        options = UiAutomator2Options()
        options.platform_name = "Android"
        options.platform_version = "12.0"
        options.device_name = "Android_12_API_31"
        options.automation_name = "UiAutomator2"
        options.app_package = "com.facebook.katana"
        options.app_activity = "com.facebook.katana.LoginActivity"
        options.no_reset = True  # Use existing app state
        
        try:
            self.driver = webdriver.Remote("http://localhost:4723", options=options)
            logger.info("Appium driver connected successfully")
            self.results['actions_performed'].append("Connected to Facebook app")
        except Exception as e:
            error_msg = f"Failed to connect to Appium: {str(e)}"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            raise
    
    def navigate_to_post(self) -> bool:
        """Navigate to the target post URL"""
        target_url = self.task_data.get('task_data', {}).get('target_url')
        if not target_url:
            error_msg = "No target URL provided in task data"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            return False
        
        logger.info(f"Navigating to post: {target_url}")
        
        try:
            # This is a simplified example - in a real implementation,
            # you would need to parse the URL and navigate through the Facebook app UI
            
            # For demonstration, we'll simulate navigation
            logger.info("Simulating navigation to post")
            
            # Wait for Facebook to load
            WebDriverWait(self.driver, 30).until(
                EC.presence_of_element_located((AppiumBy.ID, "com.facebook.katana:id/bookmarks_tab"))
            )
            
            # Navigate to the search bar
            search_button = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, "Search")
            search_button.click()
            
            # Enter the URL
            search_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((AppiumBy.ID, "com.facebook.katana:id/search_box"))
            )
            search_input.send_keys(target_url)
            
            # Press enter
            self.driver.press_keycode(66)  # Enter key
            
            # Wait for content to load
            time.sleep(5)
            
            # Take screenshot if requested
            if self.task_data.get('task_data', {}).get('screenshot', False):
                self.take_screenshot("post_navigation")
            
            self.results['actions_performed'].append(f"Navigated to post: {target_url}")
            return True
            
        except Exception as e:
            error_msg = f"Failed to navigate to post: {str(e)}"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            return False
    
    def perform_like_action(self) -> bool:
        """Like the post"""
        logger.info("Attempting to like the post")
        
        try:
            # Find and click the like button
            # This is a simplified example - in a real implementation,
            # you would need to handle different UI states
            
            # Wait for the like button to be visible
            like_button = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Like')]"))
            )
            
            # Check if already liked
            if "Liked" in like_button.get_attribute("content-desc"):
                logger.info("Post is already liked")
                self.results['actions_performed'].append("Post was already liked")
                return True
            
            # Click the like button
            like_button.click()
            logger.info("Clicked like button")
            
            # Wait for the like to register
            wait_time = self.task_data.get('task_data', {}).get('wait_after_action', 3)
            time.sleep(wait_time)
            
            # Take screenshot if requested
            if self.task_data.get('task_data', {}).get('screenshot', False):
                self.take_screenshot("after_like")
            
            self.results['actions_performed'].append("Liked the post")
            return True
            
        except Exception as e:
            error_msg = f"Failed to like post: {str(e)}"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            return False
    
    def add_comment(self) -> bool:
        """Add a comment to the post if specified"""
        comment_text = self.task_data.get('task_data', {}).get('comment_text')
        if not comment_text:
            logger.info("No comment text provided, skipping comment")
            return True
        
        logger.info(f"Adding comment: {comment_text}")
        
        try:
            # Find and click the comment button
            comment_button = self.driver.find_element(AppiumBy.XPATH, 
                "//android.widget.Button[contains(@content-desc, 'Comment')]")
            comment_button.click()
            
            # Wait for comment field to appear
            comment_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((AppiumBy.ID, "com.facebook.katana:id/comment_composer_edit_text"))
            )
            
            # Enter comment text
            comment_input.send_keys(comment_text)
            
            # Submit comment
            post_button = self.driver.find_element(AppiumBy.ID, "com.facebook.katana:id/comment_composer_post_button")
            post_button.click()
            
            # Wait for the comment to post
            wait_time = self.task_data.get('task_data', {}).get('wait_after_action', 3)
            time.sleep(wait_time)
            
            # Take screenshot if requested
            if self.task_data.get('task_data', {}).get('screenshot', False):
                self.take_screenshot("after_comment")
            
            self.results['actions_performed'].append(f"Added comment: {comment_text}")
            return True
            
        except Exception as e:
            error_msg = f"Failed to add comment: {str(e)}"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            return False
    
    def take_screenshot(self, name: str) -> None:
        """Take a screenshot and save it"""
        if not self.driver:
            return
        
        try:
            timestamp = int(time.time())
            filename = f"/home/android/logs/{self.task_id}_{name}_{timestamp}.png"
            self.driver.save_screenshot(filename)
            logger.info(f"Screenshot saved: {filename}")
            self.results['screenshots'].append(filename)
        except Exception as e:
            logger.error(f"Failed to take screenshot: {str(e)}")
    
    def execute_task(self) -> Dict[str, Any]:
        """Execute the Facebook task"""
        logger.info(f"Executing Facebook task {self.task_id} for account {self.account}")
        
        try:
            # Setup Appium driver
            self.setup_driver()
            
            # Navigate to the post
            if not self.navigate_to_post():
                return self.results
            
            # Perform the like action
            if not self.perform_like_action():
                return self.results
            
            # Add comment if specified
            self.add_comment()
            
            # Mark task as successful
            self.results['success'] = True
            logger.info(f"Task {self.task_id} completed successfully")
            
        except Exception as e:
            error_msg = f"Task execution failed: {str(e)}"
            logger.error(error_msg)
            self.results['errors'].append(error_msg)
            
        finally:
            # Clean up
            if self.driver:
                self.driver.quit()
                logger.info("Appium driver closed")
            
            return self.results

def main():
    """Main function to parse arguments and execute task"""
    parser = argparse.ArgumentParser(description='Facebook Like Post Automation')
    parser.add_argument('--task-data', required=True, help='Path to task data JSON file')
    parser.add_argument('--results-file', required=True, help='Path to save results JSON')
    args = parser.parse_args()
    
    # Load task data
    try:
        with open(args.task_data, 'r') as f:
            task_data = json.load(f)
    except Exception as e:
        logger.error(f"Failed to load task data: {str(e)}")
        sys.exit(1)
    
    # Execute task
    automation = FacebookAutomation(task_data)
    results = automation.execute_task()
    
    # Save results
    try:
        with open(args.results_file, 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"Results saved to {args.results_file}")
    except Exception as e:
        logger.error(f"Failed to save results: {str(e)}")
        sys.exit(1)
    
    # Exit with success/failure code
    sys.exit(0 if results['success'] else 1)

if __name__ == "__main__":
    main()