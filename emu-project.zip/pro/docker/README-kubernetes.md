# Kubernetes Deployment for Android 12.0 Emulator - Requirements 12.1-12.4

## ✅ **Requirements Compliance**

### **✅ Requirement 12.1: Kubernetes Deployability**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Docker image tested and deployable on Kubernetes
- **Implementation**: Complete Kubernetes deployment YAML with all necessary resources

### **✅ Requirement 12.2: RAM Optimization**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Docker image optimized for RAM usage
- **Implementation**:
  - Minimized installed packages
  - Optimized Android emulator settings
  - Memory-efficient container configuration
  - Kubernetes memory optimization annotations

### **✅ Requirement 12.3: Kubernetes Configuration**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Complete Kubernetes deployment with required specifications
- **Implementation**:
  - Resource requests: 2 cores CPU, 4GB memory
  - Resource limits: 4 cores CPU, 8GB memory
  - Liveness probe: TCP check on VNC port 5901
  - Readiness probe: Check for Android emulator boot completion

### **✅ Requirement 12.4: Performance Metrics**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Emulator configured to meet performance targets
- **Implementation**:
  - UI responsiveness optimizations (animations disabled)
  - App loading time optimizations
  - Resource allocation tuned for performance

## 🚀 **Deployment Instructions**

### **1. Prepare Kubernetes Cluster**
Ensure your Kubernetes cluster has nodes with:
- KVM support
- Sufficient resources (at least 4 CPU cores and 8GB RAM per node)
- Storage class for persistent volumes

### **2. Create Namespace (Optional)**
```bash
kubectl create namespace android-emulators
kubectl config set-context --current --namespace=android-emulators
```

### **3. Apply Kubernetes Configuration**
```bash
kubectl apply -f android-emulator-deployment.yaml
```

### **4. Verify Deployment**
```bash
# Check deployment status
kubectl get deployments

# Check pods
kubectl get pods

# Check services
kubectl get services

# Check persistent volume claims
kubectl get pvc
```

### **5. Access the Emulator**
```bash
# Port forward to access VNC
kubectl port-forward service/android-emulator-service 5901:5901

# Port forward to access noVNC web interface
kubectl port-forward service/android-emulator-service 6080:6080

# Port forward to access Appium
kubectl port-forward service/android-emulator-service 4723:4723
```

## 🔧 **Resource Configuration**

### **CPU and Memory Allocation (Requirement 12.3)**
```yaml
resources:
  requests:
    memory: "4Gi"  # 4GB memory request
    cpu: "2"       # 2 CPU cores request
  limits:
    memory: "8Gi"  # 8GB memory limit
    cpu: "4"       # 4 CPU cores limit
```

### **Health Checks (Requirement 12.3)**
```yaml
livenessProbe:
  tcpSocket:
    port: 5901  # Check if VNC server is responsive
  initialDelaySeconds: 120
  periodSeconds: 30
  timeoutSeconds: 10
  failureThreshold: 3

readinessProbe:
  exec:
    command:
    - sh
    - -c
    - "adb shell getprop sys.boot_completed | grep -q 1"  # Check if Android emulator is ready
  initialDelaySeconds: 180
  periodSeconds: 30
  timeoutSeconds: 10
  failureThreshold: 3
```

## 🔍 **Performance Optimizations (Requirement 12.2, 12.4)**

### **RAM Usage Optimizations**
- Disabled unnecessary Android services
- Reduced emulator heap size
- Optimized container base image
- Removed unnecessary packages
- Configured memory-efficient settings

### **UI Responsiveness Optimizations**
To achieve <200ms UI interaction response time:
- Disabled Android animations
- Optimized GPU acceleration
- Configured optimal CPU priority
- Reduced background processes

### **App Loading Optimizations**
To achieve <5s app loading time:
- Pre-installed social media apps
- Optimized app data storage
- Configured app optimization flags
- Reduced system overhead during app launch

## 🔄 **Scaling Configuration**

### **Horizontal Pod Autoscaler**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: android-emulator-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: android-emulator
  minReplicas: 1
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

## 🔒 **Security Configuration**

### **Privileged Mode**
The container requires privileged mode for KVM access:
```yaml
securityContext:
  privileged: true
  capabilities:
    add:
    - SYS_ADMIN
    - NET_ADMIN
```

### **Secret Management**
Sensitive data like proxy credentials are stored in Kubernetes secrets:
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: proxy-credentials
type: Opaque
data:
  host: MTkyLjE2OC4xLjEwMA==  # base64 encoded
  port: MTA4MA==              # base64 encoded
  username: cHJveHl1c2Vy        # base64 encoded
  password: cHJveHlwYXNzd29yZA==  # base64 encoded
```

## 📊 **Performance Metrics Verification (Requirement 12.4)**

### **UI Responsiveness Testing**
To verify <200ms UI interaction response:
```bash
# Connect to the pod
kubectl exec -it <pod-name> -- bash

# Run UI response test
python3.10 /home/android/scripts/test_ui_responsiveness.py
```

### **App Loading Time Testing**
To verify <5s app loading time:
```bash
# Connect to the pod
kubectl exec -it <pod-name> -- bash

# Run app loading test
python3.10 /home/android/scripts/test_app_loading.py
```

## 🐛 **Troubleshooting**

### **Common Issues**

#### **Pod Stuck in Pending State**
```bash
# Check pod status
kubectl describe pod <pod-name>

# Common causes:
# - Insufficient resources
# - PVC binding issues
# - Node selector constraints
```

#### **Readiness Probe Failures**
```bash
# Check pod events
kubectl describe pod <pod-name>

# Check container logs
kubectl logs <pod-name>

# Common causes:
# - Emulator not booting properly
# - ADB connection issues
# - KVM access problems
```

#### **Performance Issues**
```bash
# Check resource usage
kubectl top pod <pod-name>

# Check node resource allocation
kubectl describe node <node-name>

# Common causes:
# - Node overcommitment
# - Resource contention
# - Insufficient memory or CPU
```

## 🔍 **Verification Commands**

### **Check Resource Allocation**
```bash
kubectl describe pod <pod-name> | grep -A 15 "Containers:"
```

### **Verify Health Checks**
```bash
kubectl describe pod <pod-name> | grep -A 20 "Liveness:"
kubectl describe pod <pod-name> | grep -A 20 "Readiness:"
```

### **Test VNC Connection**
```bash
kubectl port-forward <pod-name> 5901:5901
# Then connect with VNC client to localhost:5901
```

### **Test Appium Connection**
```bash
kubectl port-forward <pod-name> 4723:4723
curl http://localhost:4723/wd/hub/status
```

---

**✅ Requirements 12.1-12.4 Fully Implemented**: This Kubernetes deployment configuration provides a complete solution for deploying the Android 12.0 emulator on Kubernetes with all required resource allocations, health checks, and performance optimizations.