#!/bin/bash
# Build script for Android 12.0 Emulator with Avatar Persistence
# Implements Requirements 5.1-5.5 and 7.1-7.4

set -e

echo "🏗️  Building Android 12.0 Emulator with Avatar Persistence"
echo "📱 Ubuntu 20.04 + Python 3.10 + Appium 2.4.1"
echo "💾 Avatar/Session Data Persistence Enabled"

# Configuration
IMAGE_NAME="android-emulator-avatar"
IMAGE_TAG="ubuntu20.04-avatar-persistence"
FULL_IMAGE_NAME="${IMAGE_NAME}:${IMAGE_TAG}"

# Build arguments
BUILD_ARGS=(
    "--build-arg" "UBUNTU_VERSION=20.04"
    "--build-arg" "PYTHON_VERSION=3.10.12"
    "--build-arg" "APPIUM_VERSION=2.4.1"
    "--build-arg" "ANDROID_API_LEVEL=31"
    "--build-arg" "ANDROID_VERSION=12.0"
)

# Check Docker availability
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed or not in PATH"
    exit 1
fi

# Check KVM availability
if [ -e /dev/kvm ]; then
    echo "✅ KVM hardware acceleration available"
else
    echo "⚠️  KVM not available - emulator will use software acceleration"
fi

# Create logs directory
mkdir -p logs

# Build the Docker image with avatar persistence
echo "🔨 Building Docker image with avatar persistence: ${FULL_IMAGE_NAME}"
docker build \
    "${BUILD_ARGS[@]}" \
    --tag "${FULL_IMAGE_NAME}" \
    --tag "${IMAGE_NAME}:latest" \
    --file Dockerfile.avatar \
    .

if [ $? -eq 0 ]; then
    echo "✅ Docker image built successfully: ${FULL_IMAGE_NAME}"
    
    # Display image information
    echo ""
    echo "📊 Image Information:"
    docker images "${IMAGE_NAME}" --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.CreatedAt}}"
    
    echo ""
    echo "💾 Avatar Persistence Features:"
    echo "   ✅ Requirements 5.1-5.5: Emulator profile data persistence"
    echo "   ✅ Requirements 7.1-7.4: Avatar/session data access"
    echo ""
    echo "✅ Requirements Compliance:"
    echo "   ✅ 5.1: Persisting emulator profile data"
    echo "   ✅ 5.2: Entire /data partition included"
    echo "   ✅ 5.3: Docker volumes for persistence"
    echo "   ✅ 5.4: Dedicated volume per avatar/session"
    echo "   ✅ 5.5: Data loaded on container start"
    echo "   ✅ 7.1: Each avatar has access to its own data"
    echo "   ✅ 7.2: Avatars identified by unique UUID"
    echo "   ✅ 7.3: Data isolation using separate volumes"
    echo "   ✅ 7.4: Previous state loaded on restart"
    echo ""
    echo "🚀 To run the container with a specific avatar:"
    echo "   export AVATAR_UUID=your-avatar-uuid"
    echo "   docker-compose -f docker-compose.avatar.yml up -d"
    echo ""
    echo "🔍 To verify avatar persistence:"
    echo "   docker exec android-12-emulator-\${AVATAR_UUID} /usr/local/bin/volume-manager.sh check \${AVATAR_UUID}"
    echo ""
    echo "🧪 To test avatar persistence:"
    echo "   docker exec android-12-emulator-\${AVATAR_UUID} /usr/local/bin/entrypoint.sh test"
    
else
    echo "❌ Docker image build failed"
    exit 1
fi