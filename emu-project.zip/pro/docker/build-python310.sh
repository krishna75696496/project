#!/bin/bash
# Build script for Python 3.10 Android 12.0 Emulator
# Requirements 3.1-3.4 Compliant

set -e

echo "🏗️  Building Python 3.10 Android 12.0 Emulator"
echo "🐍 Python 3.10.12 + uiautomator2 2.16.3 + requests 2.31.0"
echo "📱 Android 12.0 + Ubuntu 20.04 + Appium 2.4.1"

# Configuration
IMAGE_NAME="android-emulator-python310"
IMAGE_TAG="ubuntu20.04-python3.10-requirements"
FULL_IMAGE_NAME="${IMAGE_NAME}:${IMAGE_TAG}"

# Build arguments
BUILD_ARGS=(
    "--build-arg" "UBUNTU_VERSION=20.04"
    "--build-arg" "PYTHON_VERSION=3.10.12"
    "--build-arg" "APPIUM_VERSION=2.4.1"
    "--build-arg" "ANDROID_API_LEVEL=31"
    "--build-arg" "ANDROID_VERSION=12.0"
)

# Check Docker availability
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed or not in PATH"
    exit 1
fi

# Check KVM availability
if [ -e /dev/kvm ]; then
    echo "✅ KVM hardware acceleration available"
else
    echo "⚠️  KVM not available - emulator will use software acceleration"
fi

# Create logs directory
mkdir -p logs

# Build the Docker image with Python 3.10 requirements
echo "🔨 Building Docker image: ${FULL_IMAGE_NAME}"
docker build \
    "${BUILD_ARGS[@]}" \
    --tag "${FULL_IMAGE_NAME}" \
    --tag "${IMAGE_NAME}:latest" \
    --file Dockerfile.python310 \
    .

if [ $? -eq 0 ]; then
    echo "✅ Docker image built successfully: ${FULL_IMAGE_NAME}"
    
    # Display image information
    echo ""
    echo "📊 Image Information:"
    docker images "${IMAGE_NAME}" --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.CreatedAt}}"
    
    echo ""
    echo "🐍 Python 3.10 Environment:"
    echo "   ✅ Python 3.10.12"
    echo "   ✅ uiautomator2 2.16.3"
    echo "   ✅ requests 2.31.0"
    echo ""
    echo "✅ Requirements 3.1-3.4 Compliance:"
    echo "   ✅ 3.1: Python environment in Docker container"
    echo "   ✅ 3.2: Python version 3.10"
    echo "   ✅ 3.3: uiautomator2 2.16.3, requests 2.31.0"
    echo "   ✅ 3.4: External script execution capability"
    echo ""
    echo "🚀 To run the container:"
    echo "   docker run -d --privileged --device /dev/kvm:/dev/kvm -p 4723:4723 -p 5901:5901 -p 6080:6080 ${FULL_IMAGE_NAME}"
    echo ""
    echo "🔍 To verify Python 3.10 environment:"
    echo "   docker run --rm ${FULL_IMAGE_NAME} verify"
    echo ""
    echo "🧪 To test external script execution (Requirement 3.4):"
    echo "   docker exec <container_id> python3.10 /home/android/scripts/python310-automation-example.py"
    
else
    echo "❌ Docker image build failed"
    exit 1
fi