# Manual Control via NSQ - Requirements 11.1-11.7

## ✅ **Requirements Compliance**

### **✅ Requirement 11.1: NSQ Listener**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: External Python script listens to NSQ channel
- **Implementation**: Orchestrator script listens to `emulator_control` on channel `manual_control_requests`

### **✅ Requirement 11.2: Container Launch on Signal**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Orchestrator runs container in manual mode when signal received
- **Implementation**: Container launched with manual mode flag when NSQ message received

### **✅ Requirement 11.3: Manual Mode Configuration**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Container configured for manual control
- **Implementation**:
  - External port exposed in range 5901-6000
  - Proxy configured with credentials
  - Profile loaded for specified avatar/session
  - Social media app loaded
  - Container waits for user control

### **✅ Requirement 11.4: VNC Port Publishing**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Orchestrator publishes VNC port back to NSQ
- **Implementation**: Port information published to `emulator_control` on channel `vnc_ports`

### **✅ Requirement 11.5: Backend Forwarding**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Backend picks up VNC port message from NSQ
- **Implementation**: Message includes container ID and exposed port

### **✅ Requirement 11.6: Profile Loading**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Docker volume mounted for avatar/session
- **Implementation**: Volume mounted to container's `/data` partition

### **✅ Requirement 11.7: App Loading**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Specified social media app launched
- **Implementation**: App launched based on context in NSQ message

## 🚀 **Quick Start**

### **1. Start NSQ**
```bash
# Start NSQ lookupd
nsqlookupd &

# Start NSQ daemon
nsqd --lookupd-tcp-address=127.0.0.1:4160 &

# Start NSQ admin (optional)
nsqadmin --lookupd-http-address=127.0.0.1:4161 &
```

### **2. Start Orchestrator**
```bash
# Install Python dependencies
pip install nsq tornado

# Start orchestrator
python3.10 orchestrator.py --nsq-host localhost --nsq-port 4150
```

### **3. Send Manual Control Request**
```bash
# Using curl to publish to NSQ
curl -d '{"avatar_uuid":"avatar-12345678","social_media_app":"facebook"}' \
  'http://127.0.0.1:4151/pub?topic=emulator_control'
```

### **4. Connect to VNC**
After receiving the VNC port from the `vnc_ports` channel, connect to:
```
vnc://localhost:<port>
```
Password: `secret`

## 🏗️ **Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                      NSQ Message Broker                     │
│                                                             │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                                                             │
│                  Python Orchestrator Script                 │
│                                                             │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ Launches
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                    Docker Container                         │
│  ┌─────────────────────────────────────────────────────────┐│
│  │                Ubuntu 20.04 LTS                        ││
│  │  ┌─────────────────────────────────────────────────────┐││
│  │  │              Python 3.10.12                        │││
│  │  │  ┌─────────────────────────────────────────────────┐│││
│  │  │  │            Appium 2.4.1 Server                 ││││
│  │  │  │  ┌─────────────────────────────────────────────┐││││
│  │  │  │  │        Android 12.0 Emulator               │││││
│  │  │  │  │                                            │││││
│  │  │  │  │  ┌─────────────────────────────────────┐   │││││
│  │  │  │  │  │       /data Partition              │   │││││
│  │  │  │  │  │  (Mounted from Docker Volume)      │   │││││
│  │  │  │  │  └─────────────────────────────────────┘   │││││
│  │  │  │  └─────────────────────────────────────────────┘││││
│  │  │  └─────────────────────────────────────────────────┘│││
│  │  └─────────────────────────────────────────────────────┘││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

## 🔄 **Message Flow**

1. **Manual Control Request**
   - Frontend sends request to backend
   - Backend publishes to NSQ topic `emulator_control`, channel `manual_control_requests`
   - Message format: `{"avatar_uuid":"avatar-123","social_media_app":"facebook"}`

2. **Orchestrator Processing**
   - Orchestrator script receives NSQ message
   - Launches Docker container in manual mode
   - Container exposes VNC port in range 5901-6000

3. **VNC Port Publishing**
   - Orchestrator publishes VNC port to NSQ topic `emulator_control`, channel `vnc_ports`
   - Message format: `{"container_id":"abc123","vnc_port":5901,"avatar_uuid":"avatar-123"}`

4. **Backend Processing**
   - Backend picks up VNC port message from NSQ
   - Forwards port information to frontend
   - Frontend connects to VNC server

## 🔧 **Manual Mode Container Configuration**

### **Environment Variables**
```bash
AVATAR_UUID=avatar-12345678
SOCIAL_MEDIA_APP=facebook
MANUAL_MODE=true
VNC_PORT=5901
PROXY_HOST=192.168.1.100
PROXY_PORT=1080
PROXY_USER=proxyuser
PROXY_PASS=proxypassword
```

### **Volume Mounts**
```bash
avatar-volume-${AVATAR_UUID}:/data
android_data:/home/android/.android
android_scripts:/home/android/scripts
android_logs:/home/android/logs
```

### **Port Mappings**
```bash
${VNC_PORT}:5901  # VNC server
4723:4723         # Appium server
6080:6080         # noVNC web interface
```

## 📝 **NSQ Message Formats**

### **Manual Control Request (Requirement 11.1)**
```json
{
  "avatar_uuid": "avatar-12345678",
  "social_media_app": "facebook",
  "proxy_host": "192.168.1.100",
  "proxy_port": "1080",
  "proxy_user": "proxyuser",
  "proxy_pass": "proxypassword"
}
```

### **VNC Port Response (Requirement 11.4)**
```json
{
  "container_id": "abc123def456",
  "vnc_port": 5901,
  "avatar_uuid": "avatar-12345678",
  "timestamp": 1623456789.123
}
```

## 🔍 **Verification**

### **Verify NSQ Listener**
```bash
# Check if orchestrator is listening to NSQ
ps aux | grep orchestrator.py

# Check NSQ topics and channels
curl -s http://localhost:4161/topics | jq .
curl -s http://localhost:4161/channels | jq .
```

### **Verify Manual Mode Container**
```bash
# Check running containers
docker ps | grep emulator-manual

# Check container logs
docker logs <container_id>

# Check if VNC server is running
docker exec <container_id> ps aux | grep vnc
```

### **Test Manual Control Flow**
```bash
# 1. Publish manual control request to NSQ
curl -d '{"avatar_uuid":"test-avatar","social_media_app":"facebook"}' \
  'http://127.0.0.1:4151/pub?topic=emulator_control'

# 2. Check orchestrator logs for container launch

# 3. Check NSQ for VNC port message
curl -s 'http://127.0.0.1:4151/stats?format=json' | jq .

# 4. Connect to VNC using the published port
```

## 🐛 **Troubleshooting**

### **Common Issues**

#### **NSQ Connection Issues**
```bash
# Check if NSQ is running
ps aux | grep nsq

# Check NSQ connectivity
curl -s http://localhost:4161/ping
```

#### **Container Launch Failures**
```bash
# Check orchestrator logs
cat /var/log/orchestrator.log

# Check available ports
netstat -tuln | grep 59
```

#### **VNC Connection Issues**
```bash
# Check if VNC server is running
docker exec <container_id> ps aux | grep vnc

# Check port mapping
docker port <container_id>
```

#### **Profile Loading Issues**
```bash
# Check if profile directory exists
docker exec <container_id> ls -la /emulator_profiles

# Check if profile is mounted
docker exec <container_id> ls -la /data
```

---

**✅ Requirements 11.1-11.7 Fully Implemented**: This implementation provides a complete solution for manual control of Android 12.0 emulator containers via NSQ messaging, with proper profile loading, social media app launching, and VNC port publishing.