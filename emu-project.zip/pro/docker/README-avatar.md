# Android 12.0 Emulator with Avatar Persistence

## ✅ **Requirements Compliance**

### **Profile Data Persistence (5.1-5.5)**

#### **✅ Requirement 5.1: Persisting emulator profile data**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Complete system for persisting emulator profile data
- **Implementation**: Docker volumes mapped to emulator's `/data` partition

#### **✅ Requirement 5.2: Profile data includes entire /data partition**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Entire `/data` partition is persisted
- **Implementation**: Volume mount to `/data` in the emulator

#### **✅ Requirement 5.3: Profile data persisted using Docker volumes**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Docker volumes used for persistence
- **Implementation**: Named volumes in docker-compose and Kubernetes

#### **✅ Requirement 5.4: Dedicated Docker volume per avatar/session**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Each avatar has its own dedicated volume
- **Implementation**: Volumes named with avatar UUID: `avatar-{uuid}`

#### **✅ Requirement 5.5: Data loaded when container starts**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Avatar data automatically loaded on container start
- **Implementation**: Volume mounted to `/data` partition at startup

### **Avatar/Session Data Access (7.1-7.4)**

#### **✅ Requirement 7.1: Each avatar has access to its own image data**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Each avatar can only access its own data
- **Implementation**: Dedicated volume per avatar

#### **✅ Requirement 7.2: Avatars identified by unique UUID**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Each avatar has a unique UUID
- **Implementation**: UUID passed via environment variable

#### **✅ Requirement 7.3: Data isolation using separate Docker volumes**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Complete data isolation between avatars
- **Implementation**: Separate Docker volume per avatar

#### **✅ Requirement 7.4: Container restarts load previous state**
- **Status**: ✅ **IMPLEMENTED**
- **Details**: Previous state including logged-in sessions preserved
- **Implementation**: Persistent `/data` partition across restarts

## 🏗️ **Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│                    Docker Container                         │
│  ┌─────────────────────────────────────────────────────────┐│
│  │                Ubuntu 20.04 LTS                        ││
│  │  ┌─────────────────────────────────────────────────────┐││
│  │  │              Python 3.10.12                        │││
│  │  │  ┌─────────────────────────────────────────────────┐│││
│  │  │  │            Appium 2.4.1 Server                 ││││
│  │  │  │  ┌─────────────────────────────────────────────┐││││
│  │  │  │  │        Android 12.0 Emulator               │││││
│  │  │  │  │                                            │││││
│  │  │  │  │  ┌─────────────────────────────────────┐   │││││
│  │  │  │  │  │       /data Partition              │   │││││
│  │  │  │  │  │  (Mounted from Docker Volume)      │   │││││
│  │  │  │  │  └─────────────────────────────────────┘   │││││
│  │  │  │  └─────────────────────────────────────────────┘││││
│  │  │  └─────────────────────────────────────────────────┘│││
│  │  └─────────────────────────────────────────────────────┘││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
            │
            │ Persists
            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Docker Volumes                           │
│                                                             │
│  ┌─────────────────────────┐  ┌─────────────────────────┐   │
│  │  avatar-volume-uuid1    │  │  avatar-volume-uuid2    │   │
│  │  (Avatar 1 Data)        │  │  (Avatar 2 Data)        │   │
│  └─────────────────────────┘  └─────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────┐  ┌─────────────────────────┐   │
│  │  avatar-volume-uuid3    │  │  avatar-volume-uuid4    │   │
│  │  (Avatar 3 Data)        │  │  (Avatar 4 Data)        │   │
│  └─────────────────────────┘  └─────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 **Quick Start**

### **1. Build the Avatar-Enabled Container**
```bash
chmod +x build-avatar.sh
./build-avatar.sh
```

### **2. Run with Docker Compose**
```bash
# Set avatar UUID
export AVATAR_UUID=avatar-12345678

# Start container with avatar persistence
docker-compose -f docker-compose.avatar.yml up -d
```

### **3. Run with Docker CLI**
```bash
# Create a named volume for the avatar
docker volume create avatar-data-avatar-12345678

# Run container with avatar persistence
docker run -d \
  --name android-emulator-avatar-12345678 \
  --privileged \
  --device /dev/kvm:/dev/kvm \
  -p 4723:4723 \
  -p 5901:5901 \
  -p 6080:6080 \
  -e AVATAR_UUID=avatar-12345678 \
  -v avatar-data-avatar-12345678:/mnt/volumes/avatar-volume-avatar-12345678 \
  -v android_scripts:/home/android/scripts \
  -v android_logs:/home/android/logs \
  android-emulator-avatar:latest
```

### **4. Deploy to Kubernetes**
```bash
# Set avatar UUID
export AVATAR_UUID=avatar-12345678

# Apply Kubernetes manifests
envsubst < kubernetes/avatar-emulator-deployment.yaml | kubectl apply -f -
```

## 🔧 **Configuration**

### **Environment Variables**
| Variable | Description | Default |
|----------|-------------|---------|
| `AVATAR_UUID` | Unique identifier for the avatar/session | `default-avatar` |
| `ANDROID_VERSION` | Android version | `12.0` |
| `PYTHON_VERSION` | Python version | `3.10.12` |
| `APPIUM_VERSION` | Appium version | `2.4.1` |

### **Volume Mounts**
| Path | Purpose | Requirement |
|------|---------|------------|
| `/mnt/volumes/avatar-volume-{uuid}` | Avatar-specific data | 5.3, 5.4, 7.1, 7.3 |
| `/home/android/scripts` | Automation scripts | - |
| `/home/android/logs` | Logs and screenshots | - |

### **Port Mappings**
| Port | Service | Description |
|------|---------|-------------|
| `4723` | Appium Server | WebDriver automation endpoint |
| `5901` | VNC Server | Remote desktop access |
| `6080` | noVNC Web | Browser-based VNC client |

## 🧪 **Testing Avatar Persistence**

### **1. Create and Launch Avatar**
```bash
# Set avatar UUID
export AVATAR_UUID=test-avatar-123

# Start container with this avatar
docker-compose -f docker-compose.avatar.yml up -d
```

### **2. Install and Configure Apps**
```bash
# Connect to the container
docker exec -it android-12-emulator-test-avatar-123 bash

# Inside the container, run app setup
/usr/local/bin/setup-social-apps.sh
```

### **3. Stop and Restart Container**
```bash
# Stop the container
docker-compose -f docker-compose.avatar.yml down

# Restart with the same avatar UUID
docker-compose -f docker-compose.avatar.yml up -d
```

### **4. Verify Persistence**
```bash
# Check if apps are still logged in
docker exec -it android-12-emulator-test-avatar-123 adb shell "pm list packages"
```

## 📊 **Avatar Management**

### **Avatar Volume Manager**
The `volume-manager.sh` script provides tools for managing avatar volumes:

```bash
# Create a new avatar volume
/usr/local/bin/volume-manager.sh create avatar-12345678

# Mount avatar volume to container
/usr/local/bin/volume-manager.sh mount avatar-12345678 emulator-1

# List all avatar volumes
/usr/local/bin/volume-manager.sh list

# Backup avatar volume
/usr/local/bin/volume-manager.sh backup avatar-12345678
```

### **Avatar Manager**
The `avatar-manager.sh` script provides higher-level avatar management:

```bash
# Initialize avatar database
/usr/local/bin/avatar-manager.sh init

# Create a new avatar
/usr/local/bin/avatar-manager.sh create avatar-12345678 "Test Avatar"

# Launch avatar container
/usr/local/bin/avatar-manager.sh launch avatar-12345678 emulator-1

# List all avatars
/usr/local/bin/avatar-manager.sh list
```

## 🔒 **Security**

### **Data Isolation**
- Each avatar has its own dedicated Docker volume
- Volumes are isolated from each other
- Container can only access its own avatar's data

### **Volume Permissions**
- Volumes owned by `android` user
- Permissions set to `755` for security
- No cross-avatar access possible

### **Container Security**
- Privileged mode required for KVM
- Avatar UUID passed via environment variable
- Volume paths include avatar UUID for isolation

## 🐛 **Troubleshooting**

### **Common Issues**

#### **Avatar Volume Not Found**
```bash
# Check if volume exists
docker volume ls | grep avatar-${AVATAR_UUID}

# Create volume if missing
docker volume create avatar-${AVATAR_UUID}
```

#### **Data Not Persisting**
```bash
# Check volume mount
docker inspect android-12-emulator-${AVATAR_UUID} | grep -A 10 Mounts

# Verify data in volume
docker run --rm -v avatar-${AVATAR_UUID}:/data busybox ls -la /data
```

#### **Container Fails to Start**
```bash
# Check logs
docker logs android-12-emulator-${AVATAR_UUID}

# Verify avatar UUID is set
echo $AVATAR_UUID
```

## 📈 **Performance Optimization**

### **Volume Performance**
- Use local SSD storage for volumes
- Consider volume drivers optimized for performance
- Avoid network-attached storage for avatar volumes

### **Container Resources**
- Allocate sufficient memory (8GB recommended)
- Provide at least 4 CPU cores
- Enable KVM for hardware acceleration

## 🔄 **CI/CD Integration**

### **GitHub Actions Example**
```yaml
- name: Start Android Emulator with Avatar
  run: |
    export AVATAR_UUID=ci-avatar-${{ github.run_id }}
    docker-compose -f docker-compose.avatar.yml up -d
    
    # Wait for emulator to be ready
    timeout 300 bash -c 'until docker exec android-12-emulator-$AVATAR_UUID curl -s http://localhost:4723/wd/hub/status; do sleep 5; done'
```

### **Jenkins Pipeline**
```groovy
pipeline {
    agent any
    environment {
        AVATAR_UUID = "jenkins-${BUILD_ID}"
    }
    stages {
        stage('Start Emulator') {
            steps {
                sh 'docker-compose -f docker-compose.avatar.yml up -d'
                sh 'docker exec android-12-emulator-${AVATAR_UUID} /usr/local/bin/volume-manager.sh check ${AVATAR_UUID}'
            }
        }
    }
}
```

## 📚 **API Documentation**

### **Volume Manager API**
```bash
# Create avatar volume
volume-manager.sh create <avatar_uuid>

# Mount avatar volume
volume-manager.sh mount <avatar_uuid> <container_id>

# Unmount avatar volume
volume-manager.sh unmount <avatar_uuid> <container_id>

# List avatar volumes
volume-manager.sh list

# Check avatar volume
volume-manager.sh check <avatar_uuid>

# Backup avatar volume
volume-manager.sh backup <avatar_uuid>

# Restore avatar volume
volume-manager.sh restore <avatar_uuid> <backup_path>
```

### **Avatar Manager API**
```bash
# Initialize avatar database
avatar-manager.sh init

# Create avatar
avatar-manager.sh create <avatar_uuid> <avatar_name>

# Launch avatar container
avatar-manager.sh launch <avatar_uuid> <container_name>

# Stop avatar container
avatar-manager.sh stop <avatar_uuid> <container_name>

# List avatars
avatar-manager.sh list

# Get avatar details
avatar-manager.sh get <avatar_uuid>

# Delete avatar
avatar-manager.sh delete <avatar_uuid>
```

## 🆘 **Support**

### **Logs Location**
- **Container Logs**: `docker logs android-12-emulator-${AVATAR_UUID}`
- **Emulator Logs**: `/home/android/logs/emulator.log`
- **Appium Logs**: `/home/android/logs/appium.log`
- **Avatar Logs**: `/home/android/logs/avatar-${AVATAR_UUID}.log`

### **Debug Mode**
```bash
# Start container in debug mode
docker run -it --rm \
  -e AVATAR_UUID=debug-avatar \
  android-emulator-avatar:latest shell
```

### **Health Monitoring**
```bash
# Check avatar volume status
docker exec android-12-emulator-${AVATAR_UUID} /usr/local/bin/volume-manager.sh check ${AVATAR_UUID}

# Check emulator status
docker exec android-12-emulator-${AVATAR_UUID} adb devices

# Check Appium status
curl http://localhost:4723/wd/hub/status
```

---

**✅ All Requirements Met**: This implementation fully satisfies requirements 5.1-5.5 for profile data persistence and 7.1-7.4 for avatar/session data access, providing complete data isolation and persistence for Android 12.0 emulator containers.