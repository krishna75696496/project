# Android Emulator Backend API System

This document provides an overview of the backend API system for the Android Emulator project, including database schema, REST API endpoints, NSQ message queue integration, and error logging functionality.

## Database Schema

The database schema is implemented in Supabase and includes the following tables:

### Tasks Table
- Stores information about automation tasks
- Fields: id, task_id, task_type, account, social_media_app, python_code, task_data, status, assigned_to, created_at
- Row-level security ensures users can only access their own tasks

### Task Logs Table
- Tracks the execution status and progress of tasks
- Fields: id, task_id, status, timestamp, details
- Linked to tasks via foreign key

### Task Results Table
- Stores the results of completed tasks
- Fields: id, task_id, result_data, submitted_at
- Supports JSON data for flexible result storage

### Error Logs Table
- Records errors that occur during task execution
- Fields: id, task_id, error_message, log_path, reported_at
- Helps with debugging and error tracking

### Profile Volumes Table
- Manages avatar profiles and Docker volumes
- Fields: id, user_id, avatar_id, docker_volume_name, social_app_state, created_at
- Supports persistence of user profiles across sessions

### Proxy Sessions Table
- Configures proxy settings for tasks
- Fields: id, task_id, proxy_host, proxy_port, proxy_user, proxy_pass, applied_at
- Enables routing traffic through proxies

### VNC Sessions Table
- Tracks VNC sessions for manual control
- Fields: id, avatar_id, container_id, exposed_port, session_mode, started_at, ended_at
- Supports both manual and automated sessions

## REST API Endpoints

The API is implemented using Supabase Edge Functions and client-side services:

### Task Management
- `GET /functions/v1/get-task` - Get the next pending task
- `POST /functions/v1/update-status` - Update task status and add log entry
- `POST /functions/v1/submit-result` - Submit task results
- `POST /functions/v1/report-error` - Report task execution errors

### Manual Control
- `POST /functions/v1/manual-control` - Request manual control of an emulator

### Client-Side Services
- `taskService.ts` - Task CRUD operations and status management
- `avatarService.ts` - Avatar profile management
- `vncService.ts` - VNC session management
- `proxyService.ts` - Proxy configuration
- `nsqService.ts` - NSQ message queue integration

## NSQ Message Queue Integration

The system uses NSQ for asynchronous communication between components:

### Topics and Channels
- `emulator_control` topic with channels:
  - `manual_control_requests` - Requests for manual control
  - `vnc_ports` - VNC port information for manual control sessions

### Server-Side Components
- `nsqListener.js` - Listens for manual control requests and launches containers
- `taskManager.js` - Processes tasks from the queue and updates status

### Client-Side Integration
- `nsqClient.ts` - Browser-friendly client for NSQ interaction
- `useManualControl.ts` - React hook for manual control functionality

## Error Logging and Status Tracking

The system includes comprehensive error logging and status tracking:

### Error Logging
- Centralized error logging in the `error_logs` table
- Detailed error messages and stack traces
- Optional log file paths for additional context

### Status Tracking
- Task status updates in the `tasks` table
- Detailed execution logs in the `task_logs` table
- Real-time status updates via the API

### Utility Functions
- `logger.ts` - Centralized logging utility
- Error reporting endpoints for automated error handling

## Getting Started

1. Set up Supabase:
   - Create a new Supabase project
   - Run the migration scripts in `supabase/migrations/`
   - Set up Edge Functions in `supabase/functions/`

2. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Update with your Supabase URL and anon key
   - Configure NSQ host and ports

3. Start the server components:
   - Run NSQ: `nsqlookupd & nsqd --lookupd-tcp-address=127.0.0.1:4160 &`
   - Start the NSQ listener: `node src/server/nsqListener.js`
   - Start the task manager: `node src/server/taskManager.js`

4. Use the client-side hooks and services to interact with the API.

## Security Considerations

- Row-level security ensures users can only access their own data
- Service role key used only in server-side components
- Sensitive data (proxy credentials, etc.) properly secured
- CORS headers configured for API endpoints

## Extending the System

To add new functionality:
1. Create new tables in Supabase as needed
2. Add corresponding TypeScript types in `database.types.ts`
3. Create new API endpoints as Edge Functions
4. Implement client-side services and hooks