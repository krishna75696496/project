// Task Manager for Android Emulator Project
// This would run on the server side, not in the browser

const { createClient } = require('@supabase/supabase-js');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const BACKEND_API_ENDPOINT = process.env.BACKEND_API_ENDPOINT || 'http://localhost:3000/api';
const PROFILES_DIR = process.env.BROWSER_PROFILES_PATH || './browser_profiles';
const TASK_LOOP_INTERVAL = 60; // seconds to wait between API calls when no tasks

// Supabase configuration
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

// Initialize Supabase client with service role key
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// Logger
function log(level, message) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [${level}] ${message}`);
  
  // Also log to file
  fs.appendFileSync('/var/log/emulator_task.log', `[${timestamp}] [${level}] ${message}\n`);
}

// Get a task from the database
async function getTask(userId) {
  try {
    log('INFO', 'Requesting task from database');
    
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('assigned_to', userId)
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(1);
    
    if (error) {
      log('ERROR', `Error fetching task: ${error.message}`);
      return null;
    }
    
    if (!data || data.length === 0) {
      log('INFO', 'No tasks available');
      return null;
    }
    
    log('INFO', `Received task: ${data[0].task_id}`);
    return data[0];
  } catch (error) {
    log('ERROR', `Error in getTask: ${error.message}`);
    return null;
  }
}

// Update task status
async function updateTaskStatus(taskId, status, details) {
  try {
    log('INFO', `Updating task status: ${taskId} -> ${status}`);
    
    // Update task status
    const { error: updateError } = await supabase
      .from('tasks')
      .update({ status })
      .eq('id', taskId);
    
    if (updateError) {
      log('ERROR', `Failed to update task status: ${updateError.message}`);
      return false;
    }
    
    // Add task log
    const { error: logError } = await supabase
      .from('task_logs')
      .insert({
        task_id: taskId,
        status,
        details: details || `Status updated to ${status}`
      });
    
    if (logError) {
      log('ERROR', `Failed to add task log: ${logError.message}`);
      // Continue even if log fails
    }
    
    return true;
  } catch (error) {
    log('ERROR', `Error in updateTaskStatus: ${error.message}`);
    return false;
  }
}

// Submit task results
async function submitTaskResults(taskId, resultData) {
  try {
    log('INFO', `Submitting results for task: ${taskId}`);
    
    // Insert task results
    const { error: resultError } = await supabase
      .from('task_results')
      .insert({
        task_id: taskId,
        result_data: resultData
      });
    
    if (resultError) {
      log('ERROR', `Failed to submit task results: ${resultError.message}`);
      return false;
    }
    
    // Update task status to completed
    return await updateTaskStatus(taskId, 'completed', 'Task completed with results');
  } catch (error) {
    log('ERROR', `Error in submitTaskResults: ${error.message}`);
    return false;
  }
}

// Report error
async function reportError(taskId, errorMessage, logPath) {
  try {
    log('ERROR', `Task ${taskId} failed: ${errorMessage}`);
    
    // Log error
    const { error: errorLogError } = await supabase
      .from('error_logs')
      .insert({
        task_id: taskId,
        error_message: errorMessage,
        log_path: logPath
      });
    
    if (errorLogError) {
      log('ERROR', `Failed to log error: ${errorLogError.message}`);
      return false;
    }
    
    // Update task status to failed
    return await updateTaskStatus(taskId, 'failed', `Error: ${errorMessage}`);
  } catch (error) {
    log('ERROR', `Error in reportError: ${error.message}`);
    return false;
  }
}

// Configure proxy for a task
async function configureProxy(taskId) {
  try {
    log('INFO', 'Configuring proxy for task execution');
    
    // Get proxy configuration for this task
    const { data: proxyData, error: proxyError } = await supabase
      .from('proxy_sessions')
      .select('*')
      .eq('task_id', taskId)
      .order('applied_at', { ascending: false })
      .limit(1);
    
    if (proxyError) {
      log('ERROR', `Error fetching proxy configuration: ${proxyError.message}`);
      return false;
    }
    
    if (!proxyData || proxyData.length === 0) {
      log('INFO', 'No proxy configuration found for this task');
      return true; // Not an error, just no proxy needed
    }
    
    const proxy = proxyData[0];
    
    // Set environment variables for proxy
    process.env.PROXY_HOST = proxy.proxy_host;
    process.env.PROXY_PORT = proxy.proxy_port.toString();
    
    if (proxy.proxy_user) {
      process.env.PROXY_USER = proxy.proxy_user;
    }
    
    if (proxy.proxy_pass) {
      process.env.PROXY_PASS = proxy.proxy_pass;
    }
    
    // Run proxy configuration script
    const configScript = spawn('/usr/local/bin/configure-proxy.sh');
    
    return new Promise((resolve, reject) => {
      configScript.on('close', (code) => {
        if (code === 0) {
          log('INFO', 'Proxy configured successfully');
          resolve(true);
        } else {
          log('WARN', `Proxy configuration exited with code ${code}`);
          resolve(false); // Continue even if proxy config fails
        }
      });
      
      configScript.on('error', (err) => {
        log('ERROR', `Proxy configuration error: ${err.message}`);
        resolve(false); // Continue even if proxy config fails
      });
    });
  } catch (error) {
    log('ERROR', `Error in configureProxy: ${error.message}`);
    return false;
  }
}

// Load browser profile
async function loadProfile(account) {
  try {
    log('INFO', `Loading browser profile for account: ${account}`);
    
    // Check if profile exists
    const profilePath = path.join(PROFILES_DIR, account);
    
    if (!fs.existsSync(profilePath)) {
      log('ERROR', `Profile not found: ${profilePath}`);
      return false;
    }
    
    // Verify profile structure
    if (!fs.existsSync(path.join(profilePath, 'cookies.sqlite'))) {
      log('WARN', 'Profile may be incomplete, cookies.sqlite not found');
    }
    
    // Copy profile to appropriate location for the app to use
    const appProfileDir = '/home/android/.app_profiles/' + account;
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(appProfileDir)) {
      fs.mkdirSync(appProfileDir, { recursive: true });
    }
    
    // Copy profile files
    const files = fs.readdirSync(profilePath);
    for (const file of files) {
      fs.copyFileSync(
        path.join(profilePath, file),
        path.join(appProfileDir, file)
      );
    }
    
    log('INFO', 'Profile loaded successfully');
    return true;
  } catch (error) {
    log('ERROR', `Error in loadProfile: ${error.message}`);
    return false;
  }
}

// Save profile after task
async function saveProfile(account) {
  try {
    log('INFO', `Saving browser profile for account: ${account}`);
    
    // Check if profile exists
    const profilePath = path.join(PROFILES_DIR, account);
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(profilePath)) {
      log('INFO', `Creating new profile directory: ${profilePath}`);
      fs.mkdirSync(profilePath, { recursive: true });
    }
    
    // Copy profile from app location back to persistent storage
    const appProfileDir = '/home/android/.app_profiles/' + account;
    
    if (!fs.existsSync(appProfileDir)) {
      log('ERROR', `App profile directory not found: ${appProfileDir}`);
      return false;
    }
    
    // Copy profile files
    const files = fs.readdirSync(appProfileDir);
    for (const file of files) {
      fs.copyFileSync(
        path.join(appProfileDir, file),
        path.join(profilePath, file)
      );
    }
    
    log('INFO', 'Profile saved successfully');
    return true;
  } catch (error) {
    log('ERROR', `Error in saveProfile: ${error.message}`);
    return false;
  }
}

// Launch social media app
async function launchApp(appName) {
  try {
    log('INFO', `Launching social media app: ${appName}`);
    
    // Convert app name to package name
    let packageName;
    switch (appName.toLowerCase()) {
      case 'facebook':
        packageName = 'com.facebook.katana';
        break;
      case 'instagram':
        packageName = 'com.instagram.android';
        break;
      case 'twitter':
        packageName = 'com.twitter.android';
        break;
      case 'whatsapp':
        packageName = 'com.whatsapp';
        break;
      default:
        log('ERROR', `Unknown app: ${appName}`);
        return false;
    }
    
    // Check if app is installed
    const checkApp = spawn('adb', ['shell', 'pm', 'list', 'packages', packageName]);
    
    let output = '';
    checkApp.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    return new Promise((resolve, reject) => {
      checkApp.on('close', (code) => {
        if (code !== 0 || !output.includes(packageName)) {
          log('ERROR', `App not installed: ${packageName}`);
          resolve(false);
          return;
        }
        
        // Launch the app
        const launchApp = spawn('adb', [
          'shell', 
          'monkey', 
          '-p', 
          packageName, 
          '-c', 
          'android.intent.category.LAUNCHER', 
          '1'
        ]);
        
        launchApp.on('close', (launchCode) => {
          if (launchCode !== 0) {
            log('ERROR', `Failed to launch app: ${appName}`);
            resolve(false);
            return;
          }
          
          // Wait for app to start
          setTimeout(() => {
            log('INFO', `App launched successfully: ${appName}`);
            resolve(true);
          }, 5000);
        });
        
        launchApp.on('error', (err) => {
          log('ERROR', `Error launching app: ${err.message}`);
          resolve(false);
        });
      });
      
      checkApp.on('error', (err) => {
        log('ERROR', `Error checking app installation: ${err.message}`);
        resolve(false);
      });
    });
  } catch (error) {
    log('ERROR', `Error in launchApp: ${error.message}`);
    return false;
  }
}

// Close app
async function closeApp(appName) {
  try {
    log('INFO', `Closing social media app: ${appName}`);
    
    // Convert app name to package name
    let packageName;
    switch (appName.toLowerCase()) {
      case 'facebook':
        packageName = 'com.facebook.katana';
        break;
      case 'instagram':
        packageName = 'com.instagram.android';
        break;
      case 'twitter':
        packageName = 'com.twitter.android';
        break;
      case 'whatsapp':
        packageName = 'com.whatsapp';
        break;
      default:
        log('ERROR', `Unknown app: ${appName}`);
        return false;
    }
    
    // Force stop the app
    const closeApp = spawn('adb', ['shell', 'am', 'force-stop', packageName]);
    
    return new Promise((resolve, reject) => {
      closeApp.on('close', (code) => {
        if (code !== 0) {
          log('WARN', `Failed to close app: ${appName}`);
          resolve(false);
          return;
        }
        
        log('INFO', `App closed successfully: ${appName}`);
        resolve(true);
      });
      
      closeApp.on('error', (err) => {
        log('ERROR', `Error closing app: ${err.message}`);
        resolve(false);
      });
    });
  } catch (error) {
    log('ERROR', `Error in closeApp: ${error.message}`);
    return false;
  }
}

// Execute Python script
async function executePythonScript(scriptPath, taskId, resultsFile) {
  try {
    log('INFO', `Executing Python script: ${scriptPath}`);
    
    // Check if script exists
    if (!fs.existsSync(scriptPath)) {
      log('ERROR', `Script not found: ${scriptPath}`);
      return { success: false, error: `Script not found: ${scriptPath}` };
    }
    
    // Create a temporary file for task data
    const taskDataFile = `/tmp/task_${taskId}_data.json`;
    
    // Execute the script
    const pythonProcess = spawn('python3.10', [
      scriptPath,
      '--task-data', taskDataFile,
      '--results-file', resultsFile
    ]);
    
    let stdoutData = '';
    let stderrData = '';
    
    pythonProcess.stdout.on('data', (data) => {
      stdoutData += data.toString();
      log('INFO', `Script output: ${data.toString().trim()}`);
    });
    
    pythonProcess.stderr.on('data', (data) => {
      stderrData += data.toString();
      log('ERROR', `Script error: ${data.toString().trim()}`);
    });
    
    return new Promise((resolve, reject) => {
      pythonProcess.on('close', (code) => {
        if (code !== 0) {
          log('ERROR', `Script execution failed with exit code: ${code}`);
          resolve({ 
            success: false, 
            error: `Script execution failed with exit code: ${code}`,
            stderr: stderrData
          });
          return;
        }
        
        log('INFO', 'Script executed successfully');
        
        // Check if results file exists
        if (!fs.existsSync(resultsFile)) {
          log('ERROR', `Results file not found: ${resultsFile}`);
          resolve({ 
            success: false, 
            error: `Results file not found: ${resultsFile}`,
            stdout: stdoutData
          });
          return;
        }
        
        try {
          // Read results file
          const results = JSON.parse(fs.readFileSync(resultsFile, 'utf8'));
          resolve({ success: true, results });
        } catch (err) {
          log('ERROR', `Error parsing results file: ${err.message}`);
          resolve({ 
            success: false, 
            error: `Error parsing results file: ${err.message}`,
            stdout: stdoutData
          });
        }
      });
      
      pythonProcess.on('error', (err) => {
        log('ERROR', `Error executing script: ${err.message}`);
        resolve({ success: false, error: err.message });
      });
    });
  } catch (error) {
    log('ERROR', `Error in executePythonScript: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// Main task execution function
async function executeTask(task, userId) {
  try {
    log('INFO', `Executing task: ${task.task_id} (${task.task_type})`);
    
    // Update task status to running
    await updateTaskStatus(task.id, 'running', 'Task execution started');
    
    // Configure proxy for the task
    await configureProxy(task.id);
    
    // Load browser profile
    if (!await loadProfile(task.account)) {
      await reportError(task.id, `Failed to load profile for account: ${task.account}`);
      return false;
    }
    
    // Launch social media app
    if (!await launchApp(task.social_media_app)) {
      await reportError(task.id, `Failed to launch app: ${task.social_media_app}`);
      return false;
    }
    
    // Execute Python script
    const resultsFile = `/tmp/task_${task.task_id}_results.json`;
    const scriptResult = await executePythonScript(task.python_code, task.task_id, resultsFile);
    
    if (!scriptResult.success) {
      await reportError(task.id, `Python script execution failed: ${scriptResult.error}`);
      await closeApp(task.social_media_app);
      return false;
    }
    
    // Submit results
    await submitTaskResults(task.id, scriptResult.results);
    
    // Close app properly
    await closeApp(task.social_media_app);
    
    // Save profile
    if (!await saveProfile(task.account)) {
      log('WARN', `Failed to save profile for account: ${task.account}`);
      // Continue even if profile save fails
    }
    
    log('INFO', `Task completed successfully: ${task.task_id}`);
    return true;
  } catch (error) {
    log('ERROR', `Error executing task: ${error.message}`);
    await reportError(task.id, `Task execution error: ${error.message}`);
    return false;
  }
}

// Main task loop
async function mainTaskLoop(userId) {
  log('INFO', 'Starting main task loop');
  
  while (true) {
    try {
      // Get a task from the database
      const task = await getTask(userId);
      
      if (task) {
        // Execute the task
        await executeTask(task, userId);
      } else {
        // No tasks available, wait and retry
        log('INFO', `No tasks available, waiting for ${TASK_LOOP_INTERVAL} seconds`);
        await new Promise(resolve => setTimeout(resolve, TASK_LOOP_INTERVAL * 1000));
      }
    } catch (error) {
      log('ERROR', `Error in task loop: ${error.message}`);
      // Wait before retrying
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  }
}

// Main function
async function main() {
  log('INFO', 'Initializing task manager');
  
  try {
    // Get user ID from environment or use a default
    // In a real implementation, this would be properly authenticated
    const userId = process.env.USER_ID || '00000000-0000-0000-0000-000000000000';
    
    // Start the task loop
    await mainTaskLoop(userId);
  } catch (error) {
    log('ERROR', `Fatal error in task manager: ${error.message}`);
    process.exit(1);
  }
}

// Start the task manager
main().catch(error => {
  log('ERROR', `Unhandled error: ${error.message}`);
  process.exit(1);
});