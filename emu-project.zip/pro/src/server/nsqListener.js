// NSQ Listener for Android Emulator Project
// This would run on the server side, not in the browser

const nsq = require('nsq');
const { spawn } = require('child_process');
const { createClient } = require('@supabase/supabase-js');

// Configuration
const NSQ_HOST = process.env.NSQ_HOST || 'localhost';
const NSQ_PORT = parseInt(process.env.NSQ_PORT || '4150');
const NSQ_TOPIC = 'emulator_control';
const NSQ_CHANNEL_REQUESTS = 'manual_control_requests';
const NSQ_CHANNEL_PORTS = 'vnc_ports';

// Supabase configuration
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

// Initialize Supabase client with service role key
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// Available ports for VNC
const VNC_PORT_RANGE = { min: 5901, max: 6000 };
const usedPorts = new Set();

// Find an available port
function findAvailablePort() {
  for (let port = VNC_PORT_RANGE.min; port <= VNC_PORT_RANGE.max; port++) {
    if (!usedPorts.has(port)) {
      usedPorts.add(port);
      return port;
    }
  }
  throw new Error('No available VNC ports');
}

// Release a port when done
function releasePort(port) {
  usedPorts.delete(port);
}

// Launch a container in manual mode
async function launchContainer(message) {
  console.log('Launching container for manual control:', message);
  
  const { avatar_uuid, social_media_app, proxy_host, proxy_port, proxy_user, proxy_pass } = message;
  
  // Find an available VNC port
  const vncPort = findAvailablePort();
  
  // Build docker run command
  const dockerArgs = [
    'run',
    '-d',
    '--name', `emulator-manual-${avatar_uuid}`,
    '--privileged',
    '--device', '/dev/kvm:/dev/kvm',
    '-e', `AVATAR_UUID=${avatar_uuid}`,
    '-e', `SOCIAL_MEDIA_APP=${social_media_app}`,
    '-e', 'MANUAL_MODE=true',
    '-e', `VNC_PORT=${vncPort}`
  ];
  
  // Add proxy configuration if provided
  if (proxy_host && proxy_port) {
    dockerArgs.push('-e', `PROXY_HOST=${proxy_host}`);
    dockerArgs.push('-e', `PROXY_PORT=${proxy_port}`);
    
    if (proxy_user && proxy_pass) {
      dockerArgs.push('-e', `PROXY_USER=${proxy_user}`);
      dockerArgs.push('-e', `PROXY_PASS=${proxy_pass}`);
    }
  }
  
  // Add volume mounts
  dockerArgs.push(
    '-v', `avatar-volume-${avatar_uuid}:/data`,
    '-v', 'android_data:/home/android/.android',
    '-v', 'android_scripts:/home/android/scripts',
    '-v', 'android_logs:/home/android/logs'
  );
  
  // Add port mappings
  dockerArgs.push(
    '-p', `${vncPort}:5901`,
    '-p', '4723:4723',
    '-p', '6080:6080'
  );
  
  // Add image and command
  dockerArgs.push(
    'android-emulator:latest',
    'manual'
  );
  
  // Launch the container
  return new Promise((resolve, reject) => {
    const docker = spawn('docker', dockerArgs);
    
    let containerId = '';
    let errorOutput = '';
    
    docker.stdout.on('data', (data) => {
      containerId += data.toString().trim();
    });
    
    docker.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });
    
    docker.on('close', (code) => {
      if (code !== 0) {
        console.error(`Docker run failed with code ${code}:`, errorOutput);
        releasePort(vncPort);
        reject(new Error(`Failed to launch container: ${errorOutput}`));
        return;
      }
      
      console.log(`Container launched with ID: ${containerId}`);
      
      // Update VNC session in database
      updateVncSession(avatar_uuid, containerId, vncPort)
        .then(() => {
          // Publish VNC port information back to NSQ
          publishVncPort(containerId, vncPort, avatar_uuid)
            .then(() => resolve({ containerId, vncPort }))
            .catch(reject);
        })
        .catch(reject);
    });
  });
}

// Update VNC session in database
async function updateVncSession(avatarId, containerId, exposedPort) {
  try {
    // Find the most recent VNC session for this avatar
    const { data: sessions, error: selectError } = await supabase
      .from('vnc_sessions')
      .select('*')
      .eq('avatar_id', avatarId)
      .is('ended_at', null)
      .order('started_at', { ascending: false })
      .limit(1);
    
    if (selectError) {
      console.error('Error finding VNC session:', selectError);
      return;
    }
    
    if (sessions && sessions.length > 0) {
      // Update existing session
      const { error: updateError } = await supabase
        .from('vnc_sessions')
        .update({
          container_id: containerId,
          exposed_port: exposedPort
        })
        .eq('id', sessions[0].id);
      
      if (updateError) {
        console.error('Error updating VNC session:', updateError);
      }
    } else {
      // Create new session
      const { error: insertError } = await supabase
        .from('vnc_sessions')
        .insert({
          avatar_id: avatarId,
          container_id: containerId,
          exposed_port: exposedPort,
          session_mode: 'manual'
        });
      
      if (insertError) {
        console.error('Error creating VNC session:', insertError);
      }
    }
  } catch (error) {
    console.error('Error updating VNC session in database:', error);
  }
}

// Publish VNC port information back to NSQ
async function publishVncPort(containerId, vncPort, avatarUuid) {
  return new Promise((resolve, reject) => {
    const writer = new nsq.Writer(NSQ_HOST, NSQ_PORT);
    
    writer.connect();
    
    writer.on('ready', () => {
      const message = {
        container_id: containerId,
        vnc_port: vncPort,
        avatar_uuid: avatarUuid,
        timestamp: Date.now()
      };
      
      writer.publish(NSQ_TOPIC, message, (err) => {
        if (err) {
          console.error('Error publishing VNC port to NSQ:', err);
          reject(err);
          return;
        }
        
        console.log('Published VNC port information to NSQ:', message);
        writer.close();
        resolve();
      });
    });
    
    writer.on('error', (err) => {
      console.error('NSQ writer error:', err);
      reject(err);
    });
  });
}

// Main function
async function main() {
  console.log('Starting NSQ listener for Android Emulator Project');
  
  // Create reader for manual control requests
  const reader = new nsq.Reader(NSQ_TOPIC, NSQ_CHANNEL_REQUESTS, {
    lookupdHTTPAddresses: [`${NSQ_HOST}:4161`]
  });
  
  reader.connect();
  
  reader.on('message', async (msg) => {
    try {
      const message = JSON.parse(msg.body.toString());
      console.log('Received manual control request:', message);
      
      // Launch container
      await launchContainer(message);
      
      // Finish the message
      msg.finish();
    } catch (error) {
      console.error('Error processing message:', error);
      // Requeue the message
      msg.requeue();
    }
  });
  
  reader.on('error', (err) => {
    console.error('NSQ reader error:', err);
  });
  
  // Handle graceful shutdown
  process.on('SIGINT', () => {
    console.log('Shutting down NSQ listener...');
    reader.close();
    process.exit(0);
  });
}

// Start the listener
main().catch(console.error);