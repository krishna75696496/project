export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      tasks: {
        Row: {
          id: string
          task_id: string
          task_type: string | null
          account: string | null
          social_media_app: string | null
          python_code: string | null
          task_data: Json | null
          status: string
          assigned_to: string | null
          created_at: string
        }
        Insert: {
          id?: string
          task_id: string
          task_type?: string | null
          account?: string | null
          social_media_app?: string | null
          python_code?: string | null
          task_data?: Json | null
          status?: string
          assigned_to?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          task_id?: string
          task_type?: string | null
          account?: string | null
          social_media_app?: string | null
          python_code?: string | null
          task_data?: Json | null
          status?: string
          assigned_to?: string | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      task_logs: {
        Row: {
          id: string
          task_id: string | null
          status: string | null
          timestamp: string
          details: string | null
        }
        Insert: {
          id?: string
          task_id?: string | null
          status?: string | null
          timestamp?: string
          details?: string | null
        }
        Update: {
          id?: string
          task_id?: string | null
          status?: string | null
          timestamp?: string
          details?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "task_logs_task_id_fkey"
            columns: ["task_id"]
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          }
        ]
      }
      task_results: {
        Row: {
          id: string
          task_id: string | null
          result_data: Json | null
          submitted_at: string
        }
        Insert: {
          id?: string
          task_id?: string | null
          result_data?: Json | null
          submitted_at?: string
        }
        Update: {
          id?: string
          task_id?: string | null
          result_data?: Json | null
          submitted_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_results_task_id_fkey"
            columns: ["task_id"]
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          }
        ]
      }
      error_logs: {
        Row: {
          id: string
          task_id: string | null
          error_message: string | null
          log_path: string | null
          reported_at: string
        }
        Insert: {
          id?: string
          task_id?: string | null
          error_message?: string | null
          log_path?: string | null
          reported_at?: string
        }
        Update: {
          id?: string
          task_id?: string | null
          error_message?: string | null
          log_path?: string | null
          reported_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "error_logs_task_id_fkey"
            columns: ["task_id"]
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          }
        ]
      }
      profile_volumes: {
        Row: {
          id: string
          user_id: string | null
          avatar_id: string
          docker_volume_name: string | null
          social_app_state: Json | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          avatar_id: string
          docker_volume_name?: string | null
          social_app_state?: Json | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          avatar_id?: string
          docker_volume_name?: string | null
          social_app_state?: Json | null
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_volumes_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "users"
            referencedColumns: ["id"]
          }
        ]
      }
      proxy_sessions: {
        Row: {
          id: string
          task_id: string | null
          proxy_host: string | null
          proxy_port: number | null
          proxy_user: string | null
          proxy_pass: string | null
          applied_at: string
        }
        Insert: {
          id?: string
          task_id?: string | null
          proxy_host?: string | null
          proxy_port?: number | null
          proxy_user?: string | null
          proxy_pass?: string | null
          applied_at?: string
        }
        Update: {
          id?: string
          task_id?: string | null
          proxy_host?: string | null
          proxy_port?: number | null
          proxy_user?: string | null
          proxy_pass?: string | null
          applied_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "proxy_sessions_task_id_fkey"
            columns: ["task_id"]
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          }
        ]
      }
      vnc_sessions: {
        Row: {
          id: string
          avatar_id: string | null
          container_id: string | null
          exposed_port: number | null
          session_mode: string
          started_at: string
          ended_at: string | null
        }
        Insert: {
          id?: string
          avatar_id?: string | null
          container_id?: string | null
          exposed_port?: number | null
          session_mode?: string
          started_at?: string
          ended_at?: string | null
        }
        Update: {
          id?: string
          avatar_id?: string | null
          container_id?: string | null
          exposed_port?: number | null
          session_mode?: string
          started_at?: string
          ended_at?: string | null
        }
        Relationships: []
      }
      users: {
        Row: {
          id: string
          phone_number: string | null
          role: string | null
          created_at: string | null
        }
        Insert: {
          id?: string
          phone_number?: string | null
          role?: string | null
          created_at?: string | null
        }
        Update: {
          id?: string
          phone_number?: string | null
          role?: string | null
          created_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}