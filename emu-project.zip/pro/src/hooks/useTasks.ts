import { useState, useEffect } from 'react';
import { 
  getTasks, 
  getTaskById, 
  createTask, 
  updateTask, 
  deleteTask, 
  addTaskLog, 
  submitTaskResults, 
  logError,
  TaskCreateParams,
  TaskUpdateParams,
  TaskLogParams,
  TaskResultParams,
  ErrorLogParams
} from '../api/taskService';

export const useTasks = () => {
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTasks = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getTasks();
      setTasks(data);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching tasks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTaskById = async (taskId: string) => {
    try {
      return await getTaskById(taskId);
    } catch (err) {
      setError(err.message);
      console.error(`Error fetching task ${taskId}:`, err);
      throw err;
    }
  };

  const addTask = async (taskParams: TaskCreateParams) => {
    try {
      const newTask = await createTask(taskParams);
      setTasks(prev => [newTask, ...prev]);
      return newTask;
    } catch (err) {
      setError(err.message);
      console.error('Error creating task:', err);
      throw err;
    }
  };

  const updateTaskStatus = async (taskId: string, updateParams: TaskUpdateParams) => {
    try {
      const updatedTask = await updateTask(taskId, updateParams);
      setTasks(prev => prev.map(task => task.id === taskId ? updatedTask : task));
      return updatedTask;
    } catch (err) {
      setError(err.message);
      console.error(`Error updating task ${taskId}:`, err);
      throw err;
    }
  };

  const removeTask = async (taskId: string) => {
    try {
      await deleteTask(taskId);
      setTasks(prev => prev.filter(task => task.id !== taskId));
      return true;
    } catch (err) {
      setError(err.message);
      console.error(`Error deleting task ${taskId}:`, err);
      throw err;
    }
  };

  const logTaskStatus = async (logParams: TaskLogParams) => {
    try {
      return await addTaskLog(logParams);
    } catch (err) {
      setError(err.message);
      console.error('Error adding task log:', err);
      throw err;
    }
  };

  const submitResults = async (resultParams: TaskResultParams) => {
    try {
      return await submitTaskResults(resultParams);
    } catch (err) {
      setError(err.message);
      console.error('Error submitting task results:', err);
      throw err;
    }
  };

  const reportError = async (errorParams: ErrorLogParams) => {
    try {
      return await logError(errorParams);
    } catch (err) {
      setError(err.message);
      console.error('Error reporting error:', err);
      throw err;
    }
  };

  return {
    tasks,
    loading,
    error,
    fetchTasks,
    fetchTaskById,
    addTask,
    updateTaskStatus,
    removeTask,
    logTaskStatus,
    submitResults,
    reportError
  };
};