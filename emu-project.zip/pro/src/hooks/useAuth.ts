import { useState, useEffect } from 'react';
import { User } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate auth check
    const token = localStorage.getItem('auth_token');
    if (token) {
      // Mock user data
      setUser({
        id: '1',
        username: 'admin',
        email: 'admin@example.com',
        role: 'admin',
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=100&h=100&fit=crop&crop=face',
        lastLogin: new Date()
      });
    }
    setLoading(false);
  }, []);

  const login = async (username: string, password: string) => {
    // Mock login
    if (username && password) {
      const mockUser: User = {
        id: '1',
        username,
        email: `${username}@example.com`,
        role: username === 'admin' ? 'admin' : 'developer',
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=100&h=100&fit=crop&crop=face',
        lastLogin: new Date()
      };
      localStorage.setItem('auth_token', 'mock_token');
      setUser(mockUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
  };

  return { user, login, logout, loading };
};