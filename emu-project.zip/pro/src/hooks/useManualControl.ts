import { useState } from 'react';
import { 
  sendManualControlRequest, 
  listenForVncPortResponse,
  ManualControlRequest,
  VncPortResponse
} from '../api/nsqService';
import { 
  getSessionsByAvatarId, 
  createVncSession, 
  endVncSession 
} from '../api/vncService';

export const useManualControl = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [vncSession, setVncSession] = useState<any | null>(null);
  const [vncPort, setVncPort] = useState<number | null>(null);
  const [containerId, setContainerId] = useState<string | null>(null);
  const [listener, setListener] = useState<{ unsubscribe: () => void } | null>(null);

  const startManualSession = async (request: ManualControlRequest) => {
    setLoading(true);
    setError(null);
    
    try {
      // Send the manual control request
      const result = await sendManualControlRequest(request);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to start manual control session');
      }
      
      // Start listening for VNC port response
      const newListener = listenForVncPortResponse(request.avatar_uuid, handleVncPortResponse);
      setListener(newListener);
      
      // Store the session ID
      if (result.session_id) {
        setVncSession({ id: result.session_id, avatar_id: request.avatar_uuid });
      }
      
      return result;
    } catch (err) {
      setError(err.message);
      console.error('Error starting manual control session:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const handleVncPortResponse = (response: VncPortResponse) => {
    setVncPort(response.vnc_port);
    setContainerId(response.container_id);
    
    // Update the VNC session record with the container ID and port
    if (vncSession?.id) {
      updateVncSession(vncSession.id, response.container_id, response.vnc_port);
    }
    
    // Stop listening for further updates
    if (listener) {
      listener.unsubscribe();
      setListener(null);
    }
  };

  const updateVncSession = async (sessionId: string, containerId: string, exposedPort: number) => {
    try {
      // This would be implemented in a real backend
      console.log(`Updating VNC session ${sessionId} with container ${containerId} and port ${exposedPort}`);
    } catch (err) {
      console.error(`Error updating VNC session ${sessionId}:`, err);
    }
  };

  const endManualSession = async (sessionId: string) => {
    setLoading(true);
    setError(null);
    
    try {
      await endVncSession(sessionId);
      setVncSession(null);
      setVncPort(null);
      setContainerId(null);
      
      // Stop listening if still active
      if (listener) {
        listener.unsubscribe();
        setListener(null);
      }
      
      return true;
    } catch (err) {
      setError(err.message);
      console.error(`Error ending manual control session ${sessionId}:`, err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getActiveSessionsForAvatar = async (avatarId: string) => {
    try {
      return await getSessionsByAvatarId(avatarId);
    } catch (err) {
      setError(err.message);
      console.error(`Error fetching VNC sessions for avatar ${avatarId}:`, err);
      throw err;
    }
  };

  return {
    loading,
    error,
    vncSession,
    vncPort,
    containerId,
    startManualSession,
    endManualSession,
    getActiveSessionsForAvatar
  };
};