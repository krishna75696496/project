import { useState, useEffect } from 'react';
import { EmulatorContainer } from '../types';

export const useEmulators = () => {
  const [containers, setContainers] = useState<EmulatorContainer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock data with Android 12.0 for all emulators
    const mockContainers: EmulatorContainer[] = [
      {
        id: 'emulator-1',
        name: 'Pixel 6 Pro - Android 12.0',
        status: 'running',
        androidVersion: '12.0',
        deviceType: 'Pixel 6 Pro',
        cpuUsage: 45,
        memoryUsage: 2.1,
        networkUsage: 15.3,
        createdAt: new Date(Date.now() - 3600000),
        lastActivity: new Date(),
        assignedUser: 'john.doe',
        profileId: 'profile-1',
        vncPort: 5901,
        appiumPort: 4723
      },
      {
        id: 'emulator-2',
        name: 'Galaxy S23 - Android 12.0',
        status: 'running',
        androidVersion: '12.0',
        deviceType: 'Galaxy S23',
        cpuUsage: 32,
        memoryUsage: 1.8,
        networkUsage: 8.7,
        createdAt: new Date(Date.now() - 7200000),
        lastActivity: new Date(Date.now() - 600000),
        assignedUser: 'jane.smith',
        profileId: 'profile-2',
        vncPort: 5902,
        appiumPort: 4724
      },
      {
        id: 'emulator-3',
        name: 'OnePlus 11 - Android 12.0',
        status: 'stopped',
        androidVersion: '12.0',
        deviceType: 'OnePlus 11',
        cpuUsage: 0,
        memoryUsage: 0,
        networkUsage: 0,
        createdAt: new Date(Date.now() - 86400000),
        lastActivity: new Date(Date.now() - 3600000),
        profileId: 'profile-3'
      },
      {
        id: 'emulator-4',
        name: 'iPhone 14 Pro - Android 12.0',
        status: 'pending',
        androidVersion: '12.0',
        deviceType: 'iPhone 14 Pro',
        cpuUsage: 0,
        memoryUsage: 0,
        networkUsage: 0,
        createdAt: new Date(Date.now() - 1800000),
        lastActivity: new Date(Date.now() - 1800000),
        assignedUser: 'mike.wilson',
        profileId: 'profile-4',
        vncPort: 5903,
        appiumPort: 4725
      },
      {
        id: 'emulator-5',
        name: 'Pixel 7 - Android 12.0',
        status: 'error',
        androidVersion: '12.0',
        deviceType: 'Pixel 7',
        cpuUsage: 0,
        memoryUsage: 0,
        networkUsage: 0,
        createdAt: new Date(Date.now() - 5400000),
        lastActivity: new Date(Date.now() - 3600000),
        assignedUser: 'sarah.davis',
        profileId: 'profile-5',
        vncPort: 5904,
        appiumPort: 4726
      }
    ];

    setTimeout(() => {
      setContainers(mockContainers);
      setLoading(false);
    }, 1000);

    // Simulate real-time updates
    const interval = setInterval(() => {
      setContainers(prev => prev.map(container => ({
        ...container,
        cpuUsage: container.status === 'running' ? Math.random() * 100 : 0,
        memoryUsage: container.status === 'running' ? Math.random() * 4 : 0,
        networkUsage: container.status === 'running' ? Math.random() * 50 : 0,
        lastActivity: container.status === 'running' ? new Date() : container.lastActivity
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const startContainer = async (id: string) => {
    setContainers(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'running' as const, lastActivity: new Date() } : c
    ));
  };

  const stopContainer = async (id: string) => {
    setContainers(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'stopped' as const, cpuUsage: 0, memoryUsage: 0, networkUsage: 0 } : c
    ));
  };

  const restartContainer = async (id: string) => {
    // First set to pending
    setContainers(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'pending' as const } : c
    ));
    
    // Then after 2 seconds set to running
    setTimeout(() => {
      setContainers(prev => prev.map(c => 
        c.id === id ? { ...c, status: 'running' as const, lastActivity: new Date() } : c
      ));
    }, 2000);
  };

  const deleteContainer = async (id: string) => {
    setContainers(prev => prev.filter(c => c.id !== id));
  };

  return { containers, loading, startContainer, stopContainer, restartContainer, deleteContainer };
};