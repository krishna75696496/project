import { useState, useEffect } from 'react';
import { 
  getAvatars, 
  getAvatarById, 
  createAvatar, 
  updateAvatar, 
  deleteAvatar,
  AvatarCreateParams,
  AvatarUpdateParams
} from '../api/avatarService';

export const useAvatars = () => {
  const [avatars, setAvatars] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAvatars = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getAvatars();
      setAvatars(data);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching avatars:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAvatars();
  }, []);

  const fetchAvatarById = async (avatarId: string) => {
    try {
      return await getAvatarById(avatarId);
    } catch (err) {
      setError(err.message);
      console.error(`Error fetching avatar ${avatarId}:`, err);
      throw err;
    }
  };

  const addAvatar = async (avatarParams: AvatarCreateParams) => {
    try {
      const newAvatar = await createAvatar(avatarParams);
      setAvatars(prev => [newAvatar, ...prev]);
      return newAvatar;
    } catch (err) {
      setError(err.message);
      console.error('Error creating avatar:', err);
      throw err;
    }
  };

  const updateAvatarProfile = async (avatarId: string, updateParams: AvatarUpdateParams) => {
    try {
      const updatedAvatar = await updateAvatar(avatarId, updateParams);
      setAvatars(prev => prev.map(avatar => avatar.avatar_id === avatarId ? updatedAvatar : avatar));
      return updatedAvatar;
    } catch (err) {
      setError(err.message);
      console.error(`Error updating avatar ${avatarId}:`, err);
      throw err;
    }
  };

  const removeAvatar = async (avatarId: string) => {
    try {
      await deleteAvatar(avatarId);
      setAvatars(prev => prev.filter(avatar => avatar.avatar_id !== avatarId));
      return true;
    } catch (err) {
      setError(err.message);
      console.error(`Error deleting avatar ${avatarId}:`, err);
      throw err;
    }
  };

  return {
    avatars,
    loading,
    error,
    fetchAvatars,
    fetchAvatarById,
    addAvatar,
    updateAvatarProfile,
    removeAvatar
  };
};