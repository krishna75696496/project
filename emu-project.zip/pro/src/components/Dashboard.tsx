import React, { useState } from 'react';
import { User } from '../types';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { DashboardView } from './views/DashboardView';
import { LaunchView } from './views/LaunchView';
import { TasksView } from './views/TasksView';
import { ControlView } from './views/ControlView';
import { LogsView } from './views/LogsView';
import { VolumesView } from './views/VolumesView';
import { ProxyView } from './views/ProxyView';
import { KubernetesView } from './views/KubernetesView';
import { ReportsView } from './views/ReportsView';
import { CICDView } from './views/CICDView';
import { SecurityView } from './views/SecurityView';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const [activeView, setActiveView] = useState('dashboard');

  // Handler for quick launch button
  const handleQuickLaunch = () => {
    setActiveView('launch');
  };

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView />;
      case 'launch':
        return <LaunchView />;
      case 'tasks':
        return <TasksView />;
      case 'control':
        return <ControlView />;
      case 'logs':
        return <LogsView />;
      case 'volumes':
        return <VolumesView />;
      case 'proxy':
        return <ProxyView />;
      case 'kubernetes':
        return <KubernetesView />;
      case 'reports':
        return <ReportsView />;
      case 'cicd':
        return <CICDView />;
      case 'security':
        return <SecurityView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Sidebar activeView={activeView} onViewChange={setActiveView} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} onLogout={onLogout} onQuickLaunch={handleQuickLaunch} />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            {renderView()}
          </div>
        </main>
      </div>
    </div>
  );
};