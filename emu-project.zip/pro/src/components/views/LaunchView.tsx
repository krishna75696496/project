import React, { useState } from 'react';
import { 
  Play, 
  Smartphone, 
  Settings, 
  Zap, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle, 
  X,
  Code,
  Globe,
  Key,
  Monitor,
  Cpu,
  HardDrive,
  Network,
  Eye,
  EyeOff,
  Copy,
  RefreshCw
} from 'lucide-react';

interface EnvironmentVariable {
  key: string;
  value: string;
  isSecret: boolean;
}

interface LaunchConfig {
  selectedApp: string;
  avatarUuid: string;
  launchMode: 'auto' | 'manual';
  envVars: EnvironmentVariable[];
  proxyUrl: string;
  taskScriptId: string;
  deviceType: string;
  androidVersion: string;
  ramSize: number;
  storageSize: number;
  cpuCores: number;
  gpuAcceleration: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const LaunchView: React.FC = () => {
  const [config, setConfig] = useState<LaunchConfig>({
    selectedApp: '',
    avatarUuid: '',
    launchMode: 'auto',
    envVars: [{ key: '', value: '', isSecret: false }],
    proxyUrl: '',
    taskScriptId: '',
    deviceType: 'pixel-6-pro',
    androidVersion: '12.0', // Fixed to Android 12.0
    ramSize: 2,
    storageSize: 16,
    cpuCores: 2,
    gpuAcceleration: 'auto'
  });

  const [isLaunching, setIsLaunching] = useState(false);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Mock data
  const apps = [
    { id: 'facebook', name: 'Facebook', icon: '📘' },
    { id: 'instagram', name: 'Instagram', icon: '📷' },
    { id: 'whatsapp', name: 'WhatsApp', icon: '💬' },
    { id: 'tiktok', name: 'TikTok', icon: '🎵' },
    { id: 'twitter', name: 'Twitter', icon: '🐦' },
    { id: 'youtube', name: 'YouTube', icon: '📺' },
    { id: 'snapchat', name: 'Snapchat', icon: '👻' },
    { id: 'telegram', name: 'Telegram', icon: '✈️' }
  ];

  const taskScripts = [
    { id: 'login-test', name: 'Login Flow Test', description: 'Automated login testing' },
    { id: 'ui-regression', name: 'UI Regression Suite', description: 'Complete UI testing' },
    { id: 'performance-test', name: 'Performance Benchmark', description: 'App performance testing' },
    { id: 'social-actions', name: 'Social Actions Test', description: 'Like, share, comment tests' },
    { id: 'custom-script', name: 'Custom Script', description: 'Upload your own script' }
  ];

  const devices = [
    { id: 'pixel-6-pro', name: 'Pixel 6 Pro', resolution: '1440x3120', ram: [2, 4, 6, 8] },
    { id: 'galaxy-s23', name: 'Galaxy S23', resolution: '1080x2340', ram: [2, 4, 6] },
    { id: 'oneplus-11', name: 'OnePlus 11', resolution: '1440x3216', ram: [2, 4, 6, 8] },
    { id: 'pixel-7', name: 'Pixel 7', resolution: '1080x2400', ram: [2, 4, 6] },
  ];

  // Android 12.0 is the only version available
  const androidVersions = ['12.0'];

  // Generate random Avatar UUID
  const generateAvatarUuid = () => {
    const uuid = 'avatar-' + Math.random().toString(36).substr(2, 8) + '-' + Date.now().toString(36);
    setConfig(prev => ({ ...prev, avatarUuid: uuid }));
  };

  // Environment variables management
  const addEnvVar = () => {
    setConfig(prev => ({
      ...prev,
      envVars: [...prev.envVars, { key: '', value: '', isSecret: false }]
    }));
  };

  const removeEnvVar = (index: number) => {
    setConfig(prev => ({
      ...prev,
      envVars: prev.envVars.filter((_, i) => i !== index)
    }));
  };

  const updateEnvVar = (index: number, field: keyof EnvironmentVariable, value: string | boolean) => {
    setConfig(prev => ({
      ...prev,
      envVars: prev.envVars.map((env, i) => 
        i === index ? { ...env, [field]: value } : env
      )
    }));
  };

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  // Form validation
  const validateForm = (): boolean => {
    const errors: ValidationError[] = [];

    if (!config.selectedApp) {
      errors.push({ field: 'selectedApp', message: 'Please select an app' });
    }

    if (!config.avatarUuid) {
      errors.push({ field: 'avatarUuid', message: 'Avatar UUID is required' });
    }

    if (config.proxyUrl && !isValidUrl(config.proxyUrl)) {
      errors.push({ field: 'proxyUrl', message: 'Please enter a valid proxy URL' });
    }

    // Validate environment variables
    config.envVars.forEach((env, index) => {
      if (env.key && !env.value) {
        errors.push({ field: `envVar-${index}`, message: `Environment variable "${env.key}" needs a value` });
      }
      if (env.value && !env.key) {
        errors.push({ field: `envVar-${index}`, message: 'Environment variable key is required' });
      }
    });

    setValidationErrors(errors);
    return errors.length === 0;
  };

  const isValidUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const getFieldError = (field: string): string | undefined => {
    return validationErrors.find(error => error.field === field)?.message;
  };

  // Launch handler
  const handleLaunch = async () => {
    if (!validateForm()) {
      addToast({
        type: 'error',
        title: 'Validation Failed',
        message: 'Please fix the errors before launching'
      });
      return;
    }

    setIsLaunching(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      addToast({
        type: 'success',
        title: 'Launch Successful',
        message: `Android 12.0 emulator "${config.selectedApp}" launched successfully with UUID ${config.avatarUuid}`
      });

      // Reset form for next launch
      setConfig(prev => ({
        ...prev,
        selectedApp: '',
        avatarUuid: '',
        envVars: [{ key: '', value: '', isSecret: false }],
        proxyUrl: '',
        taskScriptId: ''
      }));
      
    } catch (error) {
      addToast({
        type: 'error',
        title: 'Launch Failed',
        message: 'Failed to launch Android 12.0 emulator. Please try again.'
      });
    } finally {
      setIsLaunching(false);
    }
  };

  const selectedDevice = devices.find(d => d.id === config.deviceType);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <AlertCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertCircle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <AlertCircle className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Launch New Emulator</h1>
          <p className="text-gray-600">Configure and launch a new Android 12.0 emulator container instance</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showAdvanced ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Settings className="w-4 h-4" />
            Advanced Settings
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Configuration Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Launch Mode Selector */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Launch Mode</h2>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setConfig(prev => ({ ...prev, launchMode: 'auto' }))}
                className={`p-4 rounded-lg border-2 transition-all ${
                  config.launchMode === 'auto'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${config.launchMode === 'auto' ? 'bg-blue-100' : 'bg-gray-100'}`}>
                    <Zap className={`w-5 h-5 ${config.launchMode === 'auto' ? 'text-blue-600' : 'text-gray-600'}`} />
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-gray-900">Auto Mode</div>
                    <div className="text-sm text-gray-500">Quick launch with task automation</div>
                  </div>
                </div>
              </button>
              <button
                onClick={() => setConfig(prev => ({ ...prev, launchMode: 'manual' }))}
                className={`p-4 rounded-lg border-2 transition-all ${
                  config.launchMode === 'manual'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${config.launchMode === 'manual' ? 'bg-blue-100' : 'bg-gray-100'}`}>
                    <Settings className={`w-5 h-5 ${config.launchMode === 'manual' ? 'text-blue-600' : 'text-gray-600'}`} />
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-gray-900">Manual Mode</div>
                    <div className="text-sm text-gray-500">Full control and customization</div>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* App and Configuration */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">App Configuration</h2>
            <div className="space-y-4">
              {/* App Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target App <span className="text-red-500">*</span>
                </label>
                <select
                  value={config.selectedApp}
                  onChange={(e) => setConfig(prev => ({ ...prev, selectedApp: e.target.value }))}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    getFieldError('selectedApp') ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Select an app to test</option>
                  {apps.map(app => (
                    <option key={app.id} value={app.id}>
                      {app.icon} {app.name}
                    </option>
                  ))}
                </select>
                {getFieldError('selectedApp') && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {getFieldError('selectedApp')}
                  </p>
                )}
              </div>

              {/* Avatar UUID */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Avatar UUID <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={config.avatarUuid}
                    onChange={(e) => setConfig(prev => ({ ...prev, avatarUuid: e.target.value }))}
                    placeholder="Enter or generate Avatar UUID"
                    className={`flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm ${
                      getFieldError('avatarUuid') ? 'border-red-300' : 'border-gray-300'
                    }`}
                  />
                  <button
                    onClick={generateAvatarUuid}
                    className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors flex items-center gap-1"
                    title="Generate UUID"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => navigator.clipboard.writeText(config.avatarUuid)}
                    className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
                    title="Copy UUID"
                    disabled={!config.avatarUuid}
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                {getFieldError('avatarUuid') && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {getFieldError('avatarUuid')}
                  </p>
                )}
              </div>

              {/* Task Script (Auto Mode) */}
              {config.launchMode === 'auto' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Task Script (Optional)
                  </label>
                  <select
                    value={config.taskScriptId}
                    onChange={(e) => setConfig(prev => ({ ...prev, taskScriptId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">No automated task</option>
                    {taskScripts.map(script => (
                      <option key={script.id} value={script.id}>
                        {script.name} - {script.description}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Proxy URL */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Proxy URL (Optional)
                </label>
                <input
                  type="url"
                  value={config.proxyUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, proxyUrl: e.target.value }))}
                  placeholder="http://proxy.example.com:8080"
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    getFieldError('proxyUrl') ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {getFieldError('proxyUrl') && (
                  <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {getFieldError('proxyUrl')}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Environment Variables */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Environment Variables</h2>
              <button
                onClick={addEnvVar}
                className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Variable
              </button>
            </div>
            <div className="space-y-3">
              {config.envVars.map((env, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder="Variable name"
                      value={env.key}
                      onChange={(e) => updateEnvVar(index, 'key', e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <div className="relative">
                      <input
                        type={env.isSecret ? 'password' : 'text'}
                        placeholder="Variable value"
                        value={env.value}
                        onChange={(e) => updateEnvVar(index, 'value', e.target.value)}
                        className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      <button
                        onClick={() => updateEnvVar(index, 'isSecret', !env.isSecret)}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {env.isSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateEnvVar(index, 'isSecret', !env.isSecret)}
                      className={`p-2 rounded-lg transition-colors ${
                        env.isSecret ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'
                      }`}
                      title={env.isSecret ? 'Secret variable' : 'Regular variable'}
                    >
                      <Key className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => removeEnvVar(index)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      disabled={config.envVars.length === 1}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Advanced Settings */}
          {showAdvanced && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Advanced Configuration</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Device Type</label>
                  <select
                    value={config.deviceType}
                    onChange={(e) => setConfig(prev => ({ ...prev, deviceType: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {devices.map(device => (
                      <option key={device.id} value={device.id}>
                        {device.name} ({device.resolution})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Android Version</label>
                  <div className="relative">
                    <input
                      type="text"
                      value="Android 12.0"
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Fixed</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">All emulators run Android 12.0</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">RAM (GB)</label>
                  <select
                    value={config.ramSize}
                    onChange={(e) => setConfig(prev => ({ ...prev, ramSize: parseInt(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {selectedDevice?.ram.map(size => (
                      <option key={size} value={size}>{size} GB</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Storage (GB)</label>
                  <input
                    type="number"
                    min="8"
                    max="64"
                    value={config.storageSize}
                    onChange={(e) => setConfig(prev => ({ ...prev, storageSize: parseInt(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">CPU Cores</label>
                  <select
                    value={config.cpuCores}
                    onChange={(e) => setConfig(prev => ({ ...prev, cpuCores: parseInt(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value={2}>2 Cores</option>
                    <option value={4}>4 Cores</option>
                    <option value={6}>6 Cores</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">GPU Acceleration</label>
                  <select
                    value={config.gpuAcceleration}
                    onChange={(e) => setConfig(prev => ({ ...prev, gpuAcceleration: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="auto">Auto</option>
                    <option value="host">Host GPU</option>
                    <option value="software">Software</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Launch Summary Panel */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Launch Summary</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">App:</span>
                <span className="font-medium">
                  {config.selectedApp ? apps.find(a => a.id === config.selectedApp)?.name : 'Not selected'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Mode:</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  config.launchMode === 'auto' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                }`}>
                  {config.launchMode.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Device:</span>
                <span className="font-medium">{selectedDevice?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Android:</span>
                <span className="font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">
                  Version 12.0
                </span>
              </div>
              {config.taskScriptId && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Task:</span>
                  <span className="font-medium text-sm">
                    {taskScripts.find(t => t.id === config.taskScriptId)?.name}
                  </span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-gray-600">Env Vars:</span>
                <span className="font-medium">
                  {config.envVars.filter(env => env.key && env.value).length}
                </span>
              </div>
              {config.proxyUrl && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Proxy:</span>
                  <span className="font-medium text-green-600">Enabled</span>
                </div>
              )}
            </div>
            
            <button
              onClick={handleLaunch}
              disabled={isLaunching || !config.selectedApp || !config.avatarUuid}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              {isLaunching ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Launching Android 12.0...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Launch Android 12.0 Emulator
                </>
              )}
            </button>
          </div>

          {/* Configuration Tips */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4">
            <h3 className="font-medium text-blue-900 mb-2 flex items-center gap-2">
              <Monitor className="w-4 h-4" />
              Android 12.0 Features
            </h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Material You design system</li>
              <li>• Enhanced privacy controls</li>
              <li>• Improved performance</li>
              <li>• New notification system</li>
              <li>• Optimized for testing</li>
            </ul>
          </div>

          {/* Resource Requirements */}
          {showAdvanced && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <h3 className="font-medium text-gray-900 mb-3">Resource Requirements</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-gray-600">
                    <Cpu className="w-4 h-4" />
                    CPU Cores:
                  </span>
                  <span className="font-medium">{config.cpuCores}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-gray-600">
                    <HardDrive className="w-4 h-4" />
                    RAM:
                  </span>
                  <span className="font-medium">{config.ramSize} GB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-gray-600">
                    <HardDrive className="w-4 h-4" />
                    Storage:
                  </span>
                  <span className="font-medium">{config.storageSize} GB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-gray-600">
                    <Network className="w-4 h-4" />
                    Network:
                  </span>
                  <span className="font-medium">
                    {config.proxyUrl ? 'Proxied' : 'Direct'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};