import React, { useState, useEffect } from 'react';
import { 
  GitBranch, 
  Github, 
  Gitlab, 
  Settings, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Key, 
  Link, 
  Unlink, 
  TestTube, 
  RefreshCw, 
  Copy, 
  Eye, 
  EyeOff, 
  Plus, 
  Trash2, 
  Edit, 
  Play, 
  Square, 
  Activity, 
  Zap, 
  Globe, 
  Shield, 
  Code, 
  Terminal, 
  FileText, 
  Download, 
  Upload, 
  Search, 
  Filter, 
  X,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Save,
  MoreVertical,
  Bell,
  Mail,
  Webhook,
  Server,
  Database,
  Monitor,
  Users
} from 'lucide-react';

interface CIProvider {
  id: string;
  name: string;
  type: 'github' | 'gitlab' | 'jenkins' | 'bitbucket' | 'azure' | 'circleci';
  icon: React.ComponentType<any>;
  status: 'connected' | 'disconnected' | 'error' | 'testing';
  webhook_url?: string;
  access_token?: string;
  last_trigger_time?: Date;
  trigger_count: number;
  success_rate: number;
  avg_execution_time: number;
  connected_at?: Date;
  config: {
    repository?: string;
    branch?: string;
    build_command?: string;
    test_command?: string;
    environment?: string;
  };
}

interface CIExecution {
  id: string;
  provider_id: string;
  provider_name: string;
  trigger_type: 'push' | 'pull_request' | 'manual' | 'scheduled';
  trigger_status: 'pending' | 'running' | 'success' | 'failure' | 'cancelled';
  repository: string;
  branch: string;
  commit_hash: string;
  commit_message: string;
  author: string;
  started_at: Date;
  completed_at?: Date;
  duration?: number;
  logs: string[];
  emulator_containers: string[];
  test_results?: {
    total: number;
    passed: number;
    failed: number;
    skipped: number;
  };
}

interface WebhookConfig {
  id: string;
  provider_id: string;
  url: string;
  secret?: string;
  events: string[];
  active: boolean;
  last_delivery?: Date;
  delivery_count: number;
  failure_count: number;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const CICDView: React.FC = () => {
  const [providers, setProviders] = useState<CIProvider[]>([]);
  const [executions, setExecutions] = useState<CIExecution[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [selectedProvider, setSelectedProvider] = useState<CIProvider | null>(null);
  const [selectedExecution, setSelectedExecution] = useState<CIExecution | null>(null);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showTokenModal, setShowTokenModal] = useState(false);
  const [showWebhookModal, setShowWebhookModal] = useState(false);
  const [showTokens, setShowTokens] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [testingConnection, setTestingConnection] = useState<string | null>(null);
  const [expandedExecution, setExpandedExecution] = useState<string | null>(null);

  const [newProvider, setNewProvider] = useState<Partial<CIProvider>>({
    type: 'github',
    config: {}
  });

  const [newWebhook, setNewWebhook] = useState<Partial<WebhookConfig>>({
    events: ['push', 'pull_request'],
    active: true
  });

  const providerTypes = [
    { id: 'github', name: 'GitHub Actions', icon: Github },
    { id: 'gitlab', name: 'GitLab CI/CD', icon: Gitlab },
    { id: 'jenkins', name: 'Jenkins', icon: Server },
    { id: 'bitbucket', name: 'Bitbucket Pipelines', icon: GitBranch },
    { id: 'azure', name: 'Azure DevOps', icon: Globe },
    { id: 'circleci', name: 'CircleCI', icon: Activity }
  ];

  // Generate mock data
  useEffect(() => {
    const generateMockData = () => {
      const mockProviders: CIProvider[] = [
        {
          id: 'github-1',
          name: 'Main Repository',
          type: 'github',
          icon: Github,
          status: 'connected',
          webhook_url: 'https://api.github.com/repos/company/mobile-app/hooks/12345',
          access_token: 'ghp_xxxxxxxxxxxxxxxxxxxx',
          last_trigger_time: new Date(Date.now() - 3600000),
          trigger_count: 156,
          success_rate: 87,
          avg_execution_time: 8.5,
          connected_at: new Date(Date.now() - 86400000 * 30),
          config: {
            repository: 'company/mobile-app',
            branch: 'main',
            build_command: 'npm run build',
            test_command: 'npm run test:emulator',
            environment: 'production'
          }
        },
        {
          id: 'gitlab-1',
          name: 'Feature Branch Pipeline',
          type: 'gitlab',
          icon: Gitlab,
          status: 'connected',
          webhook_url: 'https://gitlab.com/api/v4/projects/123/hooks/456',
          access_token: 'glpat-xxxxxxxxxxxxxxxxxxxx',
          last_trigger_time: new Date(Date.now() - 7200000),
          trigger_count: 89,
          success_rate: 92,
          avg_execution_time: 6.2,
          connected_at: new Date(Date.now() - 86400000 * 15),
          config: {
            repository: 'company/mobile-features',
            branch: 'develop',
            build_command: 'gradle build',
            test_command: 'gradle test',
            environment: 'staging'
          }
        },
        {
          id: 'jenkins-1',
          name: 'Legacy CI Server',
          type: 'jenkins',
          icon: Server,
          status: 'error',
          webhook_url: 'https://jenkins.company.com/github-webhook/',
          trigger_count: 234,
          success_rate: 76,
          avg_execution_time: 12.3,
          connected_at: new Date(Date.now() - 86400000 * 60),
          config: {
            repository: 'company/legacy-app',
            branch: 'master',
            build_command: 'mvn clean install',
            test_command: 'mvn test',
            environment: 'qa'
          }
        }
      ];

      const mockExecutions: CIExecution[] = Array.from({ length: 20 }, (_, i) => {
        const provider = mockProviders[Math.floor(Math.random() * mockProviders.length)];
        const triggerTypes = ['push', 'pull_request', 'manual', 'scheduled'] as const;
        const statuses = ['pending', 'running', 'success', 'failure', 'cancelled'] as const;
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const startTime = new Date(Date.now() - Math.random() * 86400000 * 7);
        const duration = status === 'running' || status === 'pending' ? undefined : Math.floor(Math.random() * 20) + 3;
        
        return {
          id: `exec-${i}`,
          provider_id: provider.id,
          provider_name: provider.name,
          trigger_type: triggerTypes[Math.floor(Math.random() * triggerTypes.length)],
          trigger_status: status,
          repository: provider.config.repository || 'unknown/repo',
          branch: ['main', 'develop', 'feature/new-ui', 'hotfix/bug-123'][Math.floor(Math.random() * 4)],
          commit_hash: Math.random().toString(36).substr(2, 8),
          commit_message: [
            'Add new emulator test suite',
            'Fix authentication flow',
            'Update CI configuration',
            'Improve test coverage',
            'Refactor login component'
          ][Math.floor(Math.random() * 5)],
          author: ['john.doe', 'jane.smith', 'mike.wilson', 'sarah.davis'][Math.floor(Math.random() * 4)],
          started_at: startTime,
          completed_at: duration ? new Date(startTime.getTime() + duration * 60000) : undefined,
          duration,
          logs: [
            `[${startTime.toISOString()}] Starting CI pipeline...`,
            `[${startTime.toISOString()}] Checking out code from ${provider.config.repository}`,
            `[${startTime.toISOString()}] Setting up emulator environment`,
            `[${startTime.toISOString()}] Running build command: ${provider.config.build_command}`,
            `[${startTime.toISOString()}] Executing tests: ${provider.config.test_command}`,
            status === 'success' ? `[${startTime.toISOString()}] ✅ Pipeline completed successfully` :
            status === 'failure' ? `[${startTime.toISOString()}] ❌ Pipeline failed with errors` :
            `[${startTime.toISOString()}] Pipeline ${status}`
          ],
          emulator_containers: [`emulator-${Math.floor(Math.random() * 5) + 1}`],
          test_results: status === 'success' || status === 'failure' ? {
            total: Math.floor(Math.random() * 50) + 20,
            passed: Math.floor(Math.random() * 40) + 15,
            failed: Math.floor(Math.random() * 5),
            skipped: Math.floor(Math.random() * 3)
          } : undefined
        };
      });

      const mockWebhooks: WebhookConfig[] = mockProviders.map(provider => ({
        id: `webhook-${provider.id}`,
        provider_id: provider.id,
        url: provider.webhook_url || '',
        secret: 'webhook_secret_' + Math.random().toString(36).substr(2, 8),
        events: ['push', 'pull_request', 'release'],
        active: provider.status === 'connected',
        last_delivery: provider.last_trigger_time,
        delivery_count: provider.trigger_count,
        failure_count: Math.floor(provider.trigger_count * (1 - provider.success_rate / 100))
      }));

      setProviders(mockProviders);
      setExecutions(mockExecutions);
      setWebhooks(mockWebhooks);
      setLoading(false);
    };

    setTimeout(generateMockData, 1000);
  }, []);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': case 'success': return 'text-green-600 bg-green-100 border-green-200';
      case 'running': case 'pending': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'disconnected': case 'cancelled': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'error': case 'failure': return 'text-red-600 bg-red-100 border-red-200';
      case 'testing': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': case 'success': return <CheckCircle className="w-4 h-4" />;
      case 'running': case 'pending': return <Clock className="w-4 h-4 animate-pulse" />;
      case 'disconnected': case 'cancelled': return <XCircle className="w-4 h-4" />;
      case 'error': case 'failure': return <AlertTriangle className="w-4 h-4" />;
      case 'testing': return <TestTube className="w-4 h-4" />;
      default: return <XCircle className="w-4 h-4" />;
    }
  };

  const testConnection = async (providerId: string) => {
    setTestingConnection(providerId);
    
    // Simulate connection test
    setTimeout(() => {
      const success = Math.random() > 0.2; // 80% success rate
      
      setProviders(prev => prev.map(provider => 
        provider.id === providerId 
          ? { ...provider, status: success ? 'connected' : 'error' }
          : provider
      ));

      addToast({
        type: success ? 'success' : 'error',
        title: 'Connection Test',
        message: success 
          ? 'Connection test successful' 
          : 'Connection test failed - check credentials'
      });

      setTestingConnection(null);
    }, 2000);
  };

  const connectProvider = () => {
    if (!newProvider.name || !newProvider.type) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Provider name and type are required'
      });
      return;
    }

    const provider: CIProvider = {
      id: `${newProvider.type}-${Date.now()}`,
      name: newProvider.name!,
      type: newProvider.type!,
      icon: providerTypes.find(t => t.id === newProvider.type)!.icon,
      status: 'disconnected',
      trigger_count: 0,
      success_rate: 0,
      avg_execution_time: 0,
      config: newProvider.config || {}
    };

    setProviders(prev => [...prev, provider]);
    setShowConnectModal(false);
    setNewProvider({ type: 'github', config: {} });

    addToast({
      type: 'success',
      title: 'Provider Added',
      message: `${provider.name} added successfully. Configure webhook to complete setup.`
    });
  };

  const disconnectProvider = (providerId: string) => {
    if (window.confirm('Are you sure you want to disconnect this provider?')) {
      setProviders(prev => prev.map(provider => 
        provider.id === providerId 
          ? { ...provider, status: 'disconnected', access_token: undefined }
          : provider
      ));

      addToast({
        type: 'info',
        title: 'Provider Disconnected',
        message: 'Provider disconnected successfully'
      });
    }
  };

  const regenerateToken = (providerId: string) => {
    if (window.confirm('This will invalidate the current token. Continue?')) {
      const newToken = `${providers.find(p => p.id === providerId)?.type}_${Math.random().toString(36).substr(2, 20)}`;
      
      setProviders(prev => prev.map(provider => 
        provider.id === providerId 
          ? { ...provider, access_token: newToken }
          : provider
      ));

      addToast({
        type: 'warning',
        title: 'Token Regenerated',
        message: 'New access token generated. Update your CI configuration.'
      });
    }
  };

  const toggleTokenVisibility = (providerId: string) => {
    setShowTokens(prev => {
      const newSet = new Set(prev);
      if (newSet.has(providerId)) {
        newSet.delete(providerId);
      } else {
        newSet.add(providerId);
      }
      return newSet;
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    addToast({
      type: 'success',
      title: 'Copied',
      message: `${label} copied to clipboard`
    });
  };

  const filteredExecutions = executions.filter(exec => {
    const matchesSearch = searchTerm === '' || 
      exec.repository.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exec.branch.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exec.commit_message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exec.author.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === '' || exec.trigger_status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const stats = {
    totalProviders: providers.length,
    connectedProviders: providers.filter(p => p.status === 'connected').length,
    totalExecutions: executions.length,
    successfulExecutions: executions.filter(e => e.trigger_status === 'success').length,
    avgSuccessRate: providers.length > 0 ? 
      Math.round(providers.reduce((acc, p) => acc + p.success_rate, 0) / providers.length) : 0,
    avgExecutionTime: providers.length > 0 ?
      Math.round(providers.reduce((acc, p) => acc + p.avg_execution_time, 0) / providers.length * 10) / 10 : 0
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading CI/CD integrations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <GitBranch className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">CI/CD Integration</h1>
          <p className="text-gray-600">Connect the emulator platform to CI pipelines (GitHub, GitLab, Jenkins)</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowWebhookModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
          >
            <Webhook className="w-4 h-4" />
            Webhooks
          </button>
          <button
            onClick={() => setShowConnectModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Connect Provider
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Providers</p>
              <p className="text-2xl font-bold text-blue-600">{stats.connectedProviders}/{stats.totalProviders}</p>
            </div>
            <GitBranch className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Executions</p>
              <p className="text-2xl font-bold text-green-600">{stats.totalExecutions}</p>
            </div>
            <Activity className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Success Rate</p>
              <p className="text-2xl font-bold text-purple-600">{stats.avgSuccessRate}%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Duration</p>
              <p className="text-2xl font-bold text-orange-600">{stats.avgExecutionTime}m</p>
            </div>
            <Clock className="w-8 h-8 text-orange-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Webhooks</p>
              <p className="text-2xl font-bold text-indigo-600">{webhooks.filter(w => w.active).length}</p>
            </div>
            <Webhook className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Last 24h</p>
              <p className="text-2xl font-bold text-teal-600">
                {executions.filter(e => e.started_at > new Date(Date.now() - 86400000)).length}
              </p>
            </div>
            <Zap className="w-8 h-8 text-teal-600" />
          </div>
        </div>
      </div>

      {/* Integration Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {providers.map(provider => (
          <div key={provider.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="bg-gray-100 p-2 rounded-lg">
                  <provider.icon className="w-6 h-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{provider.name}</h3>
                  <p className="text-sm text-gray-500 capitalize">{provider.type}</p>
                </div>
              </div>
              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(provider.status)}`}>
                {getStatusIcon(provider.status)}
                {provider.status}
              </span>
            </div>

            <div className="space-y-3 mb-4">
              {provider.config.repository && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Repository:</span>
                  <span className="font-mono text-gray-900">{provider.config.repository}</span>
                </div>
              )}
              {provider.config.branch && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Branch:</span>
                  <span className="font-mono text-gray-900">{provider.config.branch}</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Triggers:</span>
                <span className="font-medium text-gray-900">{provider.trigger_count}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Success Rate:</span>
                <span className="font-medium text-green-600">{provider.success_rate}%</span>
              </div>
              {provider.last_trigger_time && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Last Trigger:</span>
                  <span className="text-gray-900">{provider.last_trigger_time.toLocaleString()}</span>
                </div>
              )}
            </div>

            {/* Access Token */}
            {provider.access_token && (
              <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Access Token</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleTokenVisibility(provider.id)}
                      className="p-1 text-gray-400 hover:text-gray-600"
                    >
                      {showTokens.has(provider.id) ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    </button>
                    <button
                      onClick={() => copyToClipboard(provider.access_token!, 'Access token')}
                      className="p-1 text-gray-400 hover:text-gray-600"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                <div className="font-mono text-xs text-gray-600 break-all">
                  {showTokens.has(provider.id) 
                    ? provider.access_token 
                    : provider.access_token.replace(/./g, '•')
                  }
                </div>
              </div>
            )}

            {/* Webhook URL */}
            {provider.webhook_url && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-700">Webhook URL</span>
                  <button
                    onClick={() => copyToClipboard(provider.webhook_url!, 'Webhook URL')}
                    className="p-1 text-blue-400 hover:text-blue-600"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
                <div className="font-mono text-xs text-blue-600 break-all">
                  {provider.webhook_url}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => testConnection(provider.id)}
                  disabled={testingConnection === provider.id}
                  className="flex items-center gap-1 px-3 py-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white rounded text-sm transition-colors"
                >
                  {testingConnection === provider.id ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <TestTube className="w-3 h-3" />
                  )}
                  Test
                </button>
                <button
                  onClick={() => setSelectedProvider(provider)}
                  className="flex items-center gap-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors"
                >
                  <Settings className="w-3 h-3" />
                  Configure
                </button>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => regenerateToken(provider.id)}
                  className="p-1 text-yellow-600 hover:bg-yellow-50 rounded transition-colors"
                  title="Regenerate Token"
                >
                  <Key className="w-4 h-4" />
                </button>
                <button
                  onClick={() => disconnectProvider(provider.id)}
                  className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                  title="Disconnect"
                >
                  <Unlink className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Execution Logs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">CI Execution Logs</h2>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search executions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Status</option>
                <option value="success">Success</option>
                <option value="failure">Failure</option>
                <option value="running">Running</option>
                <option value="pending">Pending</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Execution</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Repository</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trigger</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Duration</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredExecutions.map(execution => (
                <React.Fragment key={execution.id}>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setExpandedExecution(
                            expandedExecution === execution.id ? null : execution.id
                          )}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          {expandedExecution === execution.id ? 
                            <ChevronDown className="w-4 h-4" /> : 
                            <ChevronRight className="w-4 h-4" />
                          }
                        </button>
                        <div>
                          <div className="font-medium text-gray-900">{execution.commit_message}</div>
                          <div className="text-sm text-gray-500">
                            {execution.commit_hash} by {execution.author}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(execution.trigger_status)}`}>
                        {getStatusIcon(execution.trigger_status)}
                        {execution.trigger_status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{execution.repository}</div>
                      <div className="text-xs text-gray-500">{execution.branch}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900 capitalize">{execution.trigger_type.replace('_', ' ')}</div>
                      <div className="text-xs text-gray-500">{execution.provider_name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">
                        {execution.duration ? `${execution.duration}m` : '-'}
                      </div>
                      <div className="text-xs text-gray-500">
                        {execution.started_at.toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setSelectedExecution(execution)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                          title="View Logs"
                        >
                          <Terminal className="w-4 h-4" />
                        </button>
                        {execution.trigger_status === 'running' && (
                          <button
                            className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Cancel Execution"
                          >
                            <Square className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>

                  {/* Expanded Details */}
                  {expandedExecution === execution.id && (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 bg-gray-50">
                        <div className="space-y-4">
                          {/* Test Results */}
                          {execution.test_results && (
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Test Results</h4>
                              <div className="grid grid-cols-4 gap-4">
                                <div className="text-center p-2 bg-white rounded">
                                  <div className="text-lg font-bold text-gray-900">{execution.test_results.total}</div>
                                  <div className="text-xs text-gray-500">Total</div>
                                </div>
                                <div className="text-center p-2 bg-white rounded">
                                  <div className="text-lg font-bold text-green-600">{execution.test_results.passed}</div>
                                  <div className="text-xs text-gray-500">Passed</div>
                                </div>
                                <div className="text-center p-2 bg-white rounded">
                                  <div className="text-lg font-bold text-red-600">{execution.test_results.failed}</div>
                                  <div className="text-xs text-gray-500">Failed</div>
                                </div>
                                <div className="text-center p-2 bg-white rounded">
                                  <div className="text-lg font-bold text-yellow-600">{execution.test_results.skipped}</div>
                                  <div className="text-xs text-gray-500">Skipped</div>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Emulator Containers */}
                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Emulator Containers</h4>
                            <div className="flex flex-wrap gap-2">
                              {execution.emulator_containers.map(container => (
                                <span
                                  key={container}
                                  className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm"
                                >
                                  {container}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Execution Logs */}
                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Execution Logs</h4>
                            <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm max-h-64 overflow-y-auto">
                              {execution.logs.map((log, index) => (
                                <div key={index}>{log}</div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>

        {filteredExecutions.length === 0 && (
          <div className="p-12 text-center">
            <GitBranch className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No executions found</h3>
            <p className="text-gray-600">
              {searchTerm || statusFilter 
                ? 'Try adjusting your search or filters' 
                : 'CI executions will appear here when triggered'
              }
            </p>
          </div>
        )}
      </div>

      {/* Connect Provider Modal */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Connect CI Provider</h2>
                <button
                  onClick={() => setShowConnectModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Provider Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newProvider.type || ''}
                  onChange={(e) => setNewProvider(prev => ({ ...prev, type: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {providerTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Provider Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newProvider.name || ''}
                  onChange={(e) => setNewProvider(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="My CI Pipeline"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Repository</label>
                <input
                  type="text"
                  value={newProvider.config?.repository || ''}
                  onChange={(e) => setNewProvider(prev => ({ 
                    ...prev, 
                    config: { ...prev.config, repository: e.target.value }
                  }))}
                  placeholder="owner/repository"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Branch</label>
                <input
                  type="text"
                  value={newProvider.config?.branch || ''}
                  onChange={(e) => setNewProvider(prev => ({ 
                    ...prev, 
                    config: { ...prev.config, branch: e.target.value }
                  }))}
                  placeholder="main"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowConnectModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={connectProvider}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                Connect Provider
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Execution Detail Modal */}
      {selectedExecution && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Execution Details</h2>
                <button
                  onClick={() => setSelectedExecution(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Execution ID</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedExecution.id}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(selectedExecution.trigger_status)}`}>
                      {getStatusIcon(selectedExecution.trigger_status)}
                      {selectedExecution.trigger_status}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Repository</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedExecution.repository}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Branch</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedExecution.branch}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Commit</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedExecution.commit_hash}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Author</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedExecution.author}</div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500">Commit Message</label>
                <div className="mt-1 text-sm text-gray-900">{selectedExecution.commit_message}</div>
              </div>

              {selectedExecution.test_results && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Test Results</label>
                  <div className="mt-1 grid grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-lg font-bold text-gray-900">{selectedExecution.test_results.total}</div>
                      <div className="text-xs text-gray-500">Total Tests</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-lg font-bold text-green-600">{selectedExecution.test_results.passed}</div>
                      <div className="text-xs text-gray-500">Passed</div>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <div className="text-lg font-bold text-red-600">{selectedExecution.test_results.failed}</div>
                      <div className="text-xs text-gray-500">Failed</div>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <div className="text-lg font-bold text-yellow-600">{selectedExecution.test_results.skipped}</div>
                      <div className="text-xs text-gray-500">Skipped</div>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="text-sm font-medium text-gray-500">Execution Logs</label>
                <div className="mt-1 bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
                  {selectedExecution.logs.map((log, index) => (
                    <div key={index}>{log}</div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => copyToClipboard(selectedExecution.logs.join('\n'), 'Execution logs')}
                  className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Copy Logs
                </button>
                <button
                  onClick={() => setSelectedExecution(null)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};