import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Download, 
  Filter, 
  RefreshCw, 
  Clock, 
  Users, 
  Smartphone, 
  Activity, 
  Zap, 
  Target, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Eye, 
  FileText, 
  PieChart, 
  LineChart, 
  BarChart, 
  Settings, 
  Share, 
  Mail, 
  Save, 
  Upload, 
  Search, 
  X,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Copy,
  Globe,
  Server,
  Database,
  Network,
  Cpu,
  HardDrive,
  Monitor,
  Plus,
  Pause,
  Play,
  Edit,
  Trash2
} from 'lucide-react';

interface UsageStatistics {
  date: string;
  total_launches: number;
  successful_launches: number;
  failed_launches: number;
  avg_runtime: number; // in minutes
  peak_concurrent: number;
  unique_users: number;
  total_tasks: number;
  successful_tasks: number;
  failed_tasks: number;
  task_success_rate: number;
  cpu_avg: number;
  memory_avg: number;
  network_usage: number; // in GB
  top_apps: Array<{
    app_name: string;
    usage_count: number;
    avg_duration: number;
    success_rate: number;
  }>;
}

interface ReportFilter {
  dateRange: {
    start: string;
    end: string;
    preset: string;
  };
  apps: string[];
  modes: string[];
  users: string[];
  metrics: string[];
}

interface ScheduledReport {
  id: string;
  name: string;
  description: string;
  schedule: string; // cron expression
  format: 'pdf' | 'csv' | 'json';
  recipients: string[];
  filters: ReportFilter;
  last_run?: Date;
  next_run: Date;
  enabled: boolean;
  created_by: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const ReportsView: React.FC = () => {
  const [statistics, setStatistics] = useState<UsageStatistics[]>([]);
  const [filteredStats, setFilteredStats] = useState<UsageStatistics[]>([]);
  const [scheduledReports, setScheduledReports] = useState<ScheduledReport[]>([]);
  const [selectedChart, setSelectedChart] = useState<'launches' | 'tasks' | 'resources' | 'apps'>('launches');
  const [selectedDataPoint, setSelectedDataPoint] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [hoveredData, setHoveredData] = useState<any>(null);

  const [filters, setFilters] = useState<ReportFilter>({
    dateRange: {
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      end: new Date().toISOString().split('T')[0],
      preset: 'last30days'
    },
    apps: [],
    modes: [],
    users: [],
    metrics: ['launches', 'tasks', 'resources']
  });

  const [newReport, setNewReport] = useState<Partial<ScheduledReport>>({
    name: '',
    description: '',
    schedule: '0 9 * * 1', // Every Monday at 9 AM
    format: 'pdf',
    recipients: [],
    enabled: true
  });

  // Mock data generation
  useEffect(() => {
    const generateMockData = () => {
      const apps = ['Facebook', 'Instagram', 'WhatsApp', 'TikTok', 'Twitter', 'YouTube', 'Snapchat'];
      const users = ['john.doe', 'jane.smith', 'mike.wilson', 'sarah.davis', 'alex.chen'];
      
      const stats: UsageStatistics[] = [];
      const startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
      
      for (let i = 0; i < 90; i++) {
        const date = new Date(startDate.getTime() + i * 24 * 60 * 60 * 1000);
        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
        const baseMultiplier = isWeekend ? 0.6 : 1;
        
        const totalLaunches = Math.floor((Math.random() * 50 + 20) * baseMultiplier);
        const successfulLaunches = Math.floor(totalLaunches * (0.85 + Math.random() * 0.1));
        const totalTasks = Math.floor(totalLaunches * (1.5 + Math.random() * 0.5));
        const successfulTasks = Math.floor(totalTasks * (0.8 + Math.random() * 0.15));
        
        const topApps = apps.slice(0, Math.floor(Math.random() * 4) + 3).map(app => ({
          app_name: app,
          usage_count: Math.floor(Math.random() * 15) + 5,
          avg_duration: Math.floor(Math.random() * 30) + 10,
          success_rate: Math.floor(Math.random() * 20) + 80
        }));

        stats.push({
          date: date.toISOString().split('T')[0],
          total_launches: totalLaunches,
          successful_launches: successfulLaunches,
          failed_launches: totalLaunches - successfulLaunches,
          avg_runtime: Math.floor(Math.random() * 45) + 15,
          peak_concurrent: Math.floor(Math.random() * 20) + 5,
          unique_users: Math.floor(Math.random() * 15) + 5,
          total_tasks: totalTasks,
          successful_tasks: successfulTasks,
          failed_tasks: totalTasks - successfulTasks,
          task_success_rate: Math.round((successfulTasks / totalTasks) * 100),
          cpu_avg: Math.floor(Math.random() * 40) + 30,
          memory_avg: Math.floor(Math.random() * 35) + 40,
          network_usage: Math.round((Math.random() * 5 + 2) * 100) / 100,
          top_apps: topApps
        });
      }

      const mockScheduledReports: ScheduledReport[] = [
        {
          id: 'report-1',
          name: 'Weekly Usage Summary',
          description: 'Comprehensive weekly report of emulator usage and performance',
          schedule: '0 9 * * 1',
          format: 'pdf',
          recipients: ['admin@company.com', 'team@company.com'],
          filters: {
            dateRange: { start: '', end: '', preset: 'last7days' },
            apps: [],
            modes: [],
            users: [],
            metrics: ['launches', 'tasks', 'resources']
          },
          last_run: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          next_run: new Date(Date.now() + 24 * 60 * 60 * 1000),
          enabled: true,
          created_by: 'admin'
        },
        {
          id: 'report-2',
          name: 'Daily Task Performance',
          description: 'Daily breakdown of task execution and success rates',
          schedule: '0 8 * * *',
          format: 'csv',
          recipients: ['devops@company.com'],
          filters: {
            dateRange: { start: '', end: '', preset: 'yesterday' },
            apps: [],
            modes: [],
            users: [],
            metrics: ['tasks']
          },
          last_run: new Date(Date.now() - 24 * 60 * 60 * 1000),
          next_run: new Date(Date.now() + 8 * 60 * 60 * 1000),
          enabled: true,
          created_by: 'john.doe'
        }
      ];

      setStatistics(stats);
      setScheduledReports(mockScheduledReports);
      setLoading(false);
    };

    setTimeout(generateMockData, 1000);
  }, []);

  // Filter statistics
  useEffect(() => {
    let filtered = statistics;

    if (filters.dateRange.start && filters.dateRange.end) {
      filtered = filtered.filter(stat => 
        stat.date >= filters.dateRange.start && stat.date <= filters.dateRange.end
      );
    }

    setFilteredStats(filtered);
  }, [statistics, filters]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const downloadReport = async (format: 'pdf' | 'csv' | 'json') => {
    // Simulate report generation
    addToast({
      type: 'info',
      title: 'Generating Report',
      message: `Preparing ${format.toUpperCase()} report...`
    });

    setTimeout(() => {
      const filename = `emulator-usage-report-${new Date().toISOString().split('T')[0]}.${format}`;
      
      if (format === 'csv') {
        const csvContent = [
          'Date,Total Launches,Successful Launches,Failed Launches,Avg Runtime,Task Success Rate',
          ...filteredStats.map(stat => 
            `${stat.date},${stat.total_launches},${stat.successful_launches},${stat.failed_launches},${stat.avg_runtime},${stat.task_success_rate}`
          )
        ].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
      } else if (format === 'json') {
        const jsonContent = JSON.stringify(filteredStats, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
      }

      addToast({
        type: 'success',
        title: 'Report Downloaded',
        message: `${filename} downloaded successfully`
      });
    }, 2000);
  };

  const createScheduledReport = () => {
    if (!newReport.name || !newReport.schedule) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Name and schedule are required'
      });
      return;
    }

    const report: ScheduledReport = {
      id: `report-${Date.now()}`,
      name: newReport.name!,
      description: newReport.description || '',
      schedule: newReport.schedule!,
      format: newReport.format!,
      recipients: newReport.recipients || [],
      filters: { ...filters },
      next_run: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      enabled: newReport.enabled!,
      created_by: 'current-user'
    };

    setScheduledReports(prev => [...prev, report]);
    setShowScheduleModal(false);
    setNewReport({
      name: '',
      description: '',
      schedule: '0 9 * * 1',
      format: 'pdf',
      recipients: [],
      enabled: true
    });

    addToast({
      type: 'success',
      title: 'Scheduled Report Created',
      message: `Report "${report.name}" scheduled successfully`
    });
  };

  const toggleReport = (reportId: string) => {
    setScheduledReports(prev => prev.map(report => 
      report.id === reportId 
        ? { ...report, enabled: !report.enabled }
        : report
    ));
  };

  const deleteReport = (reportId: string) => {
    if (window.confirm('Are you sure you want to delete this scheduled report?')) {
      setScheduledReports(prev => prev.filter(report => report.id !== reportId));
      addToast({
        type: 'success',
        title: 'Report Deleted',
        message: 'Scheduled report deleted successfully'
      });
    }
  };

  const setDatePreset = (preset: string) => {
    const now = new Date();
    let start: Date;
    let end = now;

    switch (preset) {
      case 'today':
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'yesterday':
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
        break;
      case 'last7days':
        start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'last30days':
        start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case 'last90days':
        start = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        return;
    }

    setFilters(prev => ({
      ...prev,
      dateRange: {
        start: start.toISOString().split('T')[0],
        end: end.toISOString().split('T')[0],
        preset
      }
    }));
  };

  const handleDataPointClick = (date: string) => {
    setSelectedDataPoint(date);
  };

  const selectedDayData = selectedDataPoint ? filteredStats.find(s => s.date === selectedDataPoint) : null;

  // Calculate summary statistics
  const summaryStats = {
    totalLaunches: filteredStats.reduce((acc, stat) => acc + stat.total_launches, 0),
    avgSuccessRate: filteredStats.length > 0 ? 
      Math.round(filteredStats.reduce((acc, stat) => acc + (stat.successful_launches / stat.total_launches * 100), 0) / filteredStats.length) : 0,
    totalTasks: filteredStats.reduce((acc, stat) => acc + stat.total_tasks, 0),
    avgTaskSuccessRate: filteredStats.length > 0 ?
      Math.round(filteredStats.reduce((acc, stat) => acc + stat.task_success_rate, 0) / filteredStats.length) : 0,
    avgRuntime: filteredStats.length > 0 ?
      Math.round(filteredStats.reduce((acc, stat) => acc + stat.avg_runtime, 0) / filteredStats.length) : 0,
    peakConcurrent: Math.max(...filteredStats.map(s => s.peak_concurrent), 0),
    uniqueUsers: Math.max(...filteredStats.map(s => s.unique_users), 0),
    totalNetworkUsage: filteredStats.reduce((acc, stat) => acc + stat.network_usage, 0)
  };

  // Get top apps across all filtered data
  const allApps = filteredStats.flatMap(stat => stat.top_apps);
  const appUsageMap = new Map<string, { count: number; duration: number; successRate: number }>();
  
  allApps.forEach(app => {
    const existing = appUsageMap.get(app.app_name) || { count: 0, duration: 0, successRate: 0 };
    appUsageMap.set(app.app_name, {
      count: existing.count + app.usage_count,
      duration: existing.duration + app.avg_duration,
      successRate: existing.successRate + app.success_rate
    });
  });

  const topApps = Array.from(appUsageMap.entries())
    .map(([name, data]) => ({
      app_name: name,
      usage_count: data.count,
      avg_duration: Math.round(data.duration / filteredStats.length),
      success_rate: Math.round(data.successRate / filteredStats.length)
    }))
    .sort((a, b) => b.usage_count - a.usage_count)
    .slice(0, 5);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading usage statistics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <BarChart3 className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports & Usage Statistics</h1>
          <p className="text-gray-600">Visualize usage patterns, emulator uptime, and resource consumption</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showFilters ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
          >
            <Clock className="w-4 h-4" />
            Schedule Report
          </button>
          <div className="relative">
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors group">
              <Download className="w-4 h-4" />
              Download
              <ChevronDown className="w-4 h-4" />
            </button>
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <button
                onClick={() => downloadReport('pdf')}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                PDF Report
              </button>
              <button
                onClick={() => downloadReport('csv')}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
              >
                <BarChart3 className="w-4 h-4" />
                CSV Data
              </button>
              <button
                onClick={() => downloadReport('json')}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
              >
                <Database className="w-4 h-4" />
                JSON Export
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Report Filters</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <div className="space-y-2">
                <div className="flex gap-2">
                  {['today', 'yesterday', 'last7days', 'last30days', 'last90days'].map(preset => (
                    <button
                      key={preset}
                      onClick={() => setDatePreset(preset)}
                      className={`px-2 py-1 text-xs rounded ${
                        filters.dateRange.preset === preset
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {preset.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={filters.dateRange.start}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      dateRange: { ...prev.dateRange, start: e.target.value, preset: 'custom' }
                    }))}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                  <input
                    type="date"
                    value={filters.dateRange.end}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      dateRange: { ...prev.dateRange, end: e.target.value, preset: 'custom' }
                    }))}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Apps</label>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {['Facebook', 'Instagram', 'WhatsApp', 'TikTok', 'Twitter', 'YouTube'].map(app => (
                  <label key={app} className="flex items-center text-sm">
                    <input
                      type="checkbox"
                      checked={filters.apps.includes(app)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFilters(prev => ({ ...prev, apps: [...prev.apps, app] }));
                        } else {
                          setFilters(prev => ({ ...prev, apps: prev.apps.filter(a => a !== app) }));
                        }
                      }}
                      className="mr-2 h-3 w-3 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    {app}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Launch Mode</label>
              <div className="space-y-1">
                {['Auto', 'Manual'].map(mode => (
                  <label key={mode} className="flex items-center text-sm">
                    <input
                      type="checkbox"
                      checked={filters.modes.includes(mode)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFilters(prev => ({ ...prev, modes: [...prev.modes, mode] }));
                        } else {
                          setFilters(prev => ({ ...prev, modes: prev.modes.filter(m => m !== mode) }));
                        }
                      }}
                      className="mr-2 h-3 w-3 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    {mode}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Metrics</label>
              <div className="space-y-1">
                {[
                  { id: 'launches', label: 'Launches' },
                  { id: 'tasks', label: 'Tasks' },
                  { id: 'resources', label: 'Resources' },
                  { id: 'users', label: 'Users' }
                ].map(metric => (
                  <label key={metric.id} className="flex items-center text-sm">
                    <input
                      type="checkbox"
                      checked={filters.metrics.includes(metric.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFilters(prev => ({ ...prev, metrics: [...prev.metrics, metric.id] }));
                        } else {
                          setFilters(prev => ({ ...prev, metrics: prev.metrics.filter(m => m !== metric.id) }));
                        }
                      }}
                      className="mr-2 h-3 w-3 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    {metric.label}
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-8 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Launches</p>
              <p className="text-2xl font-bold text-blue-600">{summaryStats.totalLaunches.toLocaleString()}</p>
            </div>
            <Smartphone className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Success Rate</p>
              <p className="text-2xl font-bold text-green-600">{summaryStats.avgSuccessRate}%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Tasks</p>
              <p className="text-2xl font-bold text-purple-600">{summaryStats.totalTasks.toLocaleString()}</p>
            </div>
            <Activity className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Task Success</p>
              <p className="text-2xl font-bold text-indigo-600">{summaryStats.avgTaskSuccessRate}%</p>
            </div>
            <Target className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Runtime</p>
              <p className="text-2xl font-bold text-orange-600">{summaryStats.avgRuntime}m</p>
            </div>
            <Clock className="w-8 h-8 text-orange-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Peak Concurrent</p>
              <p className="text-2xl font-bold text-red-600">{summaryStats.peakConcurrent}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-red-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Unique Users</p>
              <p className="text-2xl font-bold text-teal-600">{summaryStats.uniqueUsers}</p>
            </div>
            <Users className="w-8 h-8 text-teal-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Network Usage</p>
              <p className="text-2xl font-bold text-pink-600">{summaryStats.totalNetworkUsage.toFixed(1)}GB</p>
            </div>
            <Network className="w-8 h-8 text-pink-600" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Usage Trends</h2>
            <div className="flex items-center gap-2">
              {[
                { id: 'launches', label: 'Launches', icon: Smartphone },
                { id: 'tasks', label: 'Tasks', icon: Activity },
                { id: 'resources', label: 'Resources', icon: Cpu },
                { id: 'apps', label: 'Apps', icon: BarChart3 }
              ].map(chart => (
                <button
                  key={chart.id}
                  onClick={() => setSelectedChart(chart.id as any)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                    selectedChart === chart.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <chart.icon className="w-4 h-4" />
                  {chart.label}
                </button>
              ))}
            </div>
          </div>

          {/* Mock Chart Area */}
          <div className="h-80 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 p-4">
              {/* Simulated chart with clickable data points */}
              <div className="h-full flex items-end justify-between gap-1">
                {filteredStats.slice(-30).map((stat, index) => {
                  const value = selectedChart === 'launches' ? stat.total_launches :
                               selectedChart === 'tasks' ? stat.total_tasks :
                               selectedChart === 'resources' ? stat.cpu_avg :
                               stat.top_apps.length;
                  const maxValue = selectedChart === 'launches' ? 100 :
                                  selectedChart === 'tasks' ? 150 :
                                  selectedChart === 'resources' ? 100 :
                                  10;
                  const height = (value / maxValue) * 100;
                  
                  return (
                    <div
                      key={stat.date}
                      className="flex-1 bg-blue-500 hover:bg-blue-600 cursor-pointer transition-all rounded-t relative group"
                      style={{ height: `${Math.max(height, 5)}%` }}
                      onClick={() => handleDataPointClick(stat.date)}
                      onMouseEnter={() => setHoveredData({ date: stat.date, value, index })}
                      onMouseLeave={() => setHoveredData(null)}
                    >
                      {hoveredData?.index === index && (
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-900 text-white text-xs rounded px-2 py-1 whitespace-nowrap z-10">
                          {new Date(stat.date).toLocaleDateString()}: {value}
                          {selectedChart === 'resources' && '%'}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="text-center z-10">
              <BarChart3 className="w-16 h-16 text-blue-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-blue-900 mb-2">
                {selectedChart === 'launches' && 'Daily Emulator Launches'}
                {selectedChart === 'tasks' && 'Task Execution Trends'}
                {selectedChart === 'resources' && 'Resource Utilization'}
                {selectedChart === 'apps' && 'App Usage Distribution'}
              </h3>
              <p className="text-blue-700">
                {selectedChart === 'launches' && 'Click on bars to view daily details'}
                {selectedChart === 'tasks' && 'Hover to see task execution data'}
                {selectedChart === 'resources' && 'CPU and memory usage over time'}
                {selectedChart === 'apps' && 'Most popular apps by usage'}
              </p>
            </div>
          </div>
        </div>

        {/* Top Apps */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Top Apps</h2>
          <div className="space-y-3">
            {topApps.map((app, index) => (
              <div key={app.app_name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-blue-600 font-bold text-sm">{index + 1}</span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{app.app_name}</div>
                    <div className="text-sm text-gray-500">{app.usage_count} launches</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{app.avg_duration}m</div>
                  <div className="text-xs text-green-600">{app.success_rate}% success</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Day Details */}
      {selectedDayData && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Details for {new Date(selectedDayData.date).toLocaleDateString()}
            </h2>
            <button
              onClick={() => setSelectedDataPoint(null)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{selectedDayData.total_launches}</div>
              <div className="text-sm text-blue-700">Total Launches</div>
              <div className="text-xs text-gray-600 mt-1">
                {selectedDayData.successful_launches} successful, {selectedDayData.failed_launches} failed
              </div>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{selectedDayData.total_tasks}</div>
              <div className="text-sm text-green-700">Total Tasks</div>
              <div className="text-xs text-gray-600 mt-1">
                {selectedDayData.task_success_rate}% success rate
              </div>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{selectedDayData.avg_runtime}m</div>
              <div className="text-sm text-orange-700">Avg Runtime</div>
              <div className="text-xs text-gray-600 mt-1">
                Peak: {selectedDayData.peak_concurrent} concurrent
              </div>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{selectedDayData.unique_users}</div>
              <div className="text-sm text-purple-700">Unique Users</div>
              <div className="text-xs text-gray-600 mt-1">
                {selectedDayData.network_usage.toFixed(1)}GB network usage
              </div>
            </div>
          </div>
          
          {/* Day's Top Apps */}
          <div className="mt-6">
            <h3 className="font-medium text-gray-900 mb-3">Top Apps This Day</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {selectedDayData.top_apps.slice(0, 6).map(app => (
                <div key={app.app_name} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium text-gray-900">{app.app_name}</span>
                  <span className="text-sm text-gray-600">{app.usage_count} uses</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Scheduled Reports */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Scheduled Reports</h2>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Schedule
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Report</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Schedule</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Format</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Recipients</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Next Run</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {scheduledReports.map(report => (
                <tr key={report.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <div className="font-medium text-gray-900">{report.name}</div>
                      <div className="text-sm text-gray-500">{report.description}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 font-mono">{report.schedule}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded uppercase">
                      {report.format}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{report.recipients.length} recipients</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{report.next_run.toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                      report.enabled 
                        ? 'text-green-600 bg-green-100' 
                        : 'text-gray-600 bg-gray-100'
                    }`}>
                      {report.enabled ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                      {report.enabled ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleReport(report.id)}
                        className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title={report.enabled ? 'Disable' : 'Enable'}
                      >
                        {report.enabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                      <button
                        className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                        title="Edit Report"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteReport(report.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Delete Report"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Schedule Report Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Schedule New Report</h2>
                <button
                  onClick={() => setShowScheduleModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Report Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newReport.name || ''}
                  onChange={(e) => setNewReport(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Weekly Usage Report"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={newReport.description || ''}
                  onChange={(e) => setNewReport(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe what this report contains..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Schedule (Cron) <span className="text-red-500">*</span>
                </label>
                <select
                  value={newReport.schedule || ''}
                  onChange={(e) => setNewReport(prev => ({ ...prev, schedule: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="0 9 * * 1">Weekly (Monday 9 AM)</option>
                  <option value="0 8 * * *">Daily (8 AM)</option>
                  <option value="0 9 * * 0">Weekly (Sunday 9 AM)</option>
                  <option value="0 9 1 * *">Monthly (1st day 9 AM)</option>
                  <option value="0 9 * * 1-5">Weekdays (9 AM)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Format</label>
                <select
                  value={newReport.format || 'pdf'}
                  onChange={(e) => setNewReport(prev => ({ ...prev, format: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="pdf">PDF Report</option>
                  <option value="csv">CSV Data</option>
                  <option value="json">JSON Export</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Recipients (comma-separated)</label>
                <input
                  type="text"
                  value={newReport.recipients?.join(', ') || ''}
                  onChange={(e) => setNewReport(prev => ({ 
                    ...prev, 
                    recipients: e.target.value.split(',').map(email => email.trim()).filter(email => email)
                  }))}
                  placeholder="admin@company.com, team@company.com"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={newReport.enabled || false}
                  onChange={(e) => setNewReport(prev => ({ ...prev, enabled: e.target.checked }))}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="ml-2 text-sm text-gray-700">Enable immediately</label>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowScheduleModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={createScheduledReport}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg"
              >
                Schedule Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};