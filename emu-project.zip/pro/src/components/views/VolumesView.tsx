import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Plus, 
  Trash2, 
  Copy, 
  HardDrive, 
  Calendar, 
  User, 
  Link, 
  Unlink, 
  Download, 
  Upload, 
  RefreshCw, 
  Search, 
  Filter, 
  MoreVertical, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Eye, 
  Edit, 
  Archive, 
  FolderOpen, 
  Smartphone, 
  Settings, 
  X, 
  Save, 
  FileText, 
  Folder, 
  Image, 
  Video, 
  Music, 
  File,
  Monitor,
  Activity,
  Zap,
  Shield,
  Globe
} from 'lucide-react';

interface Volume {
  volume_id: string;
  avatar_uuid: string;
  avatar_name: string;
  size_mb: number;
  mount_status: 'mounted' | 'unmounted' | 'mounting' | 'error';
  linked_container_id?: string;
  container_name?: string;
  created_at: Date;
  last_accessed: Date;
  created_by: string;
  backup_count: number;
  file_count: number;
  app_data: {
    app_name: string;
    version: string;
    data_size: number;
  }[];
  tags: string[];
  description?: string;
}

interface VolumeFilter {
  searchTerm: string;
  mountStatus: string;
  createdBy: string;
  sizeRange: {
    min: number;
    max: number;
  };
  dateRange: {
    start: string;
    end: string;
  };
  tags: string[];
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

interface CreateVolumeForm {
  avatar_uuid: string;
  avatar_name: string;
  description: string;
  clone_from?: string;
  initial_size: number;
  tags: string[];
}

export const VolumesView: React.FC = () => {
  const [volumes, setVolumes] = useState<Volume[]>([]);
  const [filteredVolumes, setFilteredVolumes] = useState<Volume[]>([]);
  const [selectedVolumes, setSelectedVolumes] = useState<Set<string>>(new Set());
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedVolume, setSelectedVolume] = useState<Volume | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const [filters, setFilters] = useState<VolumeFilter>({
    searchTerm: '',
    mountStatus: '',
    createdBy: '',
    sizeRange: { min: 0, max: 10000 },
    dateRange: { start: '', end: '' },
    tags: []
  });

  const [createForm, setCreateForm] = useState<CreateVolumeForm>({
    avatar_uuid: '',
    avatar_name: '',
    description: '',
    initial_size: 1024,
    tags: []
  });

  // Mock data
  useEffect(() => {
    const generateMockVolumes = (): Volume[] => {
      const apps = ['Facebook', 'Instagram', 'WhatsApp', 'TikTok', 'Twitter', 'YouTube', 'Snapchat', 'Telegram'];
      const users = ['john.doe', 'jane.smith', 'admin', 'mike.wilson', 'sarah.davis'];
      const tags = ['production', 'testing', 'development', 'backup', 'archived', 'critical', 'temporary'];
      
      return Array.from({ length: 25 }, (_, i) => {
        const createdAt = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000);
        const lastAccessed = new Date(createdAt.getTime() + Math.random() * (Date.now() - createdAt.getTime()));
        const appData = apps.slice(0, Math.floor(Math.random() * 3) + 1).map(app => ({
          app_name: app,
          version: `${Math.floor(Math.random() * 5) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
          data_size: Math.floor(Math.random() * 500) + 50
        }));

        return {
          volume_id: `vol-${i.toString().padStart(3, '0')}`,
          avatar_uuid: `avatar-${Math.random().toString(36).substr(2, 8)}`,
          avatar_name: `Avatar ${i + 1}`,
          size_mb: Math.floor(Math.random() * 8000) + 500,
          mount_status: ['mounted', 'unmounted', 'mounting', 'error'][Math.floor(Math.random() * 4)] as Volume['mount_status'],
          linked_container_id: Math.random() > 0.4 ? `emulator-${Math.floor(Math.random() * 5) + 1}` : undefined,
          container_name: Math.random() > 0.4 ? `Container ${Math.floor(Math.random() * 5) + 1}` : undefined,
          created_at: createdAt,
          last_accessed: lastAccessed,
          created_by: users[Math.floor(Math.random() * users.length)],
          backup_count: Math.floor(Math.random() * 10),
          file_count: Math.floor(Math.random() * 1000) + 100,
          app_data: appData,
          tags: tags.slice(0, Math.floor(Math.random() * 3) + 1),
          description: Math.random() > 0.5 ? `Volume for ${appData[0]?.app_name} testing and development` : undefined
        };
      });
    };

    setTimeout(() => {
      setVolumes(generateMockVolumes());
      setLoading(false);
    }, 1000);
  }, []);

  // Filter volumes
  useEffect(() => {
    let filtered = volumes;

    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(volume => 
        volume.avatar_uuid.toLowerCase().includes(searchLower) ||
        volume.avatar_name.toLowerCase().includes(searchLower) ||
        volume.volume_id.toLowerCase().includes(searchLower) ||
        volume.created_by.toLowerCase().includes(searchLower) ||
        volume.app_data.some(app => app.app_name.toLowerCase().includes(searchLower))
      );
    }

    if (filters.mountStatus) {
      filtered = filtered.filter(volume => volume.mount_status === filters.mountStatus);
    }

    if (filters.createdBy) {
      filtered = filtered.filter(volume => volume.created_by === filters.createdBy);
    }

    if (filters.sizeRange.min > 0 || filters.sizeRange.max < 10000) {
      filtered = filtered.filter(volume => 
        volume.size_mb >= filters.sizeRange.min && volume.size_mb <= filters.sizeRange.max
      );
    }

    if (filters.dateRange.start) {
      const startDate = new Date(filters.dateRange.start);
      filtered = filtered.filter(volume => volume.created_at >= startDate);
    }

    if (filters.dateRange.end) {
      const endDate = new Date(filters.dateRange.end);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(volume => volume.created_at <= endDate);
    }

    if (filters.tags.length > 0) {
      filtered = filtered.filter(volume => 
        filters.tags.some(tag => volume.tags.includes(tag))
      );
    }

    setFilteredVolumes(filtered);
  }, [volumes, filters]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'mounted': return 'text-green-600 bg-green-100 border-green-200';
      case 'unmounted': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'mounting': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'error': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'mounted': return <CheckCircle className="w-4 h-4" />;
      case 'unmounted': return <XCircle className="w-4 h-4" />;
      case 'mounting': return <Clock className="w-4 h-4 animate-pulse" />;
      case 'error': return <AlertTriangle className="w-4 h-4" />;
      default: return <XCircle className="w-4 h-4" />;
    }
  };

  const formatSize = (sizeInMB: number): string => {
    if (sizeInMB >= 1024) {
      return `${(sizeInMB / 1024).toFixed(1)} GB`;
    }
    return `${sizeInMB} MB`;
  };

  const mountVolume = async (volumeId: string) => {
    setVolumes(prev => prev.map(v => 
      v.volume_id === volumeId 
        ? { ...v, mount_status: 'mounting' as const }
        : v
    ));

    setTimeout(() => {
      setVolumes(prev => prev.map(v => 
        v.volume_id === volumeId 
          ? { ...v, mount_status: 'mounted' as const, linked_container_id: 'emulator-1', container_name: 'Container 1' }
          : v
      ));
      
      addToast({
        type: 'success',
        title: 'Volume Mounted',
        message: `Volume ${volumeId} mounted successfully`
      });
    }, 2000);
  };

  const unmountVolume = async (volumeId: string) => {
    setVolumes(prev => prev.map(v => 
      v.volume_id === volumeId 
        ? { ...v, mount_status: 'unmounted' as const, linked_container_id: undefined, container_name: undefined }
        : v
    ));
    
    addToast({
      type: 'info',
      title: 'Volume Unmounted',
      message: `Volume ${volumeId} unmounted successfully`
    });
  };

  const deleteVolume = async (volumeId: string) => {
    if (window.confirm('Are you sure you want to delete this volume? This action cannot be undone.')) {
      setVolumes(prev => prev.filter(v => v.volume_id !== volumeId));
      addToast({
        type: 'success',
        title: 'Volume Deleted',
        message: `Volume ${volumeId} deleted successfully`
      });
    }
  };

  const cloneVolume = async (volumeId: string) => {
    const originalVolume = volumes.find(v => v.volume_id === volumeId);
    if (!originalVolume) return;

    const newVolume: Volume = {
      ...originalVolume,
      volume_id: `vol-clone-${Date.now()}`,
      avatar_uuid: `avatar-${Math.random().toString(36).substr(2, 8)}`,
      avatar_name: `${originalVolume.avatar_name} (Clone)`,
      created_at: new Date(),
      last_accessed: new Date(),
      mount_status: 'unmounted',
      linked_container_id: undefined,
      container_name: undefined,
      backup_count: 0,
      tags: [...originalVolume.tags, 'cloned']
    };

    setVolumes(prev => [newVolume, ...prev]);
    addToast({
      type: 'success',
      title: 'Volume Cloned',
      message: `Volume cloned as ${newVolume.volume_id}`
    });
  };

  const createVolume = async () => {
    if (!createForm.avatar_uuid || !createForm.avatar_name) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Avatar UUID and name are required'
      });
      return;
    }

    const newVolume: Volume = {
      volume_id: `vol-${Date.now()}`,
      avatar_uuid: createForm.avatar_uuid,
      avatar_name: createForm.avatar_name,
      size_mb: createForm.initial_size,
      mount_status: 'unmounted',
      created_at: new Date(),
      last_accessed: new Date(),
      created_by: 'current-user',
      backup_count: 0,
      file_count: 0,
      app_data: [],
      tags: createForm.tags,
      description: createForm.description
    };

    setVolumes(prev => [newVolume, ...prev]);
    setShowCreateModal(false);
    setCreateForm({
      avatar_uuid: '',
      avatar_name: '',
      description: '',
      initial_size: 1024,
      tags: []
    });

    addToast({
      type: 'success',
      title: 'Volume Created',
      message: `Volume ${newVolume.volume_id} created successfully`
    });
  };

  const bulkAction = async (action: 'mount' | 'unmount' | 'delete') => {
    const selectedVolumesList = Array.from(selectedVolumes);
    
    if (action === 'delete') {
      if (!window.confirm(`Are you sure you want to delete ${selectedVolumesList.length} volumes? This action cannot be undone.`)) {
        return;
      }
    }

    for (const volumeId of selectedVolumesList) {
      switch (action) {
        case 'mount':
          await mountVolume(volumeId);
          break;
        case 'unmount':
          await unmountVolume(volumeId);
          break;
        case 'delete':
          setVolumes(prev => prev.filter(v => v.volume_id !== volumeId));
          break;
      }
    }

    setSelectedVolumes(new Set());
    addToast({
      type: 'success',
      title: 'Bulk Action Complete',
      message: `${action} completed for ${selectedVolumesList.length} volumes`
    });
  };

  const clearFilters = () => {
    setFilters({
      searchTerm: '',
      mountStatus: '',
      createdBy: '',
      sizeRange: { min: 0, max: 10000 },
      dateRange: { start: '', end: '' },
      tags: []
    });
  };

  const stats = {
    total: volumes.length,
    mounted: volumes.filter(v => v.mount_status === 'mounted').length,
    totalSize: volumes.reduce((acc, v) => acc + v.size_mb, 0),
    avgSize: volumes.length > 0 ? volumes.reduce((acc, v) => acc + v.size_mb, 0) / volumes.length : 0
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading volumes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <Database className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Volume Management</h1>
          <p className="text-gray-600">Manage persistent avatar profiles and emulator volumes</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showFilters ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create Volume
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Volumes</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <Database className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Mounted</p>
              <p className="text-2xl font-bold text-green-600">{stats.mounted}</p>
            </div>
            <Link className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Size</p>
              <p className="text-2xl font-bold text-purple-600">{formatSize(stats.totalSize)}</p>
            </div>
            <HardDrive className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Size</p>
              <p className="text-2xl font-bold text-orange-600">{formatSize(stats.avgSize)}</p>
            </div>
            <Activity className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search by Avatar UUID, name, or volume ID..."
              value={filters.searchTerm}
              onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="p-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
            >
              {viewMode === 'grid' ? <FileText className="w-4 h-4" /> : <Database className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mount Status</label>
              <select
                value={filters.mountStatus}
                onChange={(e) => setFilters(prev => ({ ...prev, mountStatus: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Status</option>
                <option value="mounted">Mounted</option>
                <option value="unmounted">Unmounted</option>
                <option value="mounting">Mounting</option>
                <option value="error">Error</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Created By</label>
              <select
                value={filters.createdBy}
                onChange={(e) => setFilters(prev => ({ ...prev, createdBy: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Users</option>
                <option value="john.doe">john.doe</option>
                <option value="jane.smith">jane.smith</option>
                <option value="admin">admin</option>
                <option value="mike.wilson">mike.wilson</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Size Range (MB)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="Min"
                  value={filters.sizeRange.min || ''}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    sizeRange: { ...prev.sizeRange, min: parseInt(e.target.value) || 0 }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
                <input
                  type="number"
                  placeholder="Max"
                  value={filters.sizeRange.max === 10000 ? '' : filters.sizeRange.max}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    sizeRange: { ...prev.sizeRange, max: parseInt(e.target.value) || 10000 }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={filters.dateRange.start}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    dateRange: { ...prev.dateRange, start: e.target.value }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
                <input
                  type="date"
                  value={filters.dateRange.end}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    dateRange: { ...prev.dateRange, end: e.target.value }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
              </div>
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button
                onClick={clearFilters}
                className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                Clear Filters
              </button>
            </div>
          </div>
        )}

        {/* Bulk Actions */}
        {selectedVolumes.size > 0 && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-blue-900">
                {selectedVolumes.size} volume(s) selected
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => bulkAction('mount')}
                  className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-colors"
                >
                  Mount All
                </button>
                <button
                  onClick={() => bulkAction('unmount')}
                  className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded text-sm transition-colors"
                >
                  Unmount All
                </button>
                <button
                  onClick={() => bulkAction('delete')}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm transition-colors"
                >
                  Delete All
                </button>
                <button
                  onClick={() => setSelectedVolumes(new Set())}
                  className="px-3 py-1 text-gray-600 hover:text-gray-900 border border-gray-300 rounded text-sm transition-colors"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Volumes Display */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVolumes.map((volume) => (
            <div
              key={volume.volume_id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={selectedVolumes.has(volume.volume_id)}
                    onChange={(e) => {
                      const newSelected = new Set(selectedVolumes);
                      if (e.target.checked) {
                        newSelected.add(volume.volume_id);
                      } else {
                        newSelected.delete(volume.volume_id);
                      }
                      setSelectedVolumes(newSelected);
                    }}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <div className="bg-gray-100 p-2 rounded-lg">
                    <Database className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{volume.avatar_name}</h3>
                    <p className="text-sm text-gray-500 font-mono">{volume.avatar_uuid}</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(volume.mount_status)}`}>
                  {getStatusIcon(volume.mount_status)}
                  {volume.mount_status}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Volume ID:</span>
                  <span className="font-mono text-gray-900">{volume.volume_id}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Size:</span>
                  <span className="font-medium text-gray-900">{formatSize(volume.size_mb)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Files:</span>
                  <span className="text-gray-900">{volume.file_count.toLocaleString()}</span>
                </div>
                {volume.linked_container_id && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Container:</span>
                    <span className="text-blue-600">{volume.container_name}</span>
                  </div>
                )}
              </div>

              {/* App Data */}
              {volume.app_data.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">App Data:</p>
                  <div className="space-y-1">
                    {volume.app_data.slice(0, 2).map((app, index) => (
                      <div key={index} className="flex items-center justify-between text-xs">
                        <span className="text-gray-600">{app.app_name}</span>
                        <span className="text-gray-500">{formatSize(app.data_size)}</span>
                      </div>
                    ))}
                    {volume.app_data.length > 2 && (
                      <p className="text-xs text-gray-500">+{volume.app_data.length - 2} more apps</p>
                    )}
                  </div>
                </div>
              )}

              {/* Tags */}
              {volume.tags.length > 0 && (
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {volume.tags.slice(0, 3).map(tag => (
                      <span key={tag} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                    {volume.tags.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                        +{volume.tags.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  {volume.mount_status === 'unmounted' ? (
                    <button
                      onClick={() => mountVolume(volume.volume_id)}
                      className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                      title="Mount Volume"
                    >
                      <Link className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => unmountVolume(volume.volume_id)}
                      className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                      title="Unmount Volume"
                    >
                      <Unlink className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={() => cloneVolume(volume.volume_id)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Clone Volume"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setSelectedVolume(volume)}
                    className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteVolume(volume.volume_id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete Volume"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs text-gray-500">
                  {volume.created_at.toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedVolumes.size === filteredVolumes.length && filteredVolumes.length > 0}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedVolumes(new Set(filteredVolumes.map(v => v.volume_id)));
                        } else {
                          setSelectedVolumes(new Set());
                        }
                      }}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Container</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredVolumes.map((volume) => (
                  <tr key={volume.volume_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <input
                        type="checkbox"
                        checked={selectedVolumes.has(volume.volume_id)}
                        onChange={(e) => {
                          const newSelected = new Set(selectedVolumes);
                          if (e.target.checked) {
                            newSelected.add(volume.volume_id);
                          } else {
                            newSelected.delete(volume.volume_id);
                          }
                          setSelectedVolumes(newSelected);
                        }}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <Database className="w-5 h-5 text-gray-400" />
                        <div>
                          <div className="font-medium text-gray-900">{volume.avatar_name}</div>
                          <div className="text-sm text-gray-500 font-mono">{volume.avatar_uuid}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(volume.mount_status)}`}>
                        {getStatusIcon(volume.mount_status)}
                        {volume.mount_status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{formatSize(volume.size_mb)}</div>
                      <div className="text-xs text-gray-500">{volume.file_count.toLocaleString()} files</div>
                    </td>
                    <td className="px-6 py-4">
                      {volume.linked_container_id ? (
                        <div className="text-sm text-blue-600">{volume.container_name}</div>
                      ) : (
                        <div className="text-sm text-gray-500">Not mounted</div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{volume.created_at.toLocaleDateString()}</div>
                      <div className="text-xs text-gray-500">by {volume.created_by}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        {volume.mount_status === 'unmounted' ? (
                          <button
                            onClick={() => mountVolume(volume.volume_id)}
                            className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                            title="Mount"
                          >
                            <Link className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => unmountVolume(volume.volume_id)}
                            className="p-1 text-gray-600 hover:bg-gray-50 rounded transition-colors"
                            title="Unmount"
                          >
                            <Unlink className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => cloneVolume(volume.volume_id)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="Clone"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setSelectedVolume(volume)}
                          className="p-1 text-purple-600 hover:bg-purple-50 rounded transition-colors"
                          title="Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteVolume(volume.volume_id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Empty State */}
      {filteredVolumes.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <Database className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No volumes found</h3>
          <p className="text-gray-600 mb-4">
            {Object.values(filters).some(f => f && (typeof f === 'string' ? f : Object.values(f).some(v => v))) 
              ? 'Try adjusting your search or filters' 
              : 'Create your first volume to get started'
            }
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 mx-auto transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create Volume
          </button>
        </div>
      )}

      {/* Create Volume Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Create New Volume</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Avatar UUID <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={createForm.avatar_uuid}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, avatar_uuid: e.target.value }))}
                  placeholder="avatar-12345678"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Avatar Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={createForm.avatar_name}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, avatar_name: e.target.value }))}
                  placeholder="My Avatar"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Initial Size (MB)
                </label>
                <input
                  type="number"
                  value={createForm.initial_size}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, initial_size: parseInt(e.target.value) || 1024 }))}
                  min="100"
                  max="10000"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={createForm.description}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Optional description..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tags (comma-separated)
                </label>
                <input
                  type="text"
                  value={createForm.tags.join(', ')}
                  onChange={(e) => setCreateForm(prev => ({ 
                    ...prev, 
                    tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag)
                  }))}
                  placeholder="production, testing, backup"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={createVolume}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                Create Volume
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Volume Detail Modal */}
      {selectedVolume && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">{selectedVolume.avatar_name}</h2>
                <button
                  onClick={() => setSelectedVolume(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Volume ID</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedVolume.volume_id}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Avatar UUID</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedVolume.avatar_uuid}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(selectedVolume.mount_status)}`}>
                      {getStatusIcon(selectedVolume.mount_status)}
                      {selectedVolume.mount_status}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Size</label>
                  <div className="mt-1 text-sm text-gray-900">{formatSize(selectedVolume.size_mb)}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Files</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedVolume.file_count.toLocaleString()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Backups</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedVolume.backup_count}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Created</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedVolume.created_at.toLocaleString()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Created By</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedVolume.created_by}</div>
                </div>
              </div>

              {selectedVolume.linked_container_id && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Linked Container</label>
                  <div className="mt-1 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">{selectedVolume.container_name}</span>
                      <span className="text-xs text-blue-600">({selectedVolume.linked_container_id})</span>
                    </div>
                  </div>
                </div>
              )}

              {selectedVolume.description && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Description</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedVolume.description}</div>
                </div>
              )}

              {selectedVolume.tags.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Tags</label>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {selectedVolume.tags.map(tag => (
                      <span key={tag} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedVolume.app_data.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-gray-500">App Data</label>
                  <div className="mt-1 space-y-2">
                    {selectedVolume.app_data.map((app, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div>
                          <span className="text-sm font-medium text-gray-900">{app.app_name}</span>
                          <span className="text-xs text-gray-500 ml-2">v{app.version}</span>
                        </div>
                        <span className="text-sm text-gray-600">{formatSize(app.data_size)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => cloneVolume(selectedVolume.volume_id)}
                  className="flex items-center gap-2 px-4 py-2 text-blue-600 hover:text-blue-700 border border-blue-300 rounded-lg transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Clone Volume
                </button>
                <button
                  onClick={() => setSelectedVolume(null)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};