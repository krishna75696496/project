import React, { useState, useRef, useEffect } from 'react';
import { 
  FileText, 
  Upload, 
  Code, 
  Play, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Search, 
  Filter, 
  Plus, 
  Trash2, 
  RefreshCw, 
  Eye, 
  Edit, 
  Copy, 
  Download, 
  X,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Smartphone,
  Terminal,
  Zap,
  Activity,
  Server,
  Database
} from 'lucide-react';

interface Task {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  script: string;
  scriptType: 'python' | 'appium';
  container: string;
  containerName: string;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  duration?: number;
  progress: number;
  assignedTo?: string;
  priority: 'low' | 'medium' | 'high';
  logs: string[];
  results?: {
    success: boolean;
    message: string;
    data?: any;
  };
}

interface TaskFilter {
  status: string;
  container: string;
  scriptType: string;
  dateRange: {
    start: string;
    end: string;
  };
  searchTerm: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const TasksView: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJsonEditor, setShowJsonEditor] = useState(false);
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [jsonConfig, setJsonConfig] = useState<string>('{\n  "task_id": "task-12345",\n  "task_type": "social_media_action",\n  "account": "test_account",\n  "social_media_app": "facebook",\n  "python_code": "/path/to/script.py",\n  "task_data": {\n    "action": "like",\n    "target_url": "https://facebook.com/post/123",\n    "comment_text": "Great post!",\n    "wait_after_action": 3\n  }\n}');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [filters, setFilters] = useState<TaskFilter>({
    status: '',
    container: '',
    scriptType: '',
    dateRange: {
      start: '',
      end: ''
    },
    searchTerm: ''
  });

  // Generate mock data
  useEffect(() => {
    const generateMockTasks = () => {
      const statuses: Task['status'][] = ['pending', 'running', 'completed', 'failed'];
      const scriptTypes: Task['scriptType'][] = ['python', 'appium'];
      const containers = ['emulator-1', 'emulator-2', 'emulator-3', 'emulator-4'];
      const containerNames = ['Pixel 6 Pro - Android 12.0', 'Galaxy S23 - Android 12.0', 'OnePlus 11 - Android 12.0', 'iPhone 14 Pro - Android 12.0'];
      const priorities: Task['priority'][] = ['low', 'medium', 'high'];
      
      const mockTasks: Task[] = [];
      
      for (let i = 0; i < 20; i++) {
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const createdAt = new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000);
        const startedAt = status !== 'pending' ? new Date(createdAt.getTime() + Math.random() * 60 * 60 * 1000) : undefined;
        const completedAt = (status === 'completed' || status === 'failed') && startedAt 
          ? new Date(startedAt.getTime() + Math.random() * 60 * 60 * 1000) 
          : undefined;
        const duration = startedAt && completedAt 
          ? Math.floor((completedAt.getTime() - startedAt.getTime()) / 1000) 
          : undefined;
        
        const containerIndex = Math.floor(Math.random() * containers.length);
        
        mockTasks.push({
          id: `task-${i.toString().padStart(3, '0')}`,
          name: `Task ${i + 1} - ${['Login Test', 'UI Automation', 'Data Scraping', 'Performance Test'][Math.floor(Math.random() * 4)]}`,
          status,
          script: `${scriptTypes[Math.floor(Math.random() * scriptTypes.length)]}_script_${i}.py`,
          scriptType: scriptTypes[Math.floor(Math.random() * scriptTypes.length)],
          container: containers[containerIndex],
          containerName: containerNames[containerIndex],
          createdAt,
          startedAt,
          completedAt,
          duration,
          progress: status === 'running' ? Math.floor(Math.random() * 100) : status === 'completed' ? 100 : 0,
          assignedTo: Math.random() > 0.3 ? ['john.doe', 'jane.smith', 'mike.wilson'][Math.floor(Math.random() * 3)] : undefined,
          priority: priorities[Math.floor(Math.random() * priorities.length)],
          logs: [
            `[${createdAt.toISOString()}] Task created`,
            ...(startedAt ? [`[${startedAt.toISOString()}] Task started execution`] : []),
            ...(status === 'running' ? [`[${new Date().toISOString()}] Task in progress...`] : []),
            ...(completedAt ? [`[${completedAt.toISOString()}] Task ${status === 'completed' ? 'completed successfully' : 'failed'}`] : [])
          ],
          results: (status === 'completed' || status === 'failed') ? {
            success: status === 'completed',
            message: status === 'completed' ? 'Task completed successfully' : 'Task failed with errors',
            data: status === 'completed' ? { 
              executionTime: duration,
              itemsProcessed: Math.floor(Math.random() * 100) + 1
            } : undefined
          } : undefined
        });
      }
      
      return mockTasks;
    };
    
    setTimeout(() => {
      const mockTasks = generateMockTasks();
      setTasks(mockTasks);
      setFilteredTasks(mockTasks);
      setLoading(false);
    }, 1000);
  }, []);

  // Filter tasks
  useEffect(() => {
    let filtered = tasks;
    
    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(task => 
        task.name.toLowerCase().includes(searchLower) ||
        task.id.toLowerCase().includes(searchLower) ||
        task.script.toLowerCase().includes(searchLower) ||
        task.containerName.toLowerCase().includes(searchLower)
      );
    }
    
    if (filters.status) {
      filtered = filtered.filter(task => task.status === filters.status);
    }
    
    if (filters.container) {
      filtered = filtered.filter(task => task.container === filters.container);
    }
    
    if (filters.scriptType) {
      filtered = filtered.filter(task => task.scriptType === filters.scriptType);
    }
    
    if (filters.dateRange.start) {
      const startDate = new Date(filters.dateRange.start);
      filtered = filtered.filter(task => task.createdAt >= startDate);
    }
    
    if (filters.dateRange.end) {
      const endDate = new Date(filters.dateRange.end);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(task => task.createdAt <= endDate);
    }
    
    setFilteredTasks(filtered);
  }, [tasks, filters]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100 border-green-200';
      case 'running': return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'pending': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'failed': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'running': return <Activity className="w-4 h-4 animate-pulse" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'failed': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Check if it's a Python file
    if (!file.name.endsWith('.py')) {
      addToast({
        type: 'error',
        title: 'Invalid File',
        message: 'Please upload a Python (.py) file'
      });
      return;
    }
    
    // Read file content
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      
      // Create a new task with the uploaded script
      const newTask: Task = {
        id: `task-${Date.now().toString(36)}`,
        name: `Task - ${file.name}`,
        status: 'pending',
        script: file.name,
        scriptType: 'python',
        container: 'emulator-1',
        containerName: 'Pixel 6 Pro - Android 12.0',
        createdAt: new Date(),
        progress: 0,
        priority: 'medium',
        logs: [
          `[${new Date().toISOString()}] Task created with uploaded script: ${file.name}`,
          `[${new Date().toISOString()}] Assigned to container: Pixel 6 Pro - Android 12.0`,
          `[${new Date().toISOString()}] Waiting for execution...`
        ]
      };
      
      setTasks(prev => [newTask, ...prev]);
      
      addToast({
        type: 'success',
        title: 'Script Uploaded',
        message: `${file.name} uploaded and task created successfully`
      });
    };
    
    reader.readAsText(file);
    
    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleJsonEditorSave = () => {
    try {
      const config = JSON.parse(jsonConfig);
      
      // Create a new task from the JSON config
      const newTask: Task = {
        id: `task-${Date.now().toString(36)}`,
        name: `Task - ${config.task_type || 'Custom JSON Task'}`,
        status: 'pending',
        script: config.python_code || 'custom_script.py',
        scriptType: 'python',
        container: 'emulator-1',
        containerName: 'Pixel 6 Pro - Android 12.0',
        createdAt: new Date(),
        progress: 0,
        priority: 'medium',
        logs: [
          `[${new Date().toISOString()}] Task created from JSON configuration`,
          `[${new Date().toISOString()}] Task type: ${config.task_type || 'Unknown'}`,
          `[${new Date().toISOString()}] Assigned to container: Pixel 6 Pro - Android 12.0`,
          `[${new Date().toISOString()}] Waiting for execution...`
        ]
      };
      
      setTasks(prev => [newTask, ...prev]);
      setShowJsonEditor(false);
      
      addToast({
        type: 'success',
        title: 'Task Created',
        message: 'Task created successfully from JSON configuration'
      });
    } catch (error) {
      addToast({
        type: 'error',
        title: 'Invalid JSON',
        message: 'Please check your JSON configuration for errors'
      });
    }
  };

  const runTask = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { 
            ...task, 
            status: 'running', 
            startedAt: new Date(),
            progress: 0,
            logs: [...task.logs, `[${new Date().toISOString()}] Task execution started`]
          }
        : task
    ));
    
    // Simulate task progress
    const interval = setInterval(() => {
      setTasks(prev => {
        const updatedTasks = prev.map(task => {
          if (task.id === taskId && task.status === 'running') {
            const newProgress = task.progress + Math.floor(Math.random() * 10) + 1;
            
            if (newProgress >= 100) {
              clearInterval(interval);
              const success = Math.random() > 0.2; // 80% chance of success
              
              return {
                ...task,
                status: success ? 'completed' : 'failed',
                progress: 100,
                completedAt: new Date(),
                duration: Math.floor((new Date().getTime() - (task.startedAt?.getTime() || 0)) / 1000),
                logs: [
                  ...task.logs,
                  `[${new Date().toISOString()}] Task execution ${success ? 'completed successfully' : 'failed'}`
                ],
                results: {
                  success,
                  message: success ? 'Task completed successfully' : 'Task failed with errors',
                  data: success ? { 
                    executionTime: Math.floor((new Date().getTime() - (task.startedAt?.getTime() || 0)) / 1000),
                    itemsProcessed: Math.floor(Math.random() * 100) + 1
                  } : undefined
                }
              };
            }
            
            return {
              ...task,
              progress: newProgress,
              logs: [...task.logs, `[${new Date().toISOString()}] Task progress: ${newProgress}%`]
            };
          }
          return task;
        });
        
        return updatedTasks;
      });
    }, 1000);
  };

  const deleteTask = (taskId: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      setTasks(prev => prev.filter(task => task.id !== taskId));
      
      addToast({
        type: 'success',
        title: 'Task Deleted',
        message: `Task ${taskId} deleted successfully`
      });
    }
  };

  const clearFilters = () => {
    setFilters({
      status: '',
      container: '',
      scriptType: '',
      dateRange: {
        start: '',
        end: ''
      },
      searchTerm: ''
    });
  };

  const stats = {
    total: tasks.length,
    pending: tasks.filter(t => t.status === 'pending').length,
    running: tasks.filter(t => t.status === 'running').length,
    completed: tasks.filter(t => t.status === 'completed').length,
    failed: tasks.filter(t => t.status === 'failed').length,
    successRate: tasks.filter(t => t.status === 'completed' || t.status === 'failed').length > 0
      ? Math.round((tasks.filter(t => t.status === 'completed').length / tasks.filter(t => t.status === 'completed' || t.status === 'failed').length) * 100)
      : 0
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading tasks...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <FileText className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header - Matching the image exactly */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Task Assignment Panel</h1>
          <p className="text-gray-600">Execute Python 3.10 & Appium 2.4.1 automation scripts on Ubuntu 20.04 containers</p>
        </div>
        <div className="flex items-center gap-4">
          {/* Tech Stack Indicator - Matching the image exactly */}
          <div className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-blue-700 font-medium">Python <span className="text-blue-700">3.10</span></span>
            </div>
            <div className="w-px h-4 bg-gray-200"></div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-green-700 font-medium">Appium <span className="text-green-700">2.4.1</span></span>
            </div>
            <div className="w-px h-4 bg-gray-200"></div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span className="text-orange-700 font-medium">Ubuntu <span className="text-orange-700">20.04</span></span>
            </div>
          </div>
          
          {/* Upload Python Script Button - Matching the image exactly */}
          <button
            onClick={handleUploadClick}
            className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white rounded-lg transition-colors"
          >
            <Upload className="w-4 h-4" />
            Upload Python Script
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".py"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          {/* JSON Editor Button - Matching the image exactly */}
          <button
            onClick={() => setShowJsonEditor(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
          >
            <Code className="w-4 h-4" />
            JSON Editor
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Tasks</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Running</p>
              <p className="text-2xl font-bold text-blue-600">{stats.running}</p>
            </div>
            <Activity className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Failed</p>
              <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
            </div>
            <XCircle className="w-8 h-8 text-red-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Success Rate</p>
              <p className="text-2xl font-bold text-purple-600">{stats.successRate}%</p>
            </div>
            <Activity className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search tasks by name, ID, or container..."
              value={filters.searchTerm}
              onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showFilters ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Task
          </button>
        </div>

        {/* Filter Controls */}
        {showFilters && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({...filters, status: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Status</option>
                <option value="pending">Pending</option>
                <option value="running">Running</option>
                <option value="completed">Completed</option>
                <option value="failed">Failed</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Container</label>
              <select
                value={filters.container}
                onChange={(e) => setFilters({...filters, container: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Containers</option>
                <option value="emulator-1">Pixel 6 Pro - Android 12.0</option>
                <option value="emulator-2">Galaxy S23 - Android 12.0</option>
                <option value="emulator-3">OnePlus 11 - Android 12.0</option>
                <option value="emulator-4">iPhone 14 Pro - Android 12.0</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Script Type</label>
              <select
                value={filters.scriptType}
                onChange={(e) => setFilters({...filters, scriptType: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Types</option>
                <option value="python">Python</option>
                <option value="appium">Appium</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={filters.dateRange.start}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    dateRange: { ...prev.dateRange, start: e.target.value }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
                <input
                  type="date"
                  value={filters.dateRange.end}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    dateRange: { ...prev.dateRange, end: e.target.value }
                  }))}
                  className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
              </div>
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button
                onClick={clearFilters}
                className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                Clear Filters
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Tasks List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Task</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Container</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Script</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Progress</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTasks.map((task) => (
                <React.Fragment key={task.id}>
                  <tr className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setExpandedTask(
                            expandedTask === task.id ? null : task.id
                          )}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          {expandedTask === task.id ? 
                            <ChevronDown className="w-4 h-4" /> : 
                            <ChevronRight className="w-4 h-4" />
                          }
                        </button>
                        <div>
                          <div className="font-medium text-gray-900">{task.name}</div>
                          <div className="text-sm text-gray-500 font-mono">{task.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(task.status)}`}>
                        {getStatusIcon(task.status)}
                        {task.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{task.containerName}</div>
                      <div className="text-xs text-gray-500 font-mono">{task.container}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {task.scriptType === 'python' ? (
                          <div className="p-1 bg-blue-100 rounded">
                            <Terminal className="w-3 h-3 text-blue-600" />
                          </div>
                        ) : (
                          <div className="p-1 bg-green-100 rounded">
                            <Smartphone className="w-3 h-3 text-green-600" />
                          </div>
                        )}
                        <span className="text-sm font-mono text-gray-900">{task.script}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                        <div 
                          className={`h-2.5 rounded-full ${
                            task.status === 'completed' ? 'bg-green-600' :
                            task.status === 'failed' ? 'bg-red-600' :
                            'bg-blue-600'
                          }`}
                          style={{ width: `${task.progress}%` }}
                        />
                      </div>
                      <div className="text-xs text-gray-500">{task.progress}%</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{task.createdAt.toLocaleDateString()}</div>
                      <div className="text-xs text-gray-500">{task.createdAt.toLocaleTimeString()}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        {task.status === 'pending' && (
                          <button
                            onClick={() => runTask(task.id)}
                            className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                            title="Run Task"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedTask(task)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                          title="Delete Task"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>

                  {/* Expanded Details */}
                  {expandedTask === task.id && (
                    <tr>
                      <td colSpan={7} className="px-6 py-4 bg-gray-50">
                        <div className="space-y-4">
                          {/* Task Logs */}
                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Task Logs</h4>
                            <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm max-h-64 overflow-y-auto">
                              {task.logs.map((log, index) => (
                                <div key={index}>{log}</div>
                              ))}
                            </div>
                          </div>

                          {/* Task Results */}
                          {task.results && (
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Results</h4>
                              <div className="p-4 bg-gray-100 rounded">
                                <div className="flex items-center gap-2 mb-2">
                                  {task.results.success ? (
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                  ) : (
                                    <XCircle className="w-5 h-5 text-red-500" />
                                  )}
                                  <span className="font-medium text-gray-900">{task.results.message}</span>
                                </div>
                                {task.results.data && (
                                  <pre className="text-xs bg-white p-2 rounded overflow-x-auto">
                                    {JSON.stringify(task.results.data, null, 2)}
                                  </pre>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Additional Details */}
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Priority</h4>
                              <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)}`}>
                                {task.priority.toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Assigned To</h4>
                              <span className="text-sm text-gray-700">
                                {task.assignedTo || 'Unassigned'}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900 mb-2">Duration</h4>
                              <span className="text-sm text-gray-700">
                                {task.duration ? `${task.duration}s` : 'N/A'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTasks.length === 0 && (
          <div className="p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
            <p className="text-gray-600">
              {Object.values(filters).some(f => f && (typeof f === 'string' ? f : Object.values(f).some(v => v))) 
                ? 'Try adjusting your search or filters' 
                : 'Create your first task to get started'
              }
            </p>
          </div>
        )}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">{selectedTask.name}</h2>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Task ID</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedTask.id}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(selectedTask.status)}`}>
                      {getStatusIcon(selectedTask.status)}
                      {selectedTask.status}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Container</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedTask.containerName}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Script</label>
                  <div className="mt-1 text-sm font-mono text-gray-900">{selectedTask.script}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Created</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedTask.createdAt.toLocaleString()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Priority</label>
                  <div className="mt-1">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(selectedTask.priority)}`}>
                      {selectedTask.priority.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div>
                <label className="text-sm font-medium text-gray-500">Progress</label>
                <div className="mt-1">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                    <div 
                      className={`h-2.5 rounded-full ${
                        selectedTask.status === 'completed' ? 'bg-green-600' :
                        selectedTask.status === 'failed' ? 'bg-red-600' :
                        'bg-blue-600'
                      }`}
                      style={{ width: `${selectedTask.progress}%` }}
                    />
                  </div>
                  <div className="text-sm text-gray-700">{selectedTask.progress}% complete</div>
                </div>
              </div>

              {/* Task Logs */}
              <div>
                <label className="text-sm font-medium text-gray-500">Logs</label>
                <div className="mt-1 bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
                  {selectedTask.logs.map((log, index) => (
                    <div key={index}>{log}</div>
                  ))}
                </div>
              </div>

              {/* Task Results */}
              {selectedTask.results && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Results</label>
                  <div className="mt-1 p-4 bg-gray-100 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {selectedTask.results.success ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                      <span className="font-medium text-gray-900">{selectedTask.results.message}</span>
                    </div>
                    {selectedTask.results.data && (
                      <pre className="text-xs bg-white p-2 rounded overflow-x-auto">
                        {JSON.stringify(selectedTask.results.data, null, 2)}
                      </pre>
                    )}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                {selectedTask.status === 'pending' && (
                  <button
                    onClick={() => {
                      runTask(selectedTask.id);
                      setSelectedTask(null);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    Run Task
                  </button>
                )}
                <button
                  onClick={() => setSelectedTask(null)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* JSON Editor Modal */}
      {showJsonEditor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">JSON Task Configuration</h2>
                <button
                  onClick={() => setShowJsonEditor(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-700 mb-2">
                  Configure your task using JSON format. This will be used to create a new task with the specified parameters.
                </p>
                <div className="flex items-center gap-2 text-xs text-blue-600">
                  <Code className="w-4 h-4" />
                  <span>Example: Social media automation task</span>
                </div>
              </div>
              
              <textarea
                value={jsonConfig}
                onChange={(e) => setJsonConfig(e.target.value)}
                className="w-full h-80 px-4 py-3 font-mono text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              
              <div className="flex justify-end gap-3 pt-4">
                <button
                  onClick={() => setShowJsonEditor(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleJsonEditorSave}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Create Task
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};