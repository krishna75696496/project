import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Server, 
  Cpu, 
  HardDrive, 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Play, 
  Square, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Settings, 
  Monitor, 
  Smartphone, 
  Users, 
  Zap, 
  BarChart3, 
  PieChart, 
  Target, 
  Gauge, 
  ArrowUp, 
  ArrowDown, 
  Plus, 
  Minus, 
  Eye, 
  Filter, 
  Search, 
  Download, 
  Upload, 
  Globe, 
  Shield, 
  Database, 
  Network, 
  X,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  ExternalLink,
  Copy,
  Edit,
  Trash2,
  Power,
  Pause
} from 'lucide-react';

interface KubernetesNode {
  node_name: string;
  status: 'Ready' | 'NotReady' | 'SchedulingDisabled';
  cpu_usage: number;
  memory_usage: number;
  pod_count: number;
  max_pods: number;
  version: string;
  created_at: Date;
  labels: Record<string, string>;
  taints: Array<{
    key: string;
    value: string;
    effect: string;
  }>;
}

interface EmulatorPod {
  pod_id: string;
  pod_name: string;
  node_name: string;
  namespace: string;
  status: 'Running' | 'Pending' | 'Failed' | 'Succeeded' | 'Unknown';
  assigned_app: string;
  avatar_id: string;
  cpu_usage: number;
  memory_usage: number;
  cpu_request: number;
  memory_request: number;
  cpu_limit: number;
  memory_limit: number;
  restarts: number;
  age: string;
  created_at: Date;
  last_restart?: Date;
  container_image: string;
  ready_containers: number;
  total_containers: number;
  labels: Record<string, string>;
}

interface HorizontalPodAutoscaler {
  hpa_name: string;
  namespace: string;
  target_deployment: string;
  current_replicas: number;
  desired_replicas: number;
  min_replicas: number;
  max_replicas: number;
  cpu_threshold: number;
  memory_threshold?: number;
  current_cpu_utilization: number;
  current_memory_utilization?: number;
  last_scale_time?: Date;
  conditions: Array<{
    type: string;
    status: string;
    reason: string;
    message: string;
  }>;
}

interface ScaleRequest {
  deployment: string;
  replicas: number;
  reason: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const KubernetesView: React.FC = () => {
  const [nodes, setNodes] = useState<KubernetesNode[]>([]);
  const [pods, setPods] = useState<EmulatorPod[]>([]);
  const [hpas, setHpas] = useState<HorizontalPodAutoscaler[]>([]);
  const [filteredPods, setFilteredPods] = useState<EmulatorPod[]>([]);
  const [selectedNode, setSelectedNode] = useState<string>('');
  const [selectedNamespace, setSelectedNamespace] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [showScaleModal, setShowScaleModal] = useState(false);
  const [scaleRequest, setScaleRequest] = useState<ScaleRequest>({ deployment: '', replicas: 1, reason: '' });
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [expandedHPA, setExpandedHPA] = useState<string | null>(null);

  // Generate mock data
  useEffect(() => {
    const generateMockData = () => {
      // Mock nodes
      const mockNodes: KubernetesNode[] = [
        {
          node_name: 'k8s-node-1',
          status: 'Ready',
          cpu_usage: 65,
          memory_usage: 72,
          pod_count: 8,
          max_pods: 110,
          version: 'v1.28.2',
          created_at: new Date(Date.now() - 86400000 * 30),
          labels: { 'node-type': 'emulator', 'zone': 'us-west-1a' },
          taints: []
        },
        {
          node_name: 'k8s-node-2',
          status: 'Ready',
          cpu_usage: 45,
          memory_usage: 58,
          pod_count: 6,
          max_pods: 110,
          version: 'v1.28.2',
          created_at: new Date(Date.now() - 86400000 * 25),
          labels: { 'node-type': 'emulator', 'zone': 'us-west-1b' },
          taints: []
        },
        {
          node_name: 'k8s-node-3',
          status: 'NotReady',
          cpu_usage: 0,
          memory_usage: 0,
          pod_count: 0,
          max_pods: 110,
          version: 'v1.28.2',
          created_at: new Date(Date.now() - 86400000 * 20),
          labels: { 'node-type': 'emulator', 'zone': 'us-west-1c' },
          taints: [{ key: 'node.kubernetes.io/unreachable', value: '', effect: 'NoExecute' }]
        }
      ];

      // Mock pods
      const apps = ['Facebook', 'Instagram', 'WhatsApp', 'TikTok', 'Twitter'];
      const mockPods: EmulatorPod[] = Array.from({ length: 14 }, (_, i) => {
        const node = mockNodes[Math.floor(Math.random() * 2)]; // Only assign to ready nodes
        const app = apps[Math.floor(Math.random() * apps.length)];
        const status = ['Running', 'Pending', 'Failed'][Math.floor(Math.random() * 3)] as EmulatorPod['status'];
        
        return {
          pod_id: `emulator-pod-${i.toString().padStart(3, '0')}`,
          pod_name: `emulator-${app.toLowerCase()}-${i}`,
          node_name: node.node_name,
          namespace: 'emulator-system',
          status,
          assigned_app: app,
          avatar_id: `avatar-${Math.random().toString(36).substr(2, 8)}`,
          cpu_usage: status === 'Running' ? Math.floor(Math.random() * 80) + 20 : 0,
          memory_usage: status === 'Running' ? Math.floor(Math.random() * 70) + 30 : 0,
          cpu_request: 500, // 500m
          memory_request: 1024, // 1Gi
          cpu_limit: 1000, // 1000m
          memory_limit: 2048, // 2Gi
          restarts: Math.floor(Math.random() * 5),
          age: `${Math.floor(Math.random() * 24)}h${Math.floor(Math.random() * 60)}m`,
          created_at: new Date(Date.now() - Math.random() * 86400000),
          container_image: 'emulator-android:v1.2.3',
          ready_containers: status === 'Running' ? 1 : 0,
          total_containers: 1,
          labels: { app: 'emulator', version: 'v1.2.3', environment: 'production' }
        };
      });

      // Mock HPAs
      const mockHPAs: HorizontalPodAutoscaler[] = [
        {
          hpa_name: 'emulator-facebook-hpa',
          namespace: 'emulator-system',
          target_deployment: 'emulator-facebook',
          current_replicas: 3,
          desired_replicas: 4,
          min_replicas: 2,
          max_replicas: 10,
          cpu_threshold: 70,
          memory_threshold: 80,
          current_cpu_utilization: 75,
          current_memory_utilization: 65,
          last_scale_time: new Date(Date.now() - 300000),
          conditions: [
            { type: 'AbleToScale', status: 'True', reason: 'ReadyForNewScale', message: 'the last scale time was sufficiently old' },
            { type: 'ScalingActive', status: 'True', reason: 'ValidMetricFound', message: 'the HPA was able to successfully calculate a replica count' }
          ]
        },
        {
          hpa_name: 'emulator-instagram-hpa',
          namespace: 'emulator-system',
          target_deployment: 'emulator-instagram',
          current_replicas: 2,
          desired_replicas: 2,
          min_replicas: 1,
          max_replicas: 8,
          cpu_threshold: 60,
          current_cpu_utilization: 45,
          conditions: [
            { type: 'AbleToScale', status: 'True', reason: 'ReadyForNewScale', message: 'the last scale time was sufficiently old' },
            { type: 'ScalingActive', status: 'True', reason: 'ValidMetricFound', message: 'the HPA was able to successfully calculate a replica count' }
          ]
        }
      ];

      setNodes(mockNodes);
      setPods(mockPods);
      setHpas(mockHPAs);
      setLoading(false);
    };

    generateMockData();
  }, []);

  // Filter pods
  useEffect(() => {
    let filtered = pods;

    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(pod => 
        pod.pod_name.toLowerCase().includes(searchLower) ||
        pod.assigned_app.toLowerCase().includes(searchLower) ||
        pod.avatar_id.toLowerCase().includes(searchLower) ||
        pod.node_name.toLowerCase().includes(searchLower)
      );
    }

    if (selectedNode) {
      filtered = filtered.filter(pod => pod.node_name === selectedNode);
    }

    if (selectedNamespace) {
      filtered = filtered.filter(pod => pod.namespace === selectedNamespace);
    }

    setFilteredPods(filtered);
  }, [pods, searchTerm, selectedNode, selectedNamespace]);

  // Auto refresh simulation
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      setPods(prev => prev.map(pod => ({
        ...pod,
        cpu_usage: pod.status === 'Running' ? Math.max(0, Math.min(100, pod.cpu_usage + (Math.random() - 0.5) * 20)) : 0,
        memory_usage: pod.status === 'Running' ? Math.max(0, Math.min(100, pod.memory_usage + (Math.random() - 0.5) * 15)) : 0
      })));

      setHpas(prev => prev.map(hpa => ({
        ...hpa,
        current_cpu_utilization: Math.max(0, Math.min(100, hpa.current_cpu_utilization + (Math.random() - 0.5) * 10)),
        current_memory_utilization: hpa.current_memory_utilization ? Math.max(0, Math.min(100, hpa.current_memory_utilization + (Math.random() - 0.5) * 8)) : undefined
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Running': case 'Ready': return 'text-green-600 bg-green-100 border-green-200';
      case 'Pending': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'Failed': case 'NotReady': return 'text-red-600 bg-red-100 border-red-200';
      case 'Succeeded': return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'SchedulingDisabled': return 'text-gray-600 bg-gray-100 border-gray-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Running': case 'Ready': return <CheckCircle className="w-4 h-4" />;
      case 'Pending': return <Clock className="w-4 h-4 animate-pulse" />;
      case 'Failed': case 'NotReady': return <XCircle className="w-4 h-4" />;
      case 'Succeeded': return <CheckCircle className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  const scaleDeployment = async (deployment: string, replicas: number, reason: string) => {
    // Simulate scaling
    setHpas(prev => prev.map(hpa => 
      hpa.target_deployment === deployment 
        ? { ...hpa, desired_replicas: replicas, last_scale_time: new Date() }
        : hpa
    ));

    addToast({
      type: 'success',
      title: 'Scaling Initiated',
      message: `${deployment} scaling to ${replicas} replicas. Reason: ${reason}`
    });

    setShowScaleModal(false);
    setScaleRequest({ deployment: '', replicas: 1, reason: '' });
  };

  const restartPod = async (podId: string) => {
    setPods(prev => prev.map(pod => 
      pod.pod_id === podId 
        ? { ...pod, status: 'Pending', restarts: pod.restarts + 1, last_restart: new Date() }
        : pod
    ));

    // Simulate pod restart
    setTimeout(() => {
      setPods(prev => prev.map(pod => 
        pod.pod_id === podId 
          ? { ...pod, status: 'Running' }
          : pod
      ));
    }, 3000);

    addToast({
      type: 'info',
      title: 'Pod Restart',
      message: `Pod ${podId} is restarting`
    });
  };

  const deletePod = async (podId: string) => {
    if (window.confirm('Are you sure you want to delete this pod?')) {
      setPods(prev => prev.filter(pod => pod.pod_id !== podId));
      addToast({
        type: 'success',
        title: 'Pod Deleted',
        message: `Pod ${podId} deleted successfully`
      });
    }
  };

  const clusterStats = {
    totalNodes: nodes.length,
    readyNodes: nodes.filter(n => n.status === 'Ready').length,
    totalPods: pods.length,
    runningPods: pods.filter(p => p.status === 'Running').length,
    avgCpuUsage: nodes.reduce((acc, n) => acc + n.cpu_usage, 0) / nodes.length || 0,
    avgMemoryUsage: nodes.reduce((acc, n) => acc + n.memory_usage, 0) / nodes.length || 0
  };

  const namespaces = [...new Set(pods.map(p => p.namespace))];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Kubernetes cluster...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <Layers className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Kubernetes Autoscaling & Pod Management</h1>
          <p className="text-gray-600">Monitor and manage emulator pods and autoscaling behaviors</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              autoRefresh 
                ? 'bg-green-50 border-green-200 text-green-700' 
                : 'border-gray-300 text-gray-600'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${autoRefresh ? 'animate-spin' : ''}`} />
            Auto Refresh
          </button>
          <button
            onClick={() => setShowScaleModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Target className="w-4 h-4" />
            Manual Scale
          </button>
        </div>
      </div>

      {/* Cluster Overview */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Nodes</p>
              <p className="text-2xl font-bold text-gray-900">{clusterStats.readyNodes}/{clusterStats.totalNodes}</p>
            </div>
            <Server className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pods</p>
              <p className="text-2xl font-bold text-green-600">{clusterStats.runningPods}/{clusterStats.totalPods}</p>
            </div>
            <Layers className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg CPU</p>
              <p className="text-2xl font-bold text-orange-600">{clusterStats.avgCpuUsage.toFixed(1)}%</p>
            </div>
            <Cpu className="w-8 h-8 text-orange-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Memory</p>
              <p className="text-2xl font-bold text-purple-600">{clusterStats.avgMemoryUsage.toFixed(1)}%</p>
            </div>
            <HardDrive className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">HPAs</p>
              <p className="text-2xl font-bold text-indigo-600">{hpas.length}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Namespaces</p>
              <p className="text-2xl font-bold text-teal-600">{namespaces.length}</p>
            </div>
            <Globe className="w-8 h-8 text-teal-600" />
          </div>
        </div>
      </div>

      {/* Node Overview */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Node Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {nodes.map(node => (
            <div key={node.node_name} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-gray-900">{node.node_name}</h3>
                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(node.status)}`}>
                  {getStatusIcon(node.status)}
                  {node.status}
                </span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">CPU Usage:</span>
                  <span className="font-medium">{node.cpu_usage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-orange-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${node.cpu_usage}%` }}
                  />
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Memory Usage:</span>
                  <span className="font-medium">{node.memory_usage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${node.memory_usage}%` }}
                  />
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Pods:</span>
                  <span className="font-medium">{node.pod_count}/{node.max_pods}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Version:</span>
                  <span className="font-mono text-xs">{node.version}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Horizontal Pod Autoscalers */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Horizontal Pod Autoscalers</h2>
        <div className="space-y-4">
          {hpas.map(hpa => (
            <div key={hpa.hpa_name} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setExpandedHPA(expandedHPA === hpa.hpa_name ? null : hpa.hpa_name)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    {expandedHPA === hpa.hpa_name ? 
                      <ChevronDown className="w-4 h-4" /> : 
                      <ChevronRight className="w-4 h-4" />
                    }
                  </button>
                  <h3 className="font-medium text-gray-900">{hpa.hpa_name}</h3>
                  <span className="text-sm text-gray-500">→ {hpa.target_deployment}</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-sm">
                    <span className="text-gray-600">Replicas: </span>
                    <span className="font-medium">{hpa.current_replicas}</span>
                    {hpa.current_replicas !== hpa.desired_replicas && (
                      <span className="text-blue-600"> → {hpa.desired_replicas}</span>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setScaleRequest({ 
                        deployment: hpa.target_deployment, 
                        replicas: hpa.current_replicas, 
                        reason: 'Manual override' 
                      });
                      setShowScaleModal(true);
                    }}
                    className="flex items-center gap-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors"
                  >
                    <Target className="w-3 h-3" />
                    Scale
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">{hpa.current_replicas}</div>
                  <div className="text-xs text-gray-500">Current</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-600">{hpa.min_replicas}-{hpa.max_replicas}</div>
                  <div className="text-xs text-gray-500">Range</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-orange-600">{hpa.current_cpu_utilization}%</div>
                  <div className="text-xs text-gray-500">CPU (target: {hpa.cpu_threshold}%)</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-600">
                    {hpa.current_memory_utilization ? `${hpa.current_memory_utilization}%` : 'N/A'}
                  </div>
                  <div className="text-xs text-gray-500">
                    Memory {hpa.memory_threshold ? `(target: ${hpa.memory_threshold}%)` : ''}
                  </div>
                </div>
              </div>

              {/* CPU Utilization Bar */}
              <div className="mb-2">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">CPU Utilization</span>
                  <span className="font-medium">{hpa.current_cpu_utilization}% / {hpa.cpu_threshold}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      hpa.current_cpu_utilization > hpa.cpu_threshold ? 'bg-red-500' : 'bg-orange-500'
                    }`}
                    style={{ width: `${Math.min(100, (hpa.current_cpu_utilization / hpa.cpu_threshold) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Memory Utilization Bar */}
              {hpa.memory_threshold && hpa.current_memory_utilization && (
                <div className="mb-2">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Memory Utilization</span>
                    <span className="font-medium">{hpa.current_memory_utilization}% / {hpa.memory_threshold}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${
                        hpa.current_memory_utilization > hpa.memory_threshold ? 'bg-red-500' : 'bg-purple-500'
                      }`}
                      style={{ width: `${Math.min(100, (hpa.current_memory_utilization / hpa.memory_threshold) * 100)}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Expanded Details */}
              {expandedHPA === hpa.hpa_name && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Conditions</h4>
                  <div className="space-y-2">
                    {hpa.conditions.map((condition, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <span className="font-medium">{condition.type}:</span>
                          <span className="text-gray-600 ml-1">{condition.message}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  {hpa.last_scale_time && (
                    <div className="mt-3 text-sm text-gray-600">
                      Last scaled: {hpa.last_scale_time.toLocaleString()}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Pod List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Emulator Pods</h2>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search pods..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <select
                value={selectedNode}
                onChange={(e) => setSelectedNode(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Nodes</option>
                {nodes.map(node => (
                  <option key={node.node_name} value={node.node_name}>{node.node_name}</option>
                ))}
              </select>
              <select
                value={selectedNamespace}
                onChange={(e) => setSelectedNamespace(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Namespaces</option>
                {namespaces.map(ns => (
                  <option key={ns} value={ns}>{ns}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Pod</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Node</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">App</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Resources</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Age</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredPods.map(pod => (
                <tr key={pod.pod_id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <Smartphone className="w-5 h-5 text-gray-400" />
                      <div>
                        <div className="font-medium text-gray-900">{pod.pod_name}</div>
                        <div className="text-sm text-gray-500 font-mono">{pod.avatar_id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(pod.status)}`}>
                        {getStatusIcon(pod.status)}
                        {pod.status}
                      </span>
                      <div className="text-xs text-gray-500">
                        {pod.ready_containers}/{pod.total_containers} ready
                        {pod.restarts > 0 && (
                          <span className="ml-2 text-yellow-600">
                            {pod.restarts} restarts
                          </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{pod.node_name}</div>
                    <div className="text-xs text-gray-500">{pod.namespace}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{pod.assigned_app}</div>
                    <div className="text-xs text-gray-500">{pod.container_image}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-600">CPU:</span>
                        <span className="font-medium">{pod.cpu_usage}%</span>
                        <div className="w-16 bg-gray-200 rounded-full h-1">
                          <div 
                            className="bg-orange-500 h-1 rounded-full"
                            style={{ width: `${pod.cpu_usage}%` }}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-600">Mem:</span>
                        <span className="font-medium">{pod.memory_usage}%</span>
                        <div className="w-16 bg-gray-200 rounded-full h-1">
                          <div 
                            className="bg-purple-500 h-1 rounded-full"
                            style={{ width: `${pod.memory_usage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{pod.age}</div>
                    <div className="text-xs text-gray-500">
                      {pod.created_at.toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => restartPod(pod.pod_id)}
                        className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Restart Pod"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                      <button
                        className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                        title="View Logs"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deletePod(pod.pod_id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Delete Pod"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredPods.length === 0 && (
          <div className="p-12 text-center">
            <Layers className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No pods found</h3>
            <p className="text-gray-600">
              {searchTerm || selectedNode || selectedNamespace 
                ? 'Try adjusting your search or filters' 
                : 'No emulator pods are currently running'
              }
            </p>
          </div>
        )}
      </div>

      {/* Scale Modal */}
      {showScaleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Manual Scale Deployment</h2>
                <button
                  onClick={() => setShowScaleModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Deployment
                </label>
                <select
                  value={scaleRequest.deployment}
                  onChange={(e) => setScaleRequest(prev => ({ ...prev, deployment: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select deployment</option>
                  {hpas.map(hpa => (
                    <option key={hpa.target_deployment} value={hpa.target_deployment}>
                      {hpa.target_deployment} (current: {hpa.current_replicas})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Replicas: {scaleRequest.replicas}
                </label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={scaleRequest.replicas}
                  onChange={(e) => setScaleRequest(prev => ({ ...prev, replicas: parseInt(e.target.value) }))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0</span>
                  <span>10</span>
                  <span>20</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason
                </label>
                <input
                  type="text"
                  value={scaleRequest.reason}
                  onChange={(e) => setScaleRequest(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="Reason for manual scaling"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowScaleModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={() => scaleDeployment(scaleRequest.deployment, scaleRequest.replicas, scaleRequest.reason)}
                disabled={!scaleRequest.deployment || !scaleRequest.reason}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-lg"
              >
                Scale Deployment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};