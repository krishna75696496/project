import React, { useState, useEffect } from 'react';
import { 
  Network, 
  Plus, 
  Trash2, 
  Edit, 
  Globe, 
  Shield, 
  Zap, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Eye, 
  EyeOff, 
  Copy, 
  RefreshCw, 
  Search, 
  Filter, 
  Settings, 
  User, 
  Key, 
  MapPin, 
  Activity, 
  Smartphone, 
  Link, 
  Unlink, 
  X, 
  Save, 
  TestTube, 
  Wifi, 
  WifiOff, 
  Timer, 
  Target, 
  Flag, 
  Server,
  Monitor,
  Database,
  MoreVertical,
  ExternalLink,
  Download,
  Upload
} from 'lucide-react';

interface Proxy {
  proxy_id: string;
  ip: string;
  port: number;
  username?: string;
  password?: string;
  country: string;
  country_code: string;
  provider: string;
  protocol: 'http' | 'https' | 'socks5';
  status: 'active' | 'inactive' | 'testing' | 'error';
  assigned_avatar_id?: string;
  assigned_container_id?: string;
  container_name?: string;
  latency?: number;
  last_tested: Date;
  created_at: Date;
  created_by: string;
  usage_stats: {
    total_requests: number;
    data_transferred: number;
    uptime_percentage: number;
    avg_response_time: number;
  };
  tags: string[];
  notes?: string;
}

interface ProxyFilter {
  searchTerm: string;
  status: string;
  country: string;
  protocol: string;
  provider: string;
  assigned: string;
}

interface ProxyForm {
  ip: string;
  port: number;
  username: string;
  password: string;
  country: string;
  country_code: string;
  provider: string;
  protocol: 'http' | 'https' | 'socks5';
  tags: string[];
  notes: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

interface TestResult {
  proxy_id: string;
  success: boolean;
  latency?: number;
  error?: string;
  timestamp: Date;
}

export const ProxyView: React.FC = () => {
  const [proxies, setProxies] = useState<Proxy[]>([]);
  const [filteredProxies, setFilteredProxies] = useState<Proxy[]>([]);
  const [selectedProxies, setSelectedProxies] = useState<Set<string>>(new Set());
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProxy, setSelectedProxy] = useState<Proxy | null>(null);
  const [editingProxy, setEditingProxy] = useState<Proxy | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [testingProxies, setTestingProxies] = useState<Set<string>>(new Set());
  const [testResults, setTestResults] = useState<Map<string, TestResult>>(new Map());
  const [showPasswords, setShowPasswords] = useState<Set<string>>(new Set());

  const [filters, setFilters] = useState<ProxyFilter>({
    searchTerm: '',
    status: '',
    country: '',
    protocol: '',
    provider: '',
    assigned: ''
  });

  const [proxyForm, setProxyForm] = useState<ProxyForm>({
    ip: '',
    port: 8080,
    username: '',
    password: '',
    country: '',
    country_code: '',
    provider: '',
    protocol: 'http',
    tags: [],
    notes: ''
  });

  // Mock containers for assignment
  const containers = [
    { id: 'emulator-1', name: 'Pixel 6 Pro - Android 13', avatar_id: 'avatar-12345678' },
    { id: 'emulator-2', name: 'Galaxy S23 - Android 14', avatar_id: 'avatar-87654321' },
    { id: 'emulator-3', name: 'OnePlus 11 - Android 13', avatar_id: 'avatar-11223344' },
    { id: 'emulator-4', name: 'iPhone 14 Pro - iOS 16', avatar_id: 'avatar-44332211' }
  ];

  const countries = [
    { code: 'US', name: 'United States', flag: '🇺🇸' },
    { code: 'UK', name: 'United Kingdom', flag: '🇬🇧' },
    { code: 'DE', name: 'Germany', flag: '🇩🇪' },
    { code: 'FR', name: 'France', flag: '🇫🇷' },
    { code: 'JP', name: 'Japan', flag: '🇯🇵' },
    { code: 'CA', name: 'Canada', flag: '🇨🇦' },
    { code: 'AU', name: 'Australia', flag: '🇦🇺' },
    { code: 'SG', name: 'Singapore', flag: '🇸🇬' }
  ];

  const providers = ['ProxyMesh', 'Bright Data', 'Oxylabs', 'Smartproxy', 'ProxyRack', 'Custom'];

  // Generate mock data
  useEffect(() => {
    const generateMockProxies = (): Proxy[] => {
      return Array.from({ length: 20 }, (_, i) => {
        const country = countries[Math.floor(Math.random() * countries.length)];
        const provider = providers[Math.floor(Math.random() * providers.length)];
        const protocol = ['http', 'https', 'socks5'][Math.floor(Math.random() * 3)] as Proxy['protocol'];
        const status = ['active', 'inactive', 'testing', 'error'][Math.floor(Math.random() * 4)] as Proxy['status'];
        const container = Math.random() > 0.6 ? containers[Math.floor(Math.random() * containers.length)] : null;

        return {
          proxy_id: `proxy-${i.toString().padStart(3, '0')}`,
          ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          port: [8080, 3128, 1080, 8888, 9000][Math.floor(Math.random() * 5)],
          username: Math.random() > 0.3 ? `user${i}` : undefined,
          password: Math.random() > 0.3 ? `pass${i}` : undefined,
          country: country.name,
          country_code: country.code,
          provider,
          protocol,
          status,
          assigned_avatar_id: container?.avatar_id,
          assigned_container_id: container?.id,
          container_name: container?.name,
          latency: status === 'active' ? Math.floor(Math.random() * 500) + 50 : undefined,
          last_tested: new Date(Date.now() - Math.random() * 86400000),
          created_at: new Date(Date.now() - Math.random() * 30 * 86400000),
          created_by: ['admin', 'john.doe', 'jane.smith'][Math.floor(Math.random() * 3)],
          usage_stats: {
            total_requests: Math.floor(Math.random() * 10000),
            data_transferred: Math.floor(Math.random() * 1000000),
            uptime_percentage: Math.floor(Math.random() * 30) + 70,
            avg_response_time: Math.floor(Math.random() * 300) + 100
          },
          tags: ['production', 'testing', 'backup', 'high-speed', 'residential'].slice(0, Math.floor(Math.random() * 3) + 1),
          notes: Math.random() > 0.5 ? `Proxy for ${country.name} region testing` : undefined
        };
      });
    };

    setTimeout(() => {
      setProxies(generateMockProxies());
      setLoading(false);
    }, 1000);
  }, []);

  // Filter proxies
  useEffect(() => {
    let filtered = proxies;

    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(proxy => 
        proxy.ip.includes(filters.searchTerm) ||
        proxy.proxy_id.toLowerCase().includes(searchLower) ||
        proxy.country.toLowerCase().includes(searchLower) ||
        proxy.provider.toLowerCase().includes(searchLower) ||
        proxy.assigned_avatar_id?.toLowerCase().includes(searchLower)
      );
    }

    if (filters.status) {
      filtered = filtered.filter(proxy => proxy.status === filters.status);
    }

    if (filters.country) {
      filtered = filtered.filter(proxy => proxy.country_code === filters.country);
    }

    if (filters.protocol) {
      filtered = filtered.filter(proxy => proxy.protocol === filters.protocol);
    }

    if (filters.provider) {
      filtered = filtered.filter(proxy => proxy.provider === filters.provider);
    }

    if (filters.assigned) {
      if (filters.assigned === 'assigned') {
        filtered = filtered.filter(proxy => proxy.assigned_container_id);
      } else if (filters.assigned === 'unassigned') {
        filtered = filtered.filter(proxy => !proxy.assigned_container_id);
      }
    }

    setFilteredProxies(filtered);
  }, [proxies, filters]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100 border-green-200';
      case 'inactive': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'testing': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'error': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4" />;
      case 'inactive': return <XCircle className="w-4 h-4" />;
      case 'testing': return <Clock className="w-4 h-4 animate-pulse" />;
      case 'error': return <AlertTriangle className="w-4 h-4" />;
      default: return <XCircle className="w-4 h-4" />;
    }
  };

  const getLatencyColor = (latency?: number) => {
    if (!latency) return 'text-gray-500';
    if (latency < 100) return 'text-green-600';
    if (latency < 300) return 'text-yellow-600';
    return 'text-red-600';
  };

  const testProxy = async (proxyId: string) => {
    setTestingProxies(prev => new Set([...prev, proxyId]));
    
    // Simulate proxy test
    setTimeout(() => {
      const success = Math.random() > 0.2; // 80% success rate
      const latency = success ? Math.floor(Math.random() * 500) + 50 : undefined;
      
      const result: TestResult = {
        proxy_id: proxyId,
        success,
        latency,
        error: success ? undefined : 'Connection timeout',
        timestamp: new Date()
      };

      setTestResults(prev => new Map([...prev, [proxyId, result]]));
      setTestingProxies(prev => {
        const newSet = new Set(prev);
        newSet.delete(proxyId);
        return newSet;
      });

      // Update proxy status
      setProxies(prev => prev.map(proxy => 
        proxy.proxy_id === proxyId 
          ? { 
              ...proxy, 
              status: success ? 'active' : 'error',
              latency,
              last_tested: new Date()
            }
          : proxy
      ));

      addToast({
        type: success ? 'success' : 'error',
        title: 'Proxy Test Complete',
        message: success 
          ? `Proxy ${proxyId} is working (${latency}ms)` 
          : `Proxy ${proxyId} failed: Connection timeout`
      });
    }, 2000);
  };

  const assignProxy = async (proxyId: string, containerId: string) => {
    const container = containers.find(c => c.id === containerId);
    if (!container) return;

    setProxies(prev => prev.map(proxy => 
      proxy.proxy_id === proxyId 
        ? { 
            ...proxy, 
            assigned_container_id: containerId,
            assigned_avatar_id: container.avatar_id,
            container_name: container.name
          }
        : proxy
    ));

    addToast({
      type: 'success',
      title: 'Proxy Assigned',
      message: `Proxy ${proxyId} assigned to ${container.name}`
    });
  };

  const unassignProxy = async (proxyId: string) => {
    setProxies(prev => prev.map(proxy => 
      proxy.proxy_id === proxyId 
        ? { 
            ...proxy, 
            assigned_container_id: undefined,
            assigned_avatar_id: undefined,
            container_name: undefined
          }
        : proxy
    ));

    addToast({
      type: 'info',
      title: 'Proxy Unassigned',
      message: `Proxy ${proxyId} unassigned from container`
    });
  };

  const deleteProxy = async (proxyId: string) => {
    if (window.confirm('Are you sure you want to delete this proxy?')) {
      setProxies(prev => prev.filter(proxy => proxy.proxy_id !== proxyId));
      addToast({
        type: 'success',
        title: 'Proxy Deleted',
        message: `Proxy ${proxyId} deleted successfully`
      });
    }
  };

  const createProxy = async () => {
    if (!proxyForm.ip || !proxyForm.port) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'IP address and port are required'
      });
      return;
    }

    const newProxy: Proxy = {
      proxy_id: `proxy-${Date.now()}`,
      ip: proxyForm.ip,
      port: proxyForm.port,
      username: proxyForm.username || undefined,
      password: proxyForm.password || undefined,
      country: proxyForm.country,
      country_code: proxyForm.country_code,
      provider: proxyForm.provider,
      protocol: proxyForm.protocol,
      status: 'inactive',
      last_tested: new Date(),
      created_at: new Date(),
      created_by: 'current-user',
      usage_stats: {
        total_requests: 0,
        data_transferred: 0,
        uptime_percentage: 0,
        avg_response_time: 0
      },
      tags: proxyForm.tags,
      notes: proxyForm.notes || undefined
    };

    setProxies(prev => [newProxy, ...prev]);
    setShowCreateModal(false);
    setProxyForm({
      ip: '',
      port: 8080,
      username: '',
      password: '',
      country: '',
      country_code: '',
      provider: '',
      protocol: 'http',
      tags: [],
      notes: ''
    });

    addToast({
      type: 'success',
      title: 'Proxy Created',
      message: `Proxy ${newProxy.proxy_id} created successfully`
    });
  };

  const bulkTest = async () => {
    const selectedProxyList = Array.from(selectedProxies);
    for (const proxyId of selectedProxyList) {
      await testProxy(proxyId);
      // Add delay between tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    setSelectedProxies(new Set());
  };

  const bulkDelete = async () => {
    const selectedProxyList = Array.from(selectedProxies);
    if (window.confirm(`Are you sure you want to delete ${selectedProxyList.length} proxies?`)) {
      setProxies(prev => prev.filter(proxy => !selectedProxies.has(proxy.proxy_id)));
      setSelectedProxies(new Set());
      addToast({
        type: 'success',
        title: 'Bulk Delete Complete',
        message: `${selectedProxyList.length} proxies deleted`
      });
    }
  };

  const togglePasswordVisibility = (proxyId: string) => {
    setShowPasswords(prev => {
      const newSet = new Set(prev);
      if (newSet.has(proxyId)) {
        newSet.delete(proxyId);
      } else {
        newSet.add(proxyId);
      }
      return newSet;
    });
  };

  const clearFilters = () => {
    setFilters({
      searchTerm: '',
      status: '',
      country: '',
      protocol: '',
      provider: '',
      assigned: ''
    });
  };

  const stats = {
    total: proxies.length,
    active: proxies.filter(p => p.status === 'active').length,
    assigned: proxies.filter(p => p.assigned_container_id).length,
    avgLatency: proxies.filter(p => p.latency).reduce((acc, p) => acc + (p.latency || 0), 0) / proxies.filter(p => p.latency).length || 0
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading proxies...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <Network className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Proxy Settings</h1>
          <p className="text-gray-600">Manage and assign proxy configurations to emulator instances</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showFilters ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Proxy
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Proxies</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <Network className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active</p>
              <p className="text-2xl font-bold text-green-600">{stats.active}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Assigned</p>
              <p className="text-2xl font-bold text-purple-600">{stats.assigned}</p>
            </div>
            <Link className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Latency</p>
              <p className={`text-2xl font-bold ${getLatencyColor(stats.avgLatency)}`}>
                {stats.avgLatency ? `${Math.round(stats.avgLatency)}ms` : 'N/A'}
              </p>
            </div>
            <Timer className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search by IP, proxy ID, country, or avatar ID..."
              value={filters.searchTerm}
              onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="testing">Testing</option>
                <option value="error">Error</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
              <select
                value={filters.country}
                onChange={(e) => setFilters(prev => ({ ...prev, country: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Countries</option>
                {countries.map(country => (
                  <option key={country.code} value={country.code}>
                    {country.flag} {country.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Protocol</label>
              <select
                value={filters.protocol}
                onChange={(e) => setFilters(prev => ({ ...prev, protocol: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Protocols</option>
                <option value="http">HTTP</option>
                <option value="https">HTTPS</option>
                <option value="socks5">SOCKS5</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Provider</label>
              <select
                value={filters.provider}
                onChange={(e) => setFilters(prev => ({ ...prev, provider: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Providers</option>
                {providers.map(provider => (
                  <option key={provider} value={provider}>{provider}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Assignment</label>
              <select
                value={filters.assigned}
                onChange={(e) => setFilters(prev => ({ ...prev, assigned: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All</option>
                <option value="assigned">Assigned</option>
                <option value="unassigned">Unassigned</option>
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={clearFilters}
                className="w-full px-3 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
              >
                Clear
              </button>
            </div>
          </div>
        )}

        {/* Bulk Actions */}
        {selectedProxies.size > 0 && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-blue-900">
                {selectedProxies.size} proxy(ies) selected
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={bulkTest}
                  className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-colors"
                >
                  Test All
                </button>
                <button
                  onClick={bulkDelete}
                  className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm transition-colors"
                >
                  Delete All
                </button>
                <button
                  onClick={() => setSelectedProxies(new Set())}
                  className="px-3 py-1 text-gray-600 hover:text-gray-900 border border-gray-300 rounded text-sm transition-colors"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Proxies Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectedProxies.size === filteredProxies.length && filteredProxies.length > 0}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedProxies(new Set(filteredProxies.map(p => p.proxy_id)));
                      } else {
                        setSelectedProxies(new Set());
                      }
                    }}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Proxy</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assignment</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Performance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredProxies.map((proxy) => (
                <tr key={proxy.proxy_id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedProxies.has(proxy.proxy_id)}
                      onChange={(e) => {
                        const newSelected = new Set(selectedProxies);
                        if (e.target.checked) {
                          newSelected.add(proxy.proxy_id);
                        } else {
                          newSelected.delete(proxy.proxy_id);
                        }
                        setSelectedProxies(newSelected);
                      }}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <Network className="w-5 h-5 text-gray-400" />
                      <div>
                        <div className="font-medium text-gray-900">{proxy.ip}:{proxy.port}</div>
                        <div className="text-sm text-gray-500">
                          {proxy.protocol.toUpperCase()} • {proxy.provider}
                        </div>
                        {proxy.username && (
                          <div className="text-xs text-gray-400 flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {proxy.username}
                            {proxy.password && (
                              <button
                                onClick={() => togglePasswordVisibility(proxy.proxy_id)}
                                className="ml-1 text-gray-400 hover:text-gray-600"
                              >
                                {showPasswords.has(proxy.proxy_id) ? 
                                  <EyeOff className="w-3 h-3" /> : 
                                  <Eye className="w-3 h-3" />
                                }
                              </button>
                            )}
                            {proxy.password && showPasswords.has(proxy.proxy_id) && (
                              <span className="font-mono">:{proxy.password}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(proxy.status)}`}>
                        {getStatusIcon(proxy.status)}
                        {proxy.status}
                      </span>
                      {testingProxies.has(proxy.proxy_id) && (
                        <div className="text-xs text-yellow-600 flex items-center gap-1">
                          <Clock className="w-3 h-3 animate-pulse" />
                          Testing...
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">
                        {countries.find(c => c.code === proxy.country_code)?.flag || '🌍'}
                      </span>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{proxy.country}</div>
                        <div className="text-xs text-gray-500">{proxy.country_code}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {proxy.assigned_container_id ? (
                      <div className="space-y-1">
                        <div className="text-sm font-medium text-blue-600">{proxy.container_name}</div>
                        <div className="text-xs text-gray-500 font-mono">{proxy.assigned_avatar_id}</div>
                        <button
                          onClick={() => unassignProxy(proxy.proxy_id)}
                          className="text-xs text-red-600 hover:text-red-700 flex items-center gap-1"
                        >
                          <Unlink className="w-3 h-3" />
                          Unassign
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <div className="text-sm text-gray-500">Not assigned</div>
                        <select
                          onChange={(e) => {
                            if (e.target.value) {
                              assignProxy(proxy.proxy_id, e.target.value);
                              e.target.value = '';
                            }
                          }}
                          className="text-xs border border-gray-300 rounded px-2 py-1"
                        >
                          <option value="">Assign to...</option>
                          {containers.map(container => (
                            <option key={container.id} value={container.id}>
                              {container.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1 text-sm">
                      {proxy.latency ? (
                        <div className={`font-medium ${getLatencyColor(proxy.latency)}`}>
                          {proxy.latency}ms
                        </div>
                      ) : (
                        <div className="text-gray-500">No data</div>
                      )}
                      <div className="text-xs text-gray-500">
                        Uptime: {proxy.usage_stats.uptime_percentage}%
                      </div>
                      <div className="text-xs text-gray-500">
                        Last tested: {proxy.last_tested.toLocaleDateString()}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => testProxy(proxy.proxy_id)}
                        disabled={testingProxies.has(proxy.proxy_id)}
                        className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors disabled:opacity-50"
                        title="Test Proxy"
                      >
                        <TestTube className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setSelectedProxy(proxy)}
                        className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="View Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingProxy(proxy)}
                        className="p-1 text-purple-600 hover:bg-purple-50 rounded transition-colors"
                        title="Edit Proxy"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteProxy(proxy.proxy_id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Delete Proxy"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredProxies.length === 0 && (
          <div className="p-12 text-center">
            <Network className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No proxies found</h3>
            <p className="text-gray-600 mb-4">
              {Object.values(filters).some(f => f) 
                ? 'Try adjusting your search or filters' 
                : 'Add your first proxy to get started'
              }
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 mx-auto transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Proxy
            </button>
          </div>
        )}
      </div>

      {/* Create Proxy Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Add New Proxy</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    IP Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={proxyForm.ip}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, ip: e.target.value }))}
                    placeholder="192.168.1.1"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Port <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={proxyForm.port}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, port: parseInt(e.target.value) || 8080 }))}
                    min="1"
                    max="65535"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                  <input
                    type="text"
                    value={proxyForm.username}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, username: e.target.value }))}
                    placeholder="Optional"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input
                    type="password"
                    value={proxyForm.password}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, password: e.target.value }))}
                    placeholder="Optional"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                <select
                  value={proxyForm.country_code}
                  onChange={(e) => {
                    const country = countries.find(c => c.code === e.target.value);
                    setProxyForm(prev => ({ 
                      ...prev, 
                      country_code: e.target.value,
                      country: country?.name || ''
                    }));
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Country</option>
                  {countries.map(country => (
                    <option key={country.code} value={country.code}>
                      {country.flag} {country.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Protocol</label>
                  <select
                    value={proxyForm.protocol}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, protocol: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="http">HTTP</option>
                    <option value="https">HTTPS</option>
                    <option value="socks5">SOCKS5</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Provider</label>
                  <select
                    value={proxyForm.provider}
                    onChange={(e) => setProxyForm(prev => ({ ...prev, provider: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select Provider</option>
                    {providers.map(provider => (
                      <option key={provider} value={provider}>{provider}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={proxyForm.tags.join(', ')}
                  onChange={(e) => setProxyForm(prev => ({ 
                    ...prev, 
                    tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag)
                  }))}
                  placeholder="production, high-speed, residential"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                <textarea
                  value={proxyForm.notes}
                  onChange={(e) => setProxyForm(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Optional notes about this proxy..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={createProxy}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                Add Proxy
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Proxy Detail Modal */}
      {selectedProxy && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Proxy Details</h2>
                <button
                  onClick={() => setSelectedProxy(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Proxy ID</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedProxy.proxy_id}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(selectedProxy.status)}`}>
                      {getStatusIcon(selectedProxy.status)}
                      {selectedProxy.status}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Address</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedProxy.ip}:{selectedProxy.port}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Protocol</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedProxy.protocol.toUpperCase()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Country</label>
                  <div className="mt-1 text-sm text-gray-900 flex items-center gap-2">
                    <span>{countries.find(c => c.code === selectedProxy.country_code)?.flag}</span>
                    {selectedProxy.country}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Provider</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedProxy.provider}</div>
                </div>
              </div>

              {selectedProxy.assigned_container_id && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Assignment</label>
                  <div className="mt-1 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">{selectedProxy.container_name}</span>
                    </div>
                    <div className="text-xs text-blue-600 mt-1">Avatar: {selectedProxy.assigned_avatar_id}</div>
                  </div>
                </div>
              )}

              <div>
                <label className="text-sm font-medium text-gray-500">Performance Stats</label>
                <div className="mt-1 grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-900">
                      {selectedProxy.latency ? `${selectedProxy.latency}ms` : 'No data'}
                    </div>
                    <div className="text-xs text-gray-500">Latency</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-900">{selectedProxy.usage_stats.uptime_percentage}%</div>
                    <div className="text-xs text-gray-500">Uptime</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-900">{selectedProxy.usage_stats.total_requests.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Total Requests</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm font-medium text-gray-900">{(selectedProxy.usage_stats.data_transferred / 1024 / 1024).toFixed(1)} MB</div>
                    <div className="text-xs text-gray-500">Data Transferred</div>
                  </div>
                </div>
              </div>

              {selectedProxy.tags.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Tags</label>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {selectedProxy.tags.map(tag => (
                      <span key={tag} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedProxy.notes && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Notes</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedProxy.notes}</div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <label className="text-sm font-medium text-gray-500">Created</label>
                  <div className="mt-1 text-gray-900">{selectedProxy.created_at.toLocaleString()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Last Tested</label>
                  <div className="mt-1 text-gray-900">{selectedProxy.last_tested.toLocaleString()}</div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => testProxy(selectedProxy.proxy_id)}
                  className="flex items-center gap-2 px-4 py-2 text-green-600 hover:text-green-700 border border-green-300 rounded-lg transition-colors"
                >
                  <TestTube className="w-4 h-4" />
                  Test Proxy
                </button>
                <button
                  onClick={() => setSelectedProxy(null)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};