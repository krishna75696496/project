import React, { useState, useEffect } from 'react';
import { useEmulators } from '../../hooks/useEmulators';
import { 
  Monitor, 
  Play, 
  Square, 
  Trash2, 
  Activity, 
  Cpu, 
  HardDrive, 
  Network,
  Users,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  RefreshCw,
  Eye,
  RotateCcw,
  FileText,
  Wifi,
  Globe,
  Smartphone,
  Grid3X3,
  List,
  X,
  Calendar,
  Zap,
  Terminal,
  Code,
  Server
} from 'lucide-react';

interface ContainerFilters {
  app: string;
  avatarId: string;
  mode: string;
  status: string;
}

interface QuickViewData {
  id: string;
  name: string;
  status: string;
  avatarUuid: string;
  launchMode: string;
  cpuUsage: number;
  ramUsage: number;
  ipAddress: string;
  proxyStatus: string;
  startedAt: Date;
  logs: string[];
  environment: {
    python: string;
    appium: string;
    ubuntu: string;
    android: string;
  };
}

export const DashboardView: React.FC = () => {
  const { containers, loading, startContainer, stopContainer, deleteContainer, restartContainer } = useEmulators();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedContainer, setSelectedContainer] = useState<QuickViewData | null>(null);
  const [filters, setFilters] = useState<ContainerFilters>({
    app: '',
    avatarId: '',
    mode: '',
    status: ''
  });

  const apps = ['Facebook', 'Instagram', 'WhatsApp', 'TikTok', 'Twitter', 'YouTube'];
  const modes = ['Auto', 'Manual'];
  const statuses = ['running', 'stopped', 'pending', 'error'];

  // Enhanced container data with tech stack information
  const enhancedContainers = containers.map(container => ({
    ...container,
    avatarUuid: `avatar-${container.id.slice(-8)}`,
    launchMode: Math.random() > 0.5 ? 'Auto' : 'Manual',
    ipAddress: `192.168.1.${Math.floor(Math.random() * 254) + 1}`,
    proxyStatus: Math.random() > 0.3 ? 'Active' : 'Inactive',
    app: apps[Math.floor(Math.random() * apps.length)],
    environment: {
      python: '3.10.12',
      appium: '2.4.1',
      ubuntu: '20.04 LTS',
      android: '12.0'
    },
    logs: [
      `[${new Date().toISOString()}] Ubuntu 20.04 LTS container ${container.name} started successfully`,
      `[${new Date().toISOString()}] Python 3.10.12 runtime initialized`,
      `[${new Date().toISOString()}] Appium 2.4.1 server listening on port ${container.appiumPort || 4723}`,
      `[${new Date().toISOString()}] VNC server started on port ${container.vncPort || 5901}`,
      `[${new Date().toISOString()}] Android 12.0 system boot completed`,
      `[${new Date().toISOString()}] UiAutomator2 driver ready for automation`,
      `[${new Date().toISOString()}] Device ready for Python 3.10 script execution`
    ]
  }));

  // Filter containers based on search and filters
  const filteredContainers = enhancedContainers.filter(container => {
    const matchesSearch = searchTerm === '' || 
      container.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      container.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      container.avatarUuid.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesApp = filters.app === '' || container.app === filters.app;
    const matchesAvatarId = filters.avatarId === '' || container.avatarUuid.includes(filters.avatarId);
    const matchesMode = filters.mode === '' || container.launchMode === filters.mode;
    const matchesStatus = filters.status === '' || container.status === filters.status;

    return matchesSearch && matchesApp && matchesAvatarId && matchesMode && matchesStatus;
  });

  const stats = {
    total: enhancedContainers.length,
    running: enhancedContainers.filter(c => c.status === 'running').length,
    stopped: enhancedContainers.filter(c => c.status === 'stopped').length,
    error: enhancedContainers.filter(c => c.status === 'error').length,
    avgCpu: enhancedContainers.reduce((acc, c) => acc + c.cpuUsage, 0) / enhancedContainers.length || 0,
    avgMemory: enhancedContainers.reduce((acc, c) => acc + c.memoryUsage, 0) / enhancedContainers.length || 0,
    avgNetwork: enhancedContainers.reduce((acc, c) => acc + c.networkUsage, 0) / enhancedContainers.length || 0,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-600 bg-green-100 border-green-200';
      case 'stopped': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'pending': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'error': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running': return <CheckCircle className="w-4 h-4" />;
      case 'stopped': return <XCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4 animate-pulse" />;
      case 'error': return <AlertTriangle className="w-4 h-4" />;
      default: return <XCircle className="w-4 h-4" />;
    }
  };

  const handleQuickView = (container: any) => {
    setSelectedContainer({
      id: container.id,
      name: container.name,
      status: container.status,
      avatarUuid: container.avatarUuid,
      launchMode: container.launchMode,
      cpuUsage: container.cpuUsage,
      ramUsage: container.memoryUsage,
      ipAddress: container.ipAddress,
      proxyStatus: container.proxyStatus,
      startedAt: container.createdAt,
      logs: container.logs,
      environment: container.environment
    });
  };

  const clearFilters = () => {
    setFilters({
      app: '',
      avatarId: '',
      mode: '',
      status: ''
    });
    setSearchTerm('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Ubuntu 20.04 containers...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Controls - Responsive Layout */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Container Dashboard</h1>
          <p className="text-gray-600">Real-time overview of Android 12.0 emulator containers running on Ubuntu 20.04</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {/* Tech Stack Indicator */}
          <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-xs font-medium text-blue-700">Python 3.10</span>
            </div>
            <div className="w-px h-4 bg-blue-300"></div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs font-medium text-green-700">Appium 2.4.1</span>
            </div>
            <div className="w-px h-4 bg-blue-300"></div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span className="text-xs font-medium text-orange-700">Ubuntu 20.04</span>
            </div>
          </div>

          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              autoRefresh 
                ? 'bg-green-50 border-green-200 text-green-700' 
                : 'bg-gray-50 border-gray-200 text-gray-600'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${autoRefresh ? 'animate-spin' : ''}`} />
            Auto Refresh
          </button>
          
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
            <Play className="w-4 h-4" />
            Launch New
          </button>
        </div>
      </div>

      {/* Rest of the component remains the same */}
      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search by container ID, avatar UUID, or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
              showFilters ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-gray-300 text-gray-600'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Controls */}
        {showFilters && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">App</label>
              <select
                value={filters.app}
                onChange={(e) => setFilters({...filters, app: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Apps</option>
                {apps.map(app => (
                  <option key={app} value={app}>{app}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Avatar ID</label>
              <input
                type="text"
                placeholder="Enter Avatar ID"
                value={filters.avatarId}
                onChange={(e) => setFilters({...filters, avatarId: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mode</label>
              <select
                value={filters.mode}
                onChange={(e) => setFilters({...filters, mode: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Modes</option>
                {modes.map(mode => (
                  <option key={mode} value={mode}>{mode}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({...filters, status: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Status</option>
                {statuses.map(status => (
                  <option key={status} value={status} className="capitalize">{status}</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button
                onClick={clearFilters}
                className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                Clear Filters
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <Monitor className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Running</p>
              <p className="text-2xl font-bold text-green-600">{stats.running}</p>
            </div>
            <Activity className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg CPU</p>
              <p className="text-2xl font-bold text-orange-600">{stats.avgCpu.toFixed(1)}%</p>
            </div>
            <Cpu className="w-8 h-8 text-orange-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg RAM</p>
              <p className="text-2xl font-bold text-purple-600">{stats.avgMemory.toFixed(1)}GB</p>
            </div>
            <HardDrive className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Network</p>
              <p className="text-2xl font-bold text-indigo-600">{stats.avgNetwork.toFixed(1)}MB/s</p>
            </div>
            <Network className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
      </div>

      {/* Container Display */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContainers.map((container) => (
            <div
              key={container.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all cursor-pointer group"
              onClick={() => handleQuickView(container)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-100 p-2 rounded-lg">
                    <Smartphone className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {container.name}
                    </h3>
                    <p className="text-sm text-gray-500">{container.app}</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(container.status)}`}>
                  {getStatusIcon(container.status)}
                  {container.status}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Avatar UUID:</span>
                  <span className="font-mono text-gray-900">{container.avatarUuid}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Mode:</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    container.launchMode === 'Auto' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {container.launchMode}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">IP Address:</span>
                  <span className="font-mono text-gray-900">{container.ipAddress}</span>
                </div>
              </div>

              {/* Tech Stack Info */}
              <div className="mb-4 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-blue-700 font-medium">Python {container.environment.python}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-green-700 font-medium">Appium {container.environment.appium}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span className="text-orange-700 font-medium">Ubuntu {container.environment.ubuntu}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-purple-700 font-medium">Android {container.environment.android}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-orange-600">{container.cpuUsage.toFixed(1)}%</div>
                  <div className="text-xs text-gray-500">CPU</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-600">{container.memoryUsage.toFixed(1)}GB</div>
                  <div className="text-xs text-gray-500">RAM</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-indigo-600">{container.networkUsage.toFixed(1)}MB/s</div>
                  <div className="text-xs text-gray-500">Network</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  {container.status === 'running' ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        stopContainer(container.id);
                      }}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Stop Container"
                    >
                      <Square className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        startContainer(container.id);
                      }}
                      className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                      title="Start Container"
                    >
                      <Play className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      restartContainer(container.id);
                    }}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Restart Container"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle inspect logs
                    }}
                    className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                    title="Inspect Logs"
                  >
                    <FileText className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Wifi className={`w-3 h-3 ${container.proxyStatus === 'Active' ? 'text-green-500' : 'text-gray-400'}`} />
                  Proxy {container.proxyStatus}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Container</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Avatar UUID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tech Stack</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Resources</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Network</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredContainers.map((container) => (
                  <tr 
                    key={container.id} 
                    className="hover:bg-gray-50 cursor-pointer"
                    onClick={() => handleQuickView(container)}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <Smartphone className="w-5 h-5 text-gray-400" />
                        <div>
                          <div className="font-medium text-gray-900">{container.name}</div>
                          <div className="text-sm text-gray-500">{container.app}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(container.status)}`}>
                        {getStatusIcon(container.status)}
                        {container.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm text-gray-900">{container.avatarUuid}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1">
                          <span className="bg-blue-100 text-blue-700 px-1 rounded text-xs">Python {container.environment.python}</span>
                          <span className="bg-green-100 text-green-700 px-1 rounded text-xs">Appium {container.environment.appium}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="bg-orange-100 text-orange-700 px-1 rounded text-xs">Ubuntu {container.environment.ubuntu}</span>
                          <span className="bg-purple-100 text-purple-700 px-1 rounded text-xs">Android {container.environment.android}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1 text-sm">
                        <div>CPU: {container.cpuUsage.toFixed(1)}%</div>
                        <div>RAM: {container.memoryUsage.toFixed(1)}GB</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1 text-sm">
                        <div>{container.ipAddress}</div>
                        <div className="flex items-center gap-1">
                          <Wifi className={`w-3 h-3 ${container.proxyStatus === 'Active' ? 'text-green-500' : 'text-gray-400'}`} />
                          {container.proxyStatus}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        {container.status === 'running' ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              stopContainer(container.id);
                            }}
                            className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Stop"
                          >
                            <Square className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              startContainer(container.id);
                            }}
                            className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                            title="Start"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            restartContainer(container.id);
                          }}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="Restart"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Handle logs
                          }}
                          className="p-1 text-gray-600 hover:bg-gray-50 rounded transition-colors"
                          title="Logs"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleQuickView(container);
                          }}
                          className="p-1 text-purple-600 hover:bg-purple-50 rounded transition-colors"
                          title="Quick View"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Quick View Modal */}
      {selectedContainer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedContainer.name}</h2>
                  <p className="text-gray-600">Ubuntu 20.04 Container Details & Environment</p>
                </div>
                <button
                  onClick={() => setSelectedContainer(null)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Environment Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Terminal className="w-5 h-5" />
                  Technology Stack
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Code className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">Python Runtime</span>
                    </div>
                    <div className="text-lg font-bold text-blue-700">{selectedContainer.environment.python}</div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Smartphone className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-900">Appium Server</span>
                    </div>
                    <div className="text-lg font-bold text-green-700">{selectedContainer.environment.appium}</div>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Server className="w-4 h-4 text-orange-600" />
                      <span className="text-sm font-medium text-orange-900">Ubuntu OS</span>
                    </div>
                    <div className="text-lg font-bold text-orange-700">{selectedContainer.environment.ubuntu}</div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Monitor className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium text-purple-900">Android</span>
                    </div>
                    <div className="text-lg font-bold text-purple-700">{selectedContainer.environment.android}</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Status</label>
                    <div className="mt-1">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(selectedContainer.status)}`}>
                        {getStatusIcon(selectedContainer.status)}
                        {selectedContainer.status}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Avatar UUID</label>
                    <div className="mt-1 font-mono text-sm text-gray-900">{selectedContainer.avatarUuid}</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Launch Mode</label>
                    <div className="mt-1">
                      <span className={`px-2 py-1 rounded text-xs ${
                        selectedContainer.launchMode === 'Auto' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {selectedContainer.launchMode}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">IP Address</label>
                    <div className="mt-1 font-mono text-sm text-gray-900">{selectedContainer.ipAddress}</div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-500">CPU Usage</label>
                    <div className="mt-1 text-lg font-bold text-orange-600">{selectedContainer.cpuUsage.toFixed(1)}%</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">RAM Usage</label>
                    <div className="mt-1 text-lg font-bold text-purple-600">{selectedContainer.ramUsage.toFixed(1)} GB</div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Proxy Status</label>
                    <div className="mt-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs ${
                        selectedContainer.proxyStatus === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        <Wifi className="w-3 h-3" />
                        {selectedContainer.proxyStatus}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Started At</label>
                    <div className="mt-1 text-sm text-gray-900 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {selectedContainer.startedAt.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500 mb-2 block">Ubuntu 20.04 Container Logs</label>
                <div className="bg-gray-900 rounded-lg p-4 max-h-64 overflow-y-auto">
                  <div className="space-y-1 font-mono text-sm">
                    {selectedContainer.logs.map((log, index) => (
                      <div key={index} className="text-green-400">{log}</div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                <button className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors">
                  View Full Logs
                </button>
                <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                  Connect via noVNC
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {filteredContainers.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <Monitor className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Ubuntu 20.04 containers found</h3>
          <p className="text-gray-600 mb-4">
            {searchTerm || Object.values(filters).some(f => f) 
              ? 'Try adjusting your search or filters' 
              : 'Launch your first Android 12.0 emulator on Ubuntu 20.04 to get started'
            }
          </p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 mx-auto transition-colors">
            <Play className="w-4 h-4" />
            Launch New Emulator
          </button>
        </div>
      )}
    </div>
  );
};