import React from 'react';
import { Shield } from 'lucide-react';

export const SecurityView: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Security</h1>
          <p className="text-gray-600">Manage security settings and access controls</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-12">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Security Center</h3>
          <p className="text-gray-600">This view will contain security and access control features.</p>
        </div>
      </div>
    </div>
  );
};