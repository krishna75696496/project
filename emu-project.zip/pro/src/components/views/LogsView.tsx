import React, { useState, useEffect, useRef } from 'react';
import { 
  BarChart3, 
  FileText, 
  Search, 
  Filter, 
  Download, 
  RefreshCw, 
  Play, 
  Pause, 
  Terminal, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  XCircle, 
  Clock, 
  Eye, 
  EyeOff, 
  Copy, 
  Trash2, 
  Settings, 
  Calendar, 
  Activity, 
  Zap, 
  Globe, 
  Server, 
  Code, 
  Bug, 
  Smartphone, 
  X,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Archive,
  Database,
  Cpu,
  HardDrive,
  Network,
  Users,
  Shield
} from 'lucide-react';

interface LogEntry {
  id: string;
  log_type: 'system' | 'appium' | 'api' | 'container' | 'security';
  container_id: string;
  container_name: string;
  timestamp: Date;
  log_message: string;
  severity: 'debug' | 'info' | 'warning' | 'error' | 'critical';
  source: string;
  user?: string;
  metadata?: Record<string, any>;
}

interface LogFilter {
  logType: string;
  containerId: string;
  severity: string;
  dateRange: {
    start: string;
    end: string;
  };
  searchTerm: string;
  scriptName: string;
}

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
}

export const LogsView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'system' | 'appium' | 'api' | 'all'>('all');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);
  const [isLiveStream, setIsLiveStream] = useState(true);
  const [autoScroll, setAutoScroll] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [expandedLogs, setExpandedLogs] = useState<Set<string>>(new Set());
  
  const logsContainerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const [filters, setFilters] = useState<LogFilter>({
    logType: '',
    containerId: '',
    severity: '',
    dateRange: {
      start: '',
      end: ''
    },
    searchTerm: '',
    scriptName: ''
  });

  // Mock containers for filter dropdown
  const containers = [
    { id: 'emulator-1', name: 'Pixel 6 Pro - Android 13' },
    { id: 'emulator-2', name: 'Galaxy S23 - Android 14' },
    { id: 'emulator-3', name: 'OnePlus 11 - Android 13' },
    { id: 'emulator-4', name: 'iPhone 14 Pro - iOS 16' }
  ];

  const logTypes = [
    { id: 'system', name: 'System Logs', icon: Server, color: 'blue' },
    { id: 'appium', name: 'Appium Logs', icon: Smartphone, color: 'green' },
    { id: 'api', name: 'API Logs', icon: Globe, color: 'purple' },
    { id: 'container', name: 'Container Logs', icon: Database, color: 'orange' },
    { id: 'security', name: 'Security Logs', icon: Shield, color: 'red' }
  ];

  const severityLevels = [
    { id: 'debug', name: 'Debug', color: 'gray' },
    { id: 'info', name: 'Info', color: 'blue' },
    { id: 'warning', name: 'Warning', color: 'yellow' },
    { id: 'error', name: 'Error', color: 'red' },
    { id: 'critical', name: 'Critical', color: 'red' }
  ];

  // Generate mock logs
  useEffect(() => {
    const generateMockLogs = () => {
      const mockLogs: LogEntry[] = [];
      const logMessages = {
        system: [
          'Container emulator-1 started successfully',
          'Docker daemon health check passed',
          'Volume mounted: /data/avatars/avatar-12345678',
          'Network bridge created: br-android-net',
          'Resource allocation: CPU 2 cores, RAM 4GB',
          'System cleanup completed',
          'Backup process initiated',
          'SSL certificate renewed'
        ],
        appium: [
          'Appium server started on port 4723',
          'New session created with capabilities: {platformName: Android}',
          'Element located: //android.widget.Button[@text="Login"]',
          'Touch action performed at coordinates (500, 800)',
          'Screenshot captured: screenshot_20240120_103045.png',
          'Session ended: 4a8b9c2d-1e3f-4567-8901-234567890abc',
          'Driver initialization completed',
          'Test execution finished with status: PASSED'
        ],
        api: [
          'POST /api/containers/launch - 201 Created',
          'GET /api/containers/emulator-1/status - 200 OK',
          'PUT /api/containers/emulator-1/stop - 200 OK',
          'DELETE /api/containers/emulator-3 - 204 No Content',
          'Authentication successful for user: john.doe',
          'Rate limit exceeded for IP: 192.168.1.100',
          'API key validation failed',
          'Webhook delivered successfully'
        ],
        container: [
          'Container health check: HEALTHY',
          'Port mapping: 5901:5901 (VNC)',
          'Environment variable set: ANDROID_VERSION=13',
          'Volume binding: /host/data:/container/data',
          'Container stopped gracefully',
          'Memory usage: 2.1GB / 4GB (52%)',
          'CPU usage spike detected: 95%',
          'Network traffic: 15.3 MB/s'
        ],
        security: [
          'Failed login attempt from IP: 192.168.1.200',
          'User john.doe granted admin privileges',
          'SSL handshake completed successfully',
          'Firewall rule updated: ALLOW port 4723',
          'Security scan completed: 0 vulnerabilities',
          'Access token expired for user: jane.smith',
          'Suspicious activity detected: multiple failed logins',
          'Encryption key rotated successfully'
        ]
      };

      for (let i = 0; i < 200; i++) {
        const logType = logTypes[Math.floor(Math.random() * logTypes.length)].id as LogEntry['log_type'];
        const severity = severityLevels[Math.floor(Math.random() * severityLevels.length)].id as LogEntry['severity'];
        const container = containers[Math.floor(Math.random() * containers.length)];
        const messages = logMessages[logType] || logMessages.system;
        
        mockLogs.push({
          id: `log-${i}`,
          log_type: logType,
          container_id: container.id,
          container_name: container.name,
          timestamp: new Date(Date.now() - Math.random() * 86400000 * 7), // Last 7 days
          log_message: messages[Math.floor(Math.random() * messages.length)],
          severity,
          source: `${logType}-service`,
          user: Math.random() > 0.5 ? ['john.doe', 'jane.smith', 'admin'][Math.floor(Math.random() * 3)] : undefined,
          metadata: {
            pid: Math.floor(Math.random() * 10000),
            thread: `thread-${Math.floor(Math.random() * 100)}`,
            requestId: `req-${Math.random().toString(36).substr(2, 9)}`
          }
        });
      }

      return mockLogs.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    };

    setLogs(generateMockLogs());
  }, []);

  // Live stream simulation
  useEffect(() => {
    if (!isLiveStream) return;

    const interval = setInterval(() => {
      const newLog: LogEntry = {
        id: `log-${Date.now()}`,
        log_type: logTypes[Math.floor(Math.random() * logTypes.length)].id as LogEntry['log_type'],
        container_id: containers[Math.floor(Math.random() * containers.length)].id,
        container_name: containers[Math.floor(Math.random() * containers.length)].name,
        timestamp: new Date(),
        log_message: `Live log entry: ${Math.random().toString(36).substr(2, 9)}`,
        severity: severityLevels[Math.floor(Math.random() * severityLevels.length)].id as LogEntry['severity'],
        source: 'live-stream',
        metadata: {
          pid: Math.floor(Math.random() * 10000),
          thread: `thread-${Math.floor(Math.random() * 100)}`
        }
      };

      setLogs(prev => [newLog, ...prev.slice(0, 999)]); // Keep last 1000 logs
    }, 3000);

    return () => clearInterval(interval);
  }, [isLiveStream]);

  // Filter logs
  useEffect(() => {
    let filtered = logs;

    // Tab filter
    if (activeTab !== 'all') {
      filtered = filtered.filter(log => log.log_type === activeTab);
    }

    // Search filter
    if (filters.searchTerm) {
      const regex = new RegExp(filters.searchTerm, 'i');
      filtered = filtered.filter(log => 
        regex.test(log.log_message) || 
        regex.test(log.container_name) ||
        regex.test(log.source)
      );
    }

    // Other filters
    if (filters.logType) {
      filtered = filtered.filter(log => log.log_type === filters.logType);
    }

    if (filters.containerId) {
      filtered = filtered.filter(log => log.container_id === filters.containerId);
    }

    if (filters.severity) {
      filtered = filtered.filter(log => log.severity === filters.severity);
    }

    // Date range filter
    if (filters.dateRange.start) {
      const startDate = new Date(filters.dateRange.start);
      filtered = filtered.filter(log => log.timestamp >= startDate);
    }

    if (filters.dateRange.end) {
      const endDate = new Date(filters.dateRange.end);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(log => log.timestamp <= endDate);
    }

    setFilteredLogs(filtered);
  }, [logs, activeTab, filters]);

  // Auto scroll
  useEffect(() => {
    if (autoScroll && logsContainerRef.current) {
      logsContainerRef.current.scrollTop = 0;
    }
  }, [filteredLogs, autoScroll]);

  // Toast notifications
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'debug': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'info': return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'warning': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'error': return 'text-red-600 bg-red-100 border-red-200';
      case 'critical': return 'text-red-700 bg-red-200 border-red-300';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'debug': return <Bug className="w-4 h-4" />;
      case 'info': return <Info className="w-4 h-4" />;
      case 'warning': return <AlertTriangle className="w-4 h-4" />;
      case 'error': return <XCircle className="w-4 h-4" />;
      case 'critical': return <XCircle className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  const getLogTypeIcon = (logType: string) => {
    const type = logTypes.find(t => t.id === logType);
    if (!type) return <FileText className="w-4 h-4" />;
    const Icon = type.icon;
    return <Icon className="w-4 h-4" />;
  };

  const exportLogs = () => {
    const csvContent = [
      'Timestamp,Type,Container,Severity,Message,Source',
      ...filteredLogs.map(log => 
        `"${log.timestamp.toISOString()}","${log.log_type}","${log.container_name}","${log.severity}","${log.log_message.replace(/"/g, '""')}","${log.source}"`
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    addToast({
      type: 'success',
      title: 'Export Complete',
      message: `${filteredLogs.length} log entries exported to CSV`
    });
  };

  const clearFilters = () => {
    setFilters({
      logType: '',
      containerId: '',
      severity: '',
      dateRange: { start: '', end: '' },
      searchTerm: '',
      scriptName: ''
    });
    setActiveTab('all');
  };

  const toggleLogExpansion = (logId: string) => {
    setExpandedLogs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(logId)) {
        newSet.delete(logId);
      } else {
        newSet.add(logId);
      }
      return newSet;
    });
  };

  const copyLogMessage = (message: string) => {
    navigator.clipboard.writeText(message);
    addToast({
      type: 'success',
      title: 'Copied',
      message: 'Log message copied to clipboard'
    });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toast Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`max-w-sm w-full bg-white rounded-lg shadow-lg border-l-4 p-4 ${
              toast.type === 'success' ? 'border-green-500' :
              toast.type === 'error' ? 'border-red-500' :
              toast.type === 'warning' ? 'border-yellow-500' :
              'border-blue-500'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
                {toast.type === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                {toast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                {toast.type === 'info' && <Info className="w-5 h-5 text-blue-500" />}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{toast.title}</p>
                <p className="text-sm text-gray-500">{toast.message}</p>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Logs & Monitoring</h1>
            <p className="text-gray-600">Centralized view for emulator and script logs with real-time streaming</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsLiveStream(!isLiveStream)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                isLiveStream 
                  ? 'bg-green-50 border-green-200 text-green-700' 
                  : 'border-gray-300 text-gray-600'
              }`}
            >
              {isLiveStream ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              Live Stream
            </button>
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                autoScroll 
                  ? 'bg-blue-50 border-blue-200 text-blue-700' 
                  : 'border-gray-300 text-gray-600'
              }`}
            >
              <Activity className="w-4 h-4" />
              Auto Scroll
            </button>
            <button
              onClick={exportLogs}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Tabs and Search */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          {/* Log Type Tabs */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                activeTab === 'all'
                  ? 'bg-blue-100 text-blue-700 border border-blue-200'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              All Logs
            </button>
            {logTypes.map(type => (
              <button
                key={type.id}
                onClick={() => setActiveTab(type.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  activeTab === type.id
                    ? `bg-${type.color}-100 text-${type.color}-700 border border-${type.color}-200`
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <type.icon className="w-4 h-4" />
                {type.name}
              </button>
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                showFilters ? 'bg-purple-50 border-purple-200 text-purple-700' : 'border-gray-300 text-gray-600'
              }`}
            >
              <Filter className="w-4 h-4" />
              Filters
            </button>
            <button
              onClick={clearFilters}
              className="px-3 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Search logs (supports regex)..."
            value={filters.searchTerm}
            onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Log Type</label>
                <select
                  value={filters.logType}
                  onChange={(e) => setFilters(prev => ({ ...prev, logType: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Types</option>
                  {logTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Container</label>
                <select
                  value={filters.containerId}
                  onChange={(e) => setFilters(prev => ({ ...prev, containerId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Containers</option>
                  {containers.map(container => (
                    <option key={container.id} value={container.id}>{container.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
                <select
                  value={filters.severity}
                  onChange={(e) => setFilters(prev => ({ ...prev, severity: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Severities</option>
                  {severityLevels.map(level => (
                    <option key={level.id} value={level.id}>{level.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={filters.dateRange.start}
                    onChange={(e) => setFilters(prev => ({ 
                      ...prev, 
                      dateRange: { ...prev.dateRange, start: e.target.value }
                    }))}
                    className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                  <input
                    type="date"
                    value={filters.dateRange.end}
                    onChange={(e) => setFilters(prev => ({ 
                      ...prev, 
                      dateRange: { ...prev.dateRange, end: e.target.value }
                    }))}
                    className="flex-1 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Stats Bar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-6">
            <span className="text-gray-600">
              Showing <span className="font-medium text-gray-900">{filteredLogs.length}</span> of <span className="font-medium text-gray-900">{logs.length}</span> logs
            </span>
            <div className="flex items-center gap-4">
              {severityLevels.map(level => {
                const count = filteredLogs.filter(log => log.severity === level.id).length;
                return (
                  <div key={level.id} className="flex items-center gap-1">
                    <div className={`w-2 h-2 rounded-full bg-${level.color}-500`} />
                    <span className="text-gray-600">{level.name}: {count}</span>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex items-center gap-2 text-gray-500">
            <Clock className="w-4 h-4" />
            <span>Last updated: {new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </div>

      {/* Logs Container */}
      <div className="flex-1 overflow-hidden">
        <div 
          ref={logsContainerRef}
          className="h-full overflow-y-auto bg-gray-50"
        >
          {filteredLogs.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {filteredLogs.map((log) => (
                <div key={log.id} className="bg-white hover:bg-gray-50 transition-colors">
                  <div className="p-4">
                    <div className="flex items-start gap-4">
                      {/* Timestamp and Expand Button */}
                      <div className="flex items-center gap-2 w-32 flex-shrink-0">
                        <button
                          onClick={() => toggleLogExpansion(log.id)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          {expandedLogs.has(log.id) ? 
                            <ChevronDown className="w-4 h-4" /> : 
                            <ChevronRight className="w-4 h-4" />
                          }
                        </button>
                        <span className="text-xs text-gray-500 font-mono">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                      </div>

                      {/* Log Type Icon */}
                      <div className="flex-shrink-0">
                        {getLogTypeIcon(log.log_type)}
                      </div>

                      {/* Severity Badge */}
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(log.severity)}`}>
                        {getSeverityIcon(log.severity)}
                        {log.severity.toUpperCase()}
                      </span>

                      {/* Container Info */}
                      <div className="flex-shrink-0 w-48">
                        <div className="text-sm font-medium text-gray-900">{log.container_name}</div>
                        <div className="text-xs text-gray-500">{log.source}</div>
                      </div>

                      {/* Log Message */}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900 break-words">
                          {filters.searchTerm && filters.searchTerm.length > 0 ? (
                            <span dangerouslySetInnerHTML={{
                              __html: log.log_message.replace(
                                new RegExp(`(${filters.searchTerm})`, 'gi'),
                                '<mark class="bg-yellow-200">$1</mark>'
                              )
                            }} />
                          ) : (
                            log.log_message
                          )}
                        </p>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <button
                          onClick={() => copyLogMessage(log.log_message)}
                          className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                          title="Copy Message"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setSelectedLog(log)}
                          className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Expanded Details */}
                    {expandedLogs.has(log.id) && (
                      <div className="mt-3 ml-8 p-3 bg-gray-50 rounded-lg">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-700">Full Timestamp:</span>
                            <div className="font-mono text-gray-600">{log.timestamp.toISOString()}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Log ID:</span>
                            <div className="font-mono text-gray-600">{log.id}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Container ID:</span>
                            <div className="font-mono text-gray-600">{log.container_id}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">User:</span>
                            <div className="text-gray-600">{log.user || 'System'}</div>
                          </div>
                          {log.metadata && (
                            <div className="col-span-2">
                              <span className="font-medium text-gray-700">Metadata:</span>
                              <pre className="mt-1 text-xs bg-white p-2 rounded border overflow-x-auto">
                                {JSON.stringify(log.metadata, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <Terminal className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No logs found</h3>
                <p className="text-gray-600">
                  {filters.searchTerm || Object.values(filters).some(f => f) 
                    ? 'Try adjusting your search or filters' 
                    : 'Logs will appear here as they are generated'
                  }
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Log Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Log Entry Details</h2>
                <button
                  onClick={() => setSelectedLog(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Timestamp</label>
                  <div className="mt-1 font-mono text-sm text-gray-900">{selectedLog.timestamp.toISOString()}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Severity</label>
                  <div className="mt-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(selectedLog.severity)}`}>
                      {getSeverityIcon(selectedLog.severity)}
                      {selectedLog.severity.toUpperCase()}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Log Type</label>
                  <div className="mt-1 text-sm text-gray-900 capitalize">{selectedLog.log_type}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Source</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedLog.source}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Container</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedLog.container_name}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">User</label>
                  <div className="mt-1 text-sm text-gray-900">{selectedLog.user || 'System'}</div>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Message</label>
                <div className="mt-1 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-900 whitespace-pre-wrap">{selectedLog.log_message}</p>
                </div>
              </div>

              {selectedLog.metadata && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Metadata</label>
                  <div className="mt-1 p-3 bg-gray-50 rounded-lg">
                    <pre className="text-xs text-gray-900 overflow-x-auto">
                      {JSON.stringify(selectedLog.metadata, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => copyLogMessage(selectedLog.log_message)}
                  className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Copy Message
                </button>
                <button
                  onClick={() => setSelectedLog(null)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};