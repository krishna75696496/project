import React from 'react';
import { 
  Monitor, 
  Play, 
  Settings, 
  FileText, 
  Database, 
  Network, 
  BarChart3, 
  GitBranch,
  Shield,
  Mouse,
  Layers,
  Zap,
  Activity
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Monitor, category: 'overview' },
  { id: 'launch', label: 'Launch Emulator', icon: Play, category: 'management' },
  { id: 'tasks', label: 'Task Assignment', icon: FileText, category: 'management' },
  { id: 'control', label: 'Manual Control', icon: Mouse, category: 'management' },
  { id: 'logs', label: 'Logs & Monitoring', icon: BarChart3, category: 'monitoring' },
  { id: 'volumes', label: 'Volume Management', icon: Database, category: 'infrastructure' },
  { id: 'proxy', label: 'Proxy Settings', icon: Network, category: 'infrastructure' },
  { id: 'kubernetes', label: 'Kubernetes', icon: Layers, category: 'infrastructure' },
  { id: 'reports', label: 'Reports', icon: BarChart3, category: 'analytics' },
  { id: 'cicd', label: 'CI/CD Integration', icon: GitBranch, category: 'integrations' },
  { id: 'security', label: 'Security', icon: Shield, category: 'settings' },
];

const categories = {
  overview: { label: 'Overview', color: 'text-purple-400' },
  management: { label: 'Management', color: 'text-blue-400' },
  monitoring: { label: 'Monitoring', color: 'text-green-400' },
  infrastructure: { label: 'Infrastructure', color: 'text-orange-400' },
  analytics: { label: 'Analytics', color: 'text-pink-400' },
  integrations: { label: 'Integrations', color: 'text-indigo-400' },
  settings: { label: 'Settings', color: 'text-gray-400' },
};

export const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange }) => {
  const groupedItems = menuItems.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, typeof menuItems>);

  return (
    <div className="w-72 bg-slate-900/95 backdrop-blur-xl border-r border-slate-800/50 text-white h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-800/50">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-2 rounded-xl">
            <Monitor className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Emulator Hub
            </h1>
            <p className="text-slate-400 text-sm">Container Platform</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-6">
          {Object.entries(groupedItems).map(([categoryKey, items]) => {
            const category = categories[categoryKey as keyof typeof categories];
            return (
              <div key={categoryKey}>
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${
                    categoryKey === 'overview' ? 'from-purple-500 to-purple-600' :
                    categoryKey === 'management' ? 'from-blue-500 to-blue-600' :
                    categoryKey === 'monitoring' ? 'from-green-500 to-green-600' :
                    categoryKey === 'infrastructure' ? 'from-orange-500 to-orange-600' :
                    categoryKey === 'analytics' ? 'from-pink-500 to-pink-600' :
                    categoryKey === 'integrations' ? 'from-indigo-500 to-indigo-600' :
                    'from-gray-500 to-gray-600'
                  }`}></div>
                  <h3 className={`text-xs font-semibold uppercase tracking-wider ${category.color}`}>
                    {category.label}
                  </h3>
                </div>
                <div className="space-y-1">
                  {items.map(item => {
                    const Icon = item.icon;
                    const isActive = activeView === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => onViewChange(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-200 group ${
                          isActive
                            ? 'bg-gradient-to-r from-purple-600/20 to-blue-600/20 text-white border border-purple-500/30 shadow-lg shadow-purple-500/10'
                            : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                        }`}
                      >
                        <div className={`p-1.5 rounded-lg transition-all duration-200 ${
                          isActive 
                            ? 'bg-gradient-to-r from-purple-500 to-blue-500 shadow-lg' 
                            : 'bg-slate-800/50 group-hover:bg-slate-700/50'
                        }`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className="font-medium text-sm">{item.label}</span>
                        {isActive && (
                          <div className="ml-auto">
                            <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full"></div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </nav>
      
      {/* Footer Status */}
      <div className="p-4 border-t border-slate-800/50">
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Activity className="w-4 h-4 text-green-400" />
            <span className="text-sm font-medium text-white">System Status</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Status</span>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 font-medium">Online</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Containers</span>
              <span className="text-white font-medium">2 active</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">CPU Load</span>
              <span className="text-white font-medium">45%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};