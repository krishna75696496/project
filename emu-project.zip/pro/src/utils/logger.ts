// Logger utility for Android emulator project

// Log levels
export enum LogLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error'
}

// Log entry interface
export interface LogEntry {
  timestamp: Date;
  level: LogLevel;
  message: string;
  context?: any;
  source?: string;
}

// Logger configuration
interface LoggerConfig {
  minLevel: LogLevel;
  enableConsole: boolean;
  enableRemote: boolean;
  remoteEndpoint?: string;
  bufferSize?: number;
}

// Default configuration
const defaultConfig: LoggerConfig = {
  minLevel: LogLevel.INFO,
  enableConsole: true,
  enableRemote: false,
  bufferSize: 100
};

class Logger {
  private config: LoggerConfig;
  private buffer: LogEntry[] = [];
  private remoteQueue: LogEntry[] = [];
  private flushInterval: number | null = null;

  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    
    if (this.config.enableRemote && this.config.remoteEndpoint) {
      // Set up periodic flushing of remote logs
      this.flushInterval = setInterval(() => this.flushRemoteLogs(), 10000) as unknown as number;
    }
  }

  // Log a message at the specified level
  private log(level: LogLevel, message: string, context?: any, source?: string): void {
    // Skip if below minimum level
    if (this.getLevelValue(level) < this.getLevelValue(this.config.minLevel)) {
      return;
    }

    const entry: LogEntry = {
      timestamp: new Date(),
      level,
      message,
      context,
      source
    };

    // Add to buffer
    this.buffer = [entry, ...this.buffer.slice(0, this.config.bufferSize! - 1)];

    // Console logging
    if (this.config.enableConsole) {
      this.logToConsole(entry);
    }

    // Remote logging
    if (this.config.enableRemote) {
      this.queueForRemoteLogging(entry);
    }
  }

  // Convert log level to numeric value for comparison
  private getLevelValue(level: LogLevel): number {
    switch (level) {
      case LogLevel.DEBUG: return 0;
      case LogLevel.INFO: return 1;
      case LogLevel.WARN: return 2;
      case LogLevel.ERROR: return 3;
      default: return 1;
    }
  }

  // Log to console with appropriate styling
  private logToConsole(entry: LogEntry): void {
    const timestamp = entry.timestamp.toISOString();
    const source = entry.source ? `[${entry.source}]` : '';
    
    switch (entry.level) {
      case LogLevel.DEBUG:
        console.debug(`${timestamp} ${source} ${entry.message}`, entry.context || '');
        break;
      case LogLevel.INFO:
        console.info(`${timestamp} ${source} ${entry.message}`, entry.context || '');
        break;
      case LogLevel.WARN:
        console.warn(`${timestamp} ${source} ${entry.message}`, entry.context || '');
        break;
      case LogLevel.ERROR:
        console.error(`${timestamp} ${source} ${entry.message}`, entry.context || '');
        break;
    }
  }

  // Queue log entry for remote logging
  private queueForRemoteLogging(entry: LogEntry): void {
    this.remoteQueue.push(entry);
    
    // Flush immediately for errors
    if (entry.level === LogLevel.ERROR) {
      this.flushRemoteLogs();
    }
  }

  // Flush queued logs to remote endpoint
  private async flushRemoteLogs(): Promise<void> {
    if (!this.remoteQueue.length || !this.config.remoteEndpoint) {
      return;
    }

    const logsToSend = [...this.remoteQueue];
    this.remoteQueue = [];

    try {
      await fetch(this.config.remoteEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ logs: logsToSend })
      });
    } catch (error) {
      // If remote logging fails, add back to queue
      console.error('Failed to send logs to remote endpoint:', error);
      this.remoteQueue = [...logsToSend, ...this.remoteQueue];
    }
  }

  // Public logging methods
  public debug(message: string, context?: any, source?: string): void {
    this.log(LogLevel.DEBUG, message, context, source);
  }

  public info(message: string, context?: any, source?: string): void {
    this.log(LogLevel.INFO, message, context, source);
  }

  public warn(message: string, context?: any, source?: string): void {
    this.log(LogLevel.WARN, message, context, source);
  }

  public error(message: string, context?: any, source?: string): void {
    this.log(LogLevel.ERROR, message, context, source);
  }

  // Get all logs
  public getLogs(level?: LogLevel): LogEntry[] {
    if (level) {
      return this.buffer.filter(entry => entry.level === level);
    }
    return this.buffer;
  }

  // Clear logs
  public clearLogs(): void {
    this.buffer = [];
  }

  // Update configuration
  public updateConfig(config: Partial<LoggerConfig>): void {
    this.config = { ...this.config, ...config };
    
    // Update flush interval if remote logging config changed
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
      this.flushInterval = null;
    }
    
    if (this.config.enableRemote && this.config.remoteEndpoint) {
      this.flushInterval = setInterval(() => this.flushRemoteLogs(), 10000) as unknown as number;
    }
  }

  // Clean up
  public dispose(): void {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
      this.flushInterval = null;
    }
    
    // Flush any remaining logs
    if (this.config.enableRemote && this.remoteQueue.length) {
      this.flushRemoteLogs();
    }
  }
}

// Create and export a default logger instance
export const logger = new Logger();

// Export the Logger class for custom instances
export default Logger;