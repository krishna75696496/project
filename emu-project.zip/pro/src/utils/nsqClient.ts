// NSQ client utility for browser environment
// Note: This is a mock implementation since browsers can't directly connect to NSQ

import { logger } from './logger';

// NSQ configuration
const NSQ_HOST = import.meta.env.VITE_NSQ_HOST || 'localhost';
const NSQ_PORT = parseInt(import.meta.env.VITE_NSQ_PORT || '4150');
const NSQ_HTTP_PORT = parseInt(import.meta.env.VITE_NSQ_HTTP_PORT || '4151');

// Message types
export interface NsqMessage<T = any> {
  id: string;
  topic: string;
  channel: string;
  timestamp: number;
  attempts: number;
  data: T;
}

export interface NsqSubscription {
  topic: string;
  channel: string;
  callback: (message: NsqMessage) => void | Promise<void>;
  unsubscribe: () => void;
}

// Mock NSQ client for browser environment
class NsqClient {
  private subscriptions: Map<string, NsqSubscription> = new Map();
  private connected: boolean = false;
  private mockWebSocket: any = null;
  private messageCounter: number = 0;

  constructor() {
    logger.info('Initializing NSQ client', { host: NSQ_HOST, port: NSQ_PORT }, 'NSQ');
  }

  // Connect to NSQ (mock implementation)
  public async connect(): Promise<boolean> {
    if (this.connected) {
      return true;
    }

    try {
      logger.info('Connecting to NSQ...', { host: NSQ_HOST, port: NSQ_PORT }, 'NSQ');
      
      // In a real implementation, this would establish a WebSocket connection
      // to a proxy server that communicates with NSQ
      
      // Simulate connection delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      this.connected = true;
      logger.info('Connected to NSQ', undefined, 'NSQ');
      return true;
    } catch (error) {
      logger.error('Failed to connect to NSQ', error, 'NSQ');
      this.connected = false;
      return false;
    }
  }

  // Publish a message to NSQ
  public async publish<T>(topic: string, data: T): Promise<boolean> {
    try {
      if (!this.connected) {
        await this.connect();
      }

      logger.debug(`Publishing message to ${topic}`, { data }, 'NSQ');
      
      // In a real implementation, this would send the message to NSQ via HTTP API
      // or through a WebSocket proxy
      
      // For this mock, we'll use the HTTP API endpoint
      const response = await fetch(`http://${NSQ_HOST}:${NSQ_HTTP_PORT}/pub?topic=${topic}`, {
        method: 'POST',
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        throw new Error(`Failed to publish message: ${response.statusText}`);
      }
      
      logger.debug(`Published message to ${topic}`, undefined, 'NSQ');
      return true;
    } catch (error) {
      logger.error(`Failed to publish message to ${topic}`, error, 'NSQ');
      return false;
    }
  }

  // Subscribe to a topic/channel (mock implementation)
  public async subscribe<T>(topic: string, channel: string, callback: (message: NsqMessage<T>) => void | Promise<void>): Promise<NsqSubscription> {
    const subscriptionId = `${topic}:${channel}:${Date.now()}`;
    
    logger.info(`Subscribing to ${topic}/${channel}`, undefined, 'NSQ');
    
    // In a real implementation, this would establish a subscription via WebSocket proxy
    
    // Create a mock subscription
    const subscription: NsqSubscription = {
      topic,
      channel,
      callback,
      unsubscribe: () => {
        this.subscriptions.delete(subscriptionId);
        logger.info(`Unsubscribed from ${topic}/${channel}`, undefined, 'NSQ');
      }
    };
    
    this.subscriptions.set(subscriptionId, subscription);
    
    // For demo purposes, simulate receiving messages periodically
    const interval = setInterval(() => {
      // Only send mock messages 20% of the time
      if (Math.random() > 0.8) {
        this.messageCounter++;
        const mockMessage: NsqMessage<T> = {
          id: `msg-${this.messageCounter}`,
          topic,
          channel,
          timestamp: Date.now(),
          attempts: 1,
          data: { mockData: true } as unknown as T
        };
        
        callback(mockMessage);
      }
    }, 5000);
    
    // Add cleanup to unsubscribe function
    const originalUnsubscribe = subscription.unsubscribe;
    subscription.unsubscribe = () => {
      clearInterval(interval);
      originalUnsubscribe();
    };
    
    return subscription;
  }

  // Disconnect from NSQ
  public disconnect(): void {
    if (!this.connected) {
      return;
    }
    
    logger.info('Disconnecting from NSQ', undefined, 'NSQ');
    
    // Unsubscribe from all topics
    for (const subscription of this.subscriptions.values()) {
      subscription.unsubscribe();
    }
    
    this.subscriptions.clear();
    this.connected = false;
    
    logger.info('Disconnected from NSQ', undefined, 'NSQ');
  }
}

// Create and export a singleton instance
export const nsqClient = new NsqClient();

export default nsqClient;