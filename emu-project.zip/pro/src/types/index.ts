export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'developer' | 'viewer';
  avatar?: string;
  lastLogin: Date;
}

export interface EmulatorContainer {
  id: string;
  name: string;
  status: 'running' | 'stopped' | 'pending' | 'error';
  androidVersion: string;
  deviceType: string;
  cpuUsage: number;
  memoryUsage: number;
  networkUsage: number;
  createdAt: Date;
  lastActivity: Date;
  assignedUser?: string;
  profileId?: string;
  vncPort?: number;
  appiumPort?: number;
  tasks?: Task[];
}

export interface Task {
  id: string;
  name: string;
  script: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  logs: string[];
  startTime?: Date;
  endTime?: Date;
  containerId: string;
}

export interface Profile {
  id: string;
  name: string;
  androidVersion: string;
  deviceType: string;
  apps: string[];
  settings: Record<string, any>;
  createdBy: string;
  isDefault: boolean;
}

export interface KubernetesPod {
  id: string;
  name: string;
  namespace: string;
  status: 'Running' | 'Pending' | 'Failed' | 'Succeeded';
  restarts: number;
  age: string;
  node: string;
  resources: {
    cpu: string;
    memory: string;
  };
}

export interface UsageStats {
  totalContainers: number;
  activeContainers: number;
  totalTasks: number;
  completedTasks: number;
  failedTasks: number;
  resourceUsage: {
    cpu: number;
    memory: number;
    storage: number;
  };
  dailyStats: Array<{
    date: string;
    containers: number;
    tasks: number;
  }>;
}