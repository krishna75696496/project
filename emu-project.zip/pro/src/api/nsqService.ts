// NSQ message queue service for Android emulator project

// NSQ configuration
const NSQ_HOST = import.meta.env.VITE_NSQ_HOST || 'localhost';
const NSQ_PORT = parseInt(import.meta.env.VITE_NSQ_PORT || '4150');
const NSQ_TOPIC = 'emulator_control';

// Message types
export interface ManualControlRequest {
  avatar_uuid: string;
  social_media_app: string;
  proxy_host?: string;
  proxy_port?: string;
  proxy_user?: string;
  proxy_pass?: string;
}

export interface VncPortResponse {
  container_id: string;
  vnc_port: number;
  avatar_uuid: string;
  timestamp: number;
}

// Function to send a manual control request via the API endpoint
export const sendManualControlRequest = async (request: ManualControlRequest): Promise<{ success: boolean; session_id?: string; error?: string }> => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manual-control`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify(request)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to send manual control request');
    }

    const data = await response.json();
    return {
      success: true,
      session_id: data.session_id
    };
  } catch (error) {
    console.error('Error sending manual control request:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Function to listen for VNC port responses (would be implemented in a real backend)
// In a browser environment, we would use WebSockets or Server-Sent Events to receive these updates
export const listenForVncPortResponse = (
  avatarUuid: string,
  callback: (response: VncPortResponse) => void
): { unsubscribe: () => void } => {
  // This is a mock implementation since browser can't directly connect to NSQ
  // In a real implementation, this would connect to a WebSocket server that bridges to NSQ
  
  console.log(`Started listening for VNC port responses for avatar ${avatarUuid}`);
  
  // Simulate a response after 3 seconds
  const timeout = setTimeout(() => {
    const mockResponse: VncPortResponse = {
      container_id: `container-${Math.random().toString(36).substring(7)}`,
      vnc_port: 5900 + Math.floor(Math.random() * 100),
      avatar_uuid: avatarUuid,
      timestamp: Date.now()
    };
    
    callback(mockResponse);
  }, 3000);
  
  return {
    unsubscribe: () => {
      clearTimeout(timeout);
      console.log(`Stopped listening for VNC port responses for avatar ${avatarUuid}`);
    }
  };
};