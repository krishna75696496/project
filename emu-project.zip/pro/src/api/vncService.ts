import supabase from '../lib/supabase';

export interface VncSessionCreateParams {
  avatar_id: string;
  container_id: string;
  exposed_port: number;
  session_mode?: 'manual' | 'auto';
}

export interface VncSessionUpdateParams {
  ended_at?: Date;
}

// Get all active VNC sessions
export const getActiveSessions = async () => {
  const { data, error } = await supabase
    .from('vnc_sessions')
    .select('*')
    .is('ended_at', null)
    .order('started_at', { ascending: false });

  if (error) {
    console.error('Error fetching VNC sessions:', error);
    throw error;
  }

  return data;
};

// Get a specific VNC session by ID
export const getSessionById = async (sessionId: string) => {
  const { data, error } = await supabase
    .from('vnc_sessions')
    .select('*')
    .eq('id', sessionId)
    .single();

  if (error) {
    console.error(`Error fetching VNC session ${sessionId}:`, error);
    throw error;
  }

  return data;
};

// Get VNC sessions for a specific avatar
export const getSessionsByAvatarId = async (avatarId: string) => {
  const { data, error } = await supabase
    .from('vnc_sessions')
    .select('*')
    .eq('avatar_id', avatarId)
    .order('started_at', { ascending: false });

  if (error) {
    console.error(`Error fetching VNC sessions for avatar ${avatarId}:`, error);
    throw error;
  }

  return data;
};

// Create a new VNC session
export const createVncSession = async (sessionParams: VncSessionCreateParams) => {
  const { data, error } = await supabase
    .from('vnc_sessions')
    .insert({
      avatar_id: sessionParams.avatar_id,
      container_id: sessionParams.container_id,
      exposed_port: sessionParams.exposed_port,
      session_mode: sessionParams.session_mode || 'manual'
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating VNC session:', error);
    throw error;
  }

  return data;
};

// End a VNC session
export const endVncSession = async (sessionId: string) => {
  const { data, error } = await supabase
    .from('vnc_sessions')
    .update({
      ended_at: new Date().toISOString()
    })
    .eq('id', sessionId)
    .select()
    .single();

  if (error) {
    console.error(`Error ending VNC session ${sessionId}:`, error);
    throw error;
  }

  return data;
};