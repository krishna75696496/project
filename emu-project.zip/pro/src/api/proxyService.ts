import supabase from '../lib/supabase';

export interface ProxySessionCreateParams {
  task_id: string;
  proxy_host: string;
  proxy_port: number;
  proxy_user?: string;
  proxy_pass?: string;
}

// Get proxy session for a specific task
export const getProxySessionByTaskId = async (taskId: string) => {
  // First get the task ID from task_id
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .select('id')
    .eq('task_id', taskId)
    .single();

  if (taskError) {
    console.error(`Error finding task with task_id ${taskId}:`, taskError);
    throw taskError;
  }

  const { data, error } = await supabase
    .from('proxy_sessions')
    .select('*')
    .eq('task_id', task.id)
    .order('applied_at', { ascending: false })
    .limit(1)
    .single();

  if (error) {
    if (error.code === 'PGRST116') {
      // No proxy session found
      return null;
    }
    console.error(`Error fetching proxy session for task ${taskId}:`, error);
    throw error;
  }

  return data;
};

// Create a new proxy session
export const createProxySession = async (sessionParams: ProxySessionCreateParams) => {
  // First get the task ID from task_id
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .select('id')
    .eq('task_id', sessionParams.task_id)
    .single();

  if (taskError) {
    console.error(`Error finding task with task_id ${sessionParams.task_id}:`, taskError);
    throw taskError;
  }

  const { data, error } = await supabase
    .from('proxy_sessions')
    .insert({
      task_id: task.id,
      proxy_host: sessionParams.proxy_host,
      proxy_port: sessionParams.proxy_port,
      proxy_user: sessionParams.proxy_user,
      proxy_pass: sessionParams.proxy_pass
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating proxy session:', error);
    throw error;
  }

  return data;
};