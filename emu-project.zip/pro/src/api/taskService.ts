import supabase from '../lib/supabase';
import type { Task } from '../types';

export interface TaskCreateParams {
  task_id: string;
  task_type: string;
  account: string;
  social_media_app: string;
  python_code: string;
  task_data: any;
}

export interface TaskUpdateParams {
  status?: string;
  task_data?: any;
}

export interface TaskLogParams {
  task_id: string;
  status: string;
  details: string;
}

export interface TaskResultParams {
  task_id: string;
  result_data: any;
}

export interface ErrorLogParams {
  task_id: string;
  error_message: string;
  log_path?: string;
}

// Get all tasks for the current user
export const getTasks = async () => {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching tasks:', error);
    throw error;
  }

  return data;
};

// Get a specific task by ID
export const getTaskById = async (taskId: string) => {
  const { data, error } = await supabase
    .from('tasks')
    .select(`
      *,
      task_logs(*),
      task_results(*),
      error_logs(*)
    `)
    .eq('id', taskId)
    .single();

  if (error) {
    console.error(`Error fetching task ${taskId}:`, error);
    throw error;
  }

  return data;
};

// Create a new task
export const createTask = async (taskParams: TaskCreateParams) => {
  const { data: user } = await supabase.auth.getUser();
  
  if (!user.user) {
    throw new Error('User not authenticated');
  }

  const { data, error } = await supabase
    .from('tasks')
    .insert({
      task_id: taskParams.task_id,
      task_type: taskParams.task_type,
      account: taskParams.account,
      social_media_app: taskParams.social_media_app,
      python_code: taskParams.python_code,
      task_data: taskParams.task_data,
      assigned_to: user.user.id,
      status: 'pending'
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating task:', error);
    throw error;
  }

  return data;
};

// Update a task
export const updateTask = async (taskId: string, updateParams: TaskUpdateParams) => {
  const { data, error } = await supabase
    .from('tasks')
    .update(updateParams)
    .eq('id', taskId)
    .select()
    .single();

  if (error) {
    console.error(`Error updating task ${taskId}:`, error);
    throw error;
  }

  return data;
};

// Delete a task
export const deleteTask = async (taskId: string) => {
  const { error } = await supabase
    .from('tasks')
    .delete()
    .eq('id', taskId);

  if (error) {
    console.error(`Error deleting task ${taskId}:`, error);
    throw error;
  }

  return true;
};

// Add a task log
export const addTaskLog = async (logParams: TaskLogParams) => {
  // First get the task ID from task_id
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .select('id')
    .eq('task_id', logParams.task_id)
    .single();

  if (taskError) {
    console.error(`Error finding task with task_id ${logParams.task_id}:`, taskError);
    throw taskError;
  }

  const { data, error } = await supabase
    .from('task_logs')
    .insert({
      task_id: task.id,
      status: logParams.status,
      details: logParams.details
    })
    .select()
    .single();

  if (error) {
    console.error('Error adding task log:', error);
    throw error;
  }

  return data;
};

// Submit task results
export const submitTaskResults = async (resultParams: TaskResultParams) => {
  // First get the task ID from task_id
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .select('id')
    .eq('task_id', resultParams.task_id)
    .single();

  if (taskError) {
    console.error(`Error finding task with task_id ${resultParams.task_id}:`, taskError);
    throw taskError;
  }

  const { data, error } = await supabase
    .from('task_results')
    .insert({
      task_id: task.id,
      result_data: resultParams.result_data
    })
    .select()
    .single();

  if (error) {
    console.error('Error submitting task results:', error);
    throw error;
  }

  // Update task status to completed
  await updateTask(task.id, { status: 'completed' });

  return data;
};

// Log an error
export const logError = async (errorParams: ErrorLogParams) => {
  // First get the task ID from task_id
  const { data: task, error: taskError } = await supabase
    .from('tasks')
    .select('id')
    .eq('task_id', errorParams.task_id)
    .single();

  if (taskError) {
    console.error(`Error finding task with task_id ${errorParams.task_id}:`, taskError);
    throw taskError;
  }

  const { data, error } = await supabase
    .from('error_logs')
    .insert({
      task_id: task.id,
      error_message: errorParams.error_message,
      log_path: errorParams.log_path
    })
    .select()
    .single();

  if (error) {
    console.error('Error logging error:', error);
    throw error;
  }

  // Update task status to failed
  await updateTask(task.id, { status: 'failed' });

  return data;
};