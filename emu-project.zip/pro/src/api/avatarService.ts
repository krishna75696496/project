import supabase from '../lib/supabase';

export interface AvatarCreateParams {
  avatar_id: string;
  docker_volume_name?: string;
  social_app_state?: any;
}

export interface AvatarUpdateParams {
  docker_volume_name?: string;
  social_app_state?: any;
}

// Get all avatars for the current user
export const getAvatars = async () => {
  const { data: user } = await supabase.auth.getUser();
  
  if (!user.user) {
    throw new Error('User not authenticated');
  }

  const { data, error } = await supabase
    .from('profile_volumes')
    .select('*')
    .eq('user_id', user.user.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching avatars:', error);
    throw error;
  }

  return data;
};

// Get a specific avatar by ID
export const getAvatarById = async (avatarId: string) => {
  const { data, error } = await supabase
    .from('profile_volumes')
    .select('*')
    .eq('avatar_id', avatarId)
    .single();

  if (error) {
    console.error(`Error fetching avatar ${avatarId}:`, error);
    throw error;
  }

  return data;
};

// Create a new avatar
export const createAvatar = async (avatarParams: AvatarCreateParams) => {
  const { data: user } = await supabase.auth.getUser();
  
  if (!user.user) {
    throw new Error('User not authenticated');
  }

  const { data, error } = await supabase
    .from('profile_volumes')
    .insert({
      user_id: user.user.id,
      avatar_id: avatarParams.avatar_id,
      docker_volume_name: avatarParams.docker_volume_name,
      social_app_state: avatarParams.social_app_state
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating avatar:', error);
    throw error;
  }

  return data;
};

// Update an avatar
export const updateAvatar = async (avatarId: string, updateParams: AvatarUpdateParams) => {
  const { data, error } = await supabase
    .from('profile_volumes')
    .update(updateParams)
    .eq('avatar_id', avatarId)
    .select()
    .single();

  if (error) {
    console.error(`Error updating avatar ${avatarId}:`, error);
    throw error;
  }

  return data;
};

// Delete an avatar
export const deleteAvatar = async (avatarId: string) => {
  const { error } = await supabase
    .from('profile_volumes')
    .delete()
    .eq('avatar_id', avatarId);

  if (error) {
    console.error(`Error deleting avatar ${avatarId}:`, error);
    throw error;
  }

  return true;
};