/*
  # Create proxy sessions table

  1. New Tables
    - `proxy_sessions`
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key to tasks)
      - `proxy_host` (text)
      - `proxy_port` (integer)
      - `proxy_user` (text)
      - `proxy_pass` (text)
      - `applied_at` (timestamp)
  2. Security
    - Enable RLS on `proxy_sessions` table
*/

CREATE TABLE IF NOT EXISTS proxy_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  proxy_host text,
  proxy_port integer,
  proxy_user text,
  proxy_pass text,
  applied_at timestamptz DEFAULT now()
);

ALTER TABLE proxy_sessions ENABLE ROW LEVEL SECURITY;