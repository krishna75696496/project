/*
  # Create task logs table

  1. New Tables
    - `task_logs`
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key to tasks)
      - `status` (text)
      - `timestamp` (timestamp)
      - `details` (text)
  2. Security
    - Enable RLS on `task_logs` table
    - Add policy for authenticated users to access logs for their own tasks
*/

CREATE TABLE IF NOT EXISTS task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  status text,
  timestamp timestamptz DEFAULT now(),
  details text
);

ALTER TABLE task_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Access own logs"
  ON task_logs
  FOR ALL
  TO authenticated
  USING (task_id IN (
    SELECT id FROM tasks WHERE assigned_to = auth.uid()
  ));