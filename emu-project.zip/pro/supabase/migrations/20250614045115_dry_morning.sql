/*
  # Create profile volumes table

  1. New Tables
    - `profile_volumes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `avatar_id` (text, unique)
      - `docker_volume_name` (text)
      - `social_app_state` (jsonb)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on `profile_volumes` table
*/

CREATE TABLE IF NOT EXISTS profile_volumes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  avatar_id text UNIQUE,
  docker_volume_name text,
  social_app_state jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profile_volumes ENABLE ROW LEVEL SECURITY;