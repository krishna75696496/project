/*
  # Create tasks table

  1. New Tables
    - `tasks`
      - `id` (uuid, primary key)
      - `task_id` (text, unique)
      - `task_type` (text)
      - `account` (text)
      - `social_media_app` (text)
      - `python_code` (text)
      - `task_data` (jsonb)
      - `status` (text)
      - `assigned_to` (uuid, foreign key to users)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on `tasks` table
    - Add policy for authenticated users to access their own tasks
*/

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id text UNIQUE,
  task_type text,
  account text,
  social_media_app text,
  python_code text,
  task_data jsonb,
  status text DEFAULT 'pending',
  assigned_to uuid REFERENCES users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can access their own tasks"
  ON tasks
  FOR ALL
  TO authenticated
  USING (assigned_to = auth.uid());