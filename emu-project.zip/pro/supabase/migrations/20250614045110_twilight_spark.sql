/*
  # Create task results table

  1. New Tables
    - `task_results`
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key to tasks)
      - `result_data` (jsonb)
      - `submitted_at` (timestamp)
  2. Security
    - Enable RLS on `task_results` table
    - Add policy for authenticated users to access results for their own tasks
*/

CREATE TABLE IF NOT EXISTS task_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  result_data jsonb,
  submitted_at timestamptz DEFAULT now()
);

ALTER TABLE task_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Access own results"
  ON task_results
  FOR ALL
  TO authenticated
  USING (task_id IN (
    SELECT id FROM tasks WHERE assigned_to = auth.uid()
  ));