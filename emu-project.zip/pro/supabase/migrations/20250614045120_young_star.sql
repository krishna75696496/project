/*
  # Create VNC sessions table

  1. New Tables
    - `vnc_sessions`
      - `id` (uuid, primary key)
      - `avatar_id` (text)
      - `container_id` (text)
      - `exposed_port` (integer)
      - `session_mode` (text)
      - `started_at` (timestamp)
      - `ended_at` (timestamp)
  2. Security
    - Enable RLS on `vnc_sessions` table
*/

CREATE TABLE IF NOT EXISTS vnc_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  avatar_id text,
  container_id text,
  exposed_port integer,
  session_mode text DEFAULT 'manual',
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz
);

ALTER TABLE vnc_sessions ENABLE ROW LEVEL SECURITY;