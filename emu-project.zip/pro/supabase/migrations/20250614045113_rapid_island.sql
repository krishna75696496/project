/*
  # Create error logs table

  1. New Tables
    - `error_logs`
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key to tasks)
      - `error_message` (text)
      - `log_path` (text)
      - `reported_at` (timestamp)
  2. Security
    - Enable RLS on `error_logs` table
*/

CREATE TABLE IF NOT EXISTS error_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  error_message text,
  log_path text,
  reported_at timestamptz DEFAULT now()
);

ALTER TABLE error_logs ENABLE ROW LEVEL SECURITY;