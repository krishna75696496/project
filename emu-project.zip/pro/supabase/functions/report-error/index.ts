import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Only allow POST requests
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Method not allowed" }),
        {
          status: 405,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Parse the request body
    const { task_id, error: errorMessage, log_path } = await req.json();

    if (!task_id || !errorMessage) {
      return new Response(
        JSON.stringify({ error: "task_id and error are required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      }
    );

    // Get the user from the request
    const {
      data: { user },
    } = await supabaseClient.auth.getUser();

    if (!user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // First get the task ID from task_id
    const { data: task, error: taskError } = await supabaseClient
      .from("tasks")
      .select("id")
      .eq("task_id", task_id)
      .eq("assigned_to", user.id)
      .single();

    if (taskError) {
      return new Response(
        JSON.stringify({ error: "Task not found or not authorized" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Log the error
    const { error: errorLogError } = await supabaseClient
      .from("error_logs")
      .insert({
        task_id: task.id,
        error_message: errorMessage,
        log_path
      });

    if (errorLogError) {
      return new Response(
        JSON.stringify({ error: errorLogError.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Update the task status to failed
    const { error: updateError } = await supabaseClient
      .from("tasks")
      .update({ status: "failed" })
      .eq("id", task.id);

    if (updateError) {
      return new Response(
        JSON.stringify({ error: updateError.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Add a task log
    const { error: logError } = await supabaseClient
      .from("task_logs")
      .insert({
        task_id: task.id,
        status: "failed",
        details: `Error: ${errorMessage}`
      });

    if (logError) {
      console.error("Error adding task log:", logError);
      // Continue even if log fails
    }

    return new Response(
      JSON.stringify({ success: true, message: "Error reported successfully" }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});