import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { connect, publish } from "npm:nsq@0.3.8";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

// NSQ configuration
const NSQ_HOST = Deno.env.get("NSQ_HOST") || "localhost";
const NSQ_PORT = parseInt(Deno.env.get("NSQ_PORT") || "4150");
const NSQ_TOPIC = "emulator_control";
const NSQ_CHANNEL = "manual_control_requests";

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Only allow POST requests
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Method not allowed" }),
        {
          status: 405,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Parse the request body
    const { avatar_uuid, social_media_app, proxy_host, proxy_port, proxy_user, proxy_pass } = await req.json();

    if (!avatar_uuid || !social_media_app) {
      return new Response(
        JSON.stringify({ error: "avatar_uuid and social_media_app are required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      }
    );

    // Get the user from the request
    const {
      data: { user },
    } = await supabaseClient.auth.getUser();

    if (!user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Verify the avatar belongs to the user
    const { data: avatar, error: avatarError } = await supabaseClient
      .from("profile_volumes")
      .select("id")
      .eq("avatar_id", avatar_uuid)
      .eq("user_id", user.id)
      .single();

    if (avatarError) {
      return new Response(
        JSON.stringify({ error: "Avatar not found or not authorized" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Prepare the message for NSQ
    const message = {
      avatar_uuid,
      social_media_app,
      proxy_host,
      proxy_port,
      proxy_user,
      proxy_pass
    };

    // Publish message to NSQ
    try {
      const writer = await connect({ host: NSQ_HOST, port: NSQ_PORT });
      await publish(writer, NSQ_TOPIC, message);
      
      // Create a VNC session record (we'll update the port later when the container responds)
      const { data: vncSession, error: vncError } = await supabaseClient
        .from("vnc_sessions")
        .insert({
          avatar_id: avatar_uuid,
          session_mode: "manual",
          // Container ID and exposed port will be updated by the orchestrator
        })
        .select()
        .single();

      if (vncError) {
        console.error("Error creating VNC session:", vncError);
        // Continue even if VNC session creation fails
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "Manual control request sent",
          session_id: vncSession?.id
        }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    } catch (nsqError) {
      console.error("NSQ error:", nsqError);
      return new Response(
        JSON.stringify({ error: "Failed to send control request to NSQ" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});