import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
    server: {
    host: '0.0.0.0', // Allow external access (important for EC2/Docker)
    port: 3000,       // Change this if you're using a different port
  },
});
